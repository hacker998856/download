<?php
if (empty($_POST['NameGame'])) {
	
}
if (empty($_POST['CodeGame'])) {
	$_POST['CodeGame'] = "";
}

$message = $class->PlayGame($_POST['NameGame'],$_POST['CodeGame']);
echo json_encode($message);
?>