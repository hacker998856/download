<?php 
if (empty($_POST['phone_mb'])) {
	$message['status'] = "error";
	$message['info'] = "phone_mb";
}elseif (empty($_POST['phone_true'])) {
	$message['status'] = "error";
	$message['info'] = "phone_true";
}elseif (empty($_POST['password_mb'])) {
	$message['status'] = "error";
	$message['info'] = "password_mb";
}elseif (empty($_POST['bank_mb'])) {
	$message['status'] = "error";
	$message['info'] = "bank_mb";
}elseif (empty($_POST['bankacc_mb'])) {
	$message['status'] = "error";
	$message['info'] = "bankacc_mb";
}elseif (empty($_POST['name_mb'])) {
	$message['status'] = "error";
	$message['info'] = "name_mb";
}elseif (empty($_POST['status_mb'])) {
	$message['status'] = "error";
	$message['info'] = "status_mb";
}elseif (empty($_POST['ip'])) {
	$message['status'] = "error";
	$message['info'] = "ip";
}elseif (empty($_POST['date_mb'])) {
	$message['status'] = "error";
	$message['info'] = "date_mb";
}else{
	$message = $class->register($_POST['phone_mb'],$_POST['phone_true'],$_POST['password_mb'],$_POST['bank_mb'],$_POST['bankacc_mb'],$_POST['name_mb'],$_POST['status_mb'],$_POST['ip'],$_POST['date_mb'],$_POST['aff']);
}
 
echo json_encode($message);
if ($message['status'] == "success") {
$load_setting = $class->load_db_setting();
$sMessage = "สมาชิกใหม่ \nชื่อ ".$_POST['name_mb']." \nเบอร์ ".$_POST['phone_mb']." \nเลขบัญชี ".$_POST['bankacc_mb']." \nธนาคาร ".$_POST['bank_mb']." \nผู้แนะนำ ".$_POST['aff'];
$token = $load_setting->lineregister;
$run_class = $class->notify_line_user($sMessage,$token);
}
?>