<?php
$message = $class->spinner();

echo $message;
//echo json_encode($message);
?>