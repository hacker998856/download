<?php 
$message = $class->update_time_refresh($_POST['v_time']);
echo json_encode($message);
?>