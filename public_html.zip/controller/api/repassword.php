<?php 
if(empty($_POST['passwordold'])) {
	$message['status'] = "error";
	$message['info'] = "กรุณาใส่รหัสผ่านเก่า";
}elseif(empty($_POST['passwordnew'])) {
	$message['status'] = "error";
	$message['info'] = "กรุณาใส่รหัสผ่านใหม่";
}elseif ($_POST['passwordnew']!==$_POST['confirmpasswordnew']) {
	$message['status'] = "error";
	$message['info'] = "ยืนยันรหัสผ่านไม่ตรงกัน";
}else{
	$message = $class->changepassword($_POST['passwordold'],$_POST['passwordnew']);
}
echo json_encode($message);
?>