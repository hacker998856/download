<?php 
session_destroy();
?>