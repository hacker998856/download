<?php
if (empty($_POST['promotion_dp'])) {
	$message['status'] = "error";
	$message['info'] = "กรุณาเลือก โปรโมชั่น";
}else{
	$message = $class->deposit_dp($_POST['id_dp'],$_POST['username_dp'],$_POST['amount_dp'],$_POST['phone_dp'],$_POST['bank_dp'],$_POST['bankacc_dp'],$_POST['name_dp'],$_POST['confirm_dp'],$_POST['promotion_dp'],$_POST['aff_dp'],$_POST['note_dp'],$_POST['bonus_dp'],$_POST['fromTrue']);
}
echo json_encode($message);
?>