<?php
$message = $class->GetDiamond();
echo json_encode($message);
?>