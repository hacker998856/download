<?php


$message = $class->withdraw_cashback($_POST['amount'],$_POST['id_cb'],$_POST['username_cb'],$_POST['bank_cb'],$_POST['bankacc_cb'],$_POST['name_cb'],$_POST['phone_cb'],$_POST['confirm_cb']);
echo json_encode($message);
?>