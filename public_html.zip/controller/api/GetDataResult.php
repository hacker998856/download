<?php
$message = $class->refresh_balance_agent();
//$message['status'] = "success";
//$message['Balance'] = "160";
echo json_encode($message);
?>