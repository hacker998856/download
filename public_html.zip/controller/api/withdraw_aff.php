<?php


$message = $class->withdraw_aff($_POST['id_aff'],$_POST['username_aff'],$_POST['bank_aff'],$_POST['phone_aff'],$_POST['bankacc_aff'],$_POST['name_aff'],$_POST['confirm_aff']);
echo json_encode($message);
?>