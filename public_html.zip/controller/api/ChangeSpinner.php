<?php
$message = $class->Change_Spinner();
echo json_encode($message);
?>