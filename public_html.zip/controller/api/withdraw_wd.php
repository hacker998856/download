<?php 
$message = $class->withdraw_wd($_POST['lastpro'],$_POST['id_wd'],$_POST['username_wd'],$_POST['bank_wd'],$_POST['bankacc_wd'],$_POST['name_wd'],$_POST['phone_wd'],$_POST['turnover_wd'],$_POST['confirm_wd'],$_POST['creditufa'],$_POST['amount_wd']);

echo json_encode($message);

if ($message['status'] == "success") {
$load_setting = $class->load_db_setting();
$sMessage = "แจ้งถอนเงิน \nจำนวนเงิน ".$_POST['amount_wd']." บาท\nเบอร์ ".$_POST['phone_wd']." \nเลขบัญชี ".$_POST['bankacc_wd']." \nธนาคาร ".$_POST['bank_wd']." \nชื่อ ".$_POST['name_wd'];
$token = $load_setting->linewithdraw;
$run_class = $class->notify_line_user($sMessage,$token);
}
?>