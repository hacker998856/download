<?php
$message = $class->Change_Diamond();
echo json_encode($message);
?>