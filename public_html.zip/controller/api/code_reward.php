<?php
if (empty($_POST['code_id'])) {
	$message['status'] = "error";
	$message['info'] = "กรุณากรอก โค้ด";
}else{
$message = $class->code_reward($_POST['code_id']);	
}
echo json_encode($message);
?>