<?php
$New_date = array_merge($_POST, $_FILES);
$message = $class_admin->api_promotion($New_date);
echo json_encode($message);
//$_POST['age'] = 26;
//$New_date = array_merge($_POST, $_FILES);
//echo $New_date['fileupload_bank']['name'];
//extract($New_date);
//var_dump(get_defined_vars());
//echo "<pre>";
//print_r($New_date);
//print_r($_FILES);   
//echo "</pre>";
?>