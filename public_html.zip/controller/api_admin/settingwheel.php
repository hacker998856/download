<?php
$message = $class_admin->api_settingwheel($_POST);
echo json_encode($message);
?>