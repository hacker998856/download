<?php
if(isset($_FILES['fileupload']['name'])){
	
	$files = glob('assets/img/popup/*');
	foreach($files as $file){
	  if(is_file($file)) {
		unlink($file);
	  }
	}
	
	
	$ran=(rand(10000,99999));
	$filename = $_FILES["fileupload"]["name"];
	$extension = end(explode(".", $filename));
	$newfilename = $ran.".".$extension;

	$location = "assets/img/popup/".$newfilename;
	$imageFileType = pathinfo($location,PATHINFO_EXTENSION);
	$imageFileType = strtolower($imageFileType);

	$moveResult = move_uploaded_file($_FILES['fileupload']['tmp_name'],$location);
	if ($moveResult == true) {
		
		$message['status'] = "success";
		$message['info'] = "เพิ่มรูปเรียบร้อย";
		
	}
	
}

echo json_encode($message);
?>