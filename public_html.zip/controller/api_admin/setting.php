<?php 
$message = $class_admin->api_setting($_POST);
echo json_encode($message);
?>