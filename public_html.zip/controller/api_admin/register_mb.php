<?php
$message = $class_admin->register_mb($_POST);
echo json_encode($message);
?>