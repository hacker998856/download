<?php
$message = $class_admin->api_promotion($_POST);
echo json_encode($message);
?>