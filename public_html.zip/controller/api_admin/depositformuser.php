<?php

$promotion_dp = $_POST["promotion_dp"];
$amount_dp = $_POST["amount_dp"];
$phone_mb = $_POST["phone_mb"];

$sql = "SELECT * FROM member WHERE phone_mb = '$phone_mb'";
$result = $class_admin->load_date_sql($sql);
$row = mysqli_fetch_array($result);
extract($row);


$check = "SELECT username_dp FROM deposit WHERE confirm_dp = 'รอดำเนินการ' AND id_dp = $id_mb AND username_dp = '$username_mb'";
$result1 = $class_admin->load_date_sql($check);
$num = mysqli_num_rows($result1);
if($num > 0){
	$message['status'] = "error";
	$message['info'] = "ท่านมีรายการฝากอยู่ 1 รายการ";
}else{


$check2 = "SELECT username_dp FROM deposit , promotion WHERE username_dp = '$username_mb' AND time_pro = 'รับได้ครั้งเดียว' AND promotion_dp = '$promotion_dp' AND confirm_dp = 'อนุมัติ' AND name_pro = '$promotion_dp'";
$result2 = $class_admin->load_date_sql($check2);
$num2 = mysqli_num_rows($result2);
if($num2 > 0){
	$message['status'] = "error";
	$message['info'] = "ท่านรับโปรโมชั่นนี้ไปแล้ว ! กรุณาเลือกโปรโมชั่นอื่น";
}else{



$date3 = date("Y-m-d");
$check3 = "SELECT username_dp FROM deposit , promotion WHERE username_dp = '$username_mb' AND promotion_dp = '$promotion_dp' AND time_pro = 'รับได้วันละ 1 ครั้ง' AND confirm_dp = 'อนุมัติ' AND name_pro = '$promotion_dp' AND date_dp LIKE '%$date3%'";
$result3 = $class_admin->load_date_sql($check3);
$num3 = mysqli_num_rows($result3);
if($num3 > 0){
	$message['status'] = "error";
	$message['info'] = "วันนี้ท่านรับโปรโมชั่นรายวันนี้ไปแล้ว ! กรุณาเลือกโปรโมชั่นอื่น";
}else{
	
	$message['status'] = "success";
	$message['info'] = "สำเร็จ อยู่ระหว่างดำเนินการ";
	
	$sql9 = "INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, game_dp, fromTrue)
             VALUES('$id_mb', '$username_mb', '$phone_mb', '$bank_mb', '$bankacc_mb','$name_mb', 'รอดำเนินการ', '$amount_dp', '$promotion_dp', '$aff', '', '', '', '$phone_true')";
	$result = $class_admin->run_insert_sql($sql9);
	
	
	$load_setting = $class_admin->load_db_setting();
	$sMessage = "แอดมินฝาก \nจำนวนเงิน ".$amount_dp." บาท\nเบอร์ ".$phone_mb."\nโปรโมชั่น ".$promotion_dp;
	$token = $load_setting->linedeposit;
	$run_class = $class_admin->notify_line($sMessage,$token);
	
}	
}
}






echo json_encode($message);
?>