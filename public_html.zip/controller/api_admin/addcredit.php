<?php 
if (empty($_POST['username'])) {
	$message['status'] = "error_username";
}elseif (empty($_POST['amount'])) {
	$message['status'] = "error_amount";
}else{
	$message = $class_admin->deposit_agent($_POST['username'],$_POST['amount']);
}


echo json_encode($message);

if ($message['status'] == "success") {

$load_setting = $class_admin->load_db_setting();
$load_profile_user = $class_admin->profile_user($_POST['username']);
$sMessage = "เติมเครดิตโดยแอดมิน \nจำนวนเงิน ".$_POST['amount']." บาท\nเข้ายูสเซอร์ ".$load_profile_user->username_mb ." \nเบอร์โทรศัพท์ ".$load_profile_user->phone_mb ." \nชื่อ ".$load_profile_user->name_mb ." \nผู้ทำรายการ ".$_SESSION["name_ad"];
$token = $load_setting->linedeposit;
$run_class = $class_admin->notify_line($sMessage,$token);

}
?>