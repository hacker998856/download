<?php
$message = $class_admin->register_ad($_POST);
echo json_encode($message);
?>