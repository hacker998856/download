<?php 

include 'connect.class.php';

use Nullix\CryptoJsAes\CryptoJsAes;

use DivineOmega\SSHConnection\SSHConnection;

use PHPUnit\Framework\TestCase;

include "CryptoJsAes.php";

class system extends pdo_mysql{

	function __construct(){

		$this->db = $this->DB_PDO();	

	}
	
	
	public function generateRandomString($length = 5) {

		$characters = '0123456789';

		$charactersLength = strlen($characters);

		$randomString1 = '';
		$randomString2 = '';
		$randomString3 = '';
		$randomString4 = '';

		for ($i = 0; $i < $length; $i++) {

			$randomString1 .= $characters[rand(0, $charactersLength - 1)];
			$randomString2 .= $characters[rand(0, $charactersLength - 1)];
			$randomString3 .= $characters[rand(0, $charactersLength - 1)];
			$randomString4 .= $characters[rand(0, $charactersLength - 1)];

		}

		return "newjersey88_" . $randomString1 . "_" . $randomString2 . "_" . $randomString3 . "_" . $randomString4;

	}
	
	
	public function register($phone_mb,$phone_true,$password_mb,$bank_mb,$bankacc_mb,$name_mb,$status_mb,$ip,$date_mb,$aff){
		
		$check_phone_mb = $this->db->prepare("SELECT * FROM member WHERE phone_mb = :phone_mb");
		$check_phone_mb->execute([':phone_mb'=>$phone_mb]);
		
		$check_bankacc_mb = $this->db->prepare("SELECT * FROM member WHERE bankacc_mb = :bankacc_mb");
		$check_bankacc_mb->execute([':bankacc_mb'=>$bankacc_mb]);
		
		$check_name_mb = $this->db->prepare("SELECT * FROM member WHERE name_mb = :name_mb");
		$check_name_mb->execute([':name_mb'=>$name_mb]);
		
		$check_phone_true = $this->db->prepare("SELECT * FROM member WHERE phone_true = :phone_true");
		$check_phone_true->execute([':phone_true'=>$phone_true]);
		
		
		if ($check_phone_mb->rowcount() > 0) {
			
			$message['status'] = "error";
			$message['info'] = "มี เบอร์โทรศัพท์นี้  ในระบบอยู่แล้ว";
			
		}elseif ($check_bankacc_mb->rowcount() > 0) {
			
			$message['status'] = "error";
			$message['info'] = "มี บัญชีธนาคารนี้ ในระบบอยู่แล้ว";
		}elseif ($check_name_mb->rowcount() > 0) {
			
			$message['status'] = "error";
			$message['info'] = "มี ชื่อ-นามสกุลนี้ ในระบบอยู่แล้ว";
			
		}elseif ($check_phone_true->rowcount() > 0) {
			
			$message['status'] = "error";
			$message['info'] = "มี ไอดีทรูวอเล็ตนี้ ในระบบอยู่แล้ว";
				
		}else{
			
			
			$add_register = $this->db->prepare("UPDATE member SET  
            password_mb = :password_mb , 
            phone_mb = :phone_mb ,
            phone_true = :phone_true ,
            bank_mb = :bank_mb ,
            bankacc_mb = :bankacc_mb ,
            name_mb = :name_mb ,
            status_mb = :status_mb ,
            aff = :aff ,
            add_mb = :add_mb ,
            date_mb = :date_mb ,
            ip = :ip
            WHERE phone_mb = '' ORDER BY id_mb ASC LIMIT 1");
			
			try {

				$add_register->execute([':password_mb'=>$password_mb,':phone_mb'=>$phone_mb,':phone_true'=>$phone_true,':bank_mb'=>$bank_mb,':bankacc_mb'=>$bankacc_mb,':name_mb'=>$name_mb,':status_mb'=>$status_mb,':aff'=>$aff,':add_mb'=>'MEMBER',':date_mb'=>$date_mb,':ip'=>$ip]);

				$message['status'] = "success";
				$message['info'] = "สำเร็จ";
				
				$this->login($phone_mb,$password_mb);

			} catch (Exception $e) {

				$message['status'] = "error";
				$message['info'] = "error";

			}
			
			
		}
			
		return $message;	
			
	}
	

	public function login($phone_mb,$password_mb){

		$stmt = $this->db->prepare("SELECT * FROM member WHERE phone_mb = :phone_mb and password_mb = :password_mb");

		$stmt->execute([':phone_mb'=>$phone_mb,':password_mb'=>$password_mb]);

		if ($stmt->rowcount() > 0) {

			$result = $stmt->fetch();


				$message['status'] = "success";

				$message['info'] = "เข้าสู่ระบบสำเร็จ";

				$_SESSION["id_mb"] = $result->id_mb;
                $_SESSION["username_mb"] = $result->username_mb;
                $_SESSION["password_mb"] = $result->password_mb;
                $_SESSION["name_mb"] = $result->name_mb;
                $_SESSION["bank_mb"] = $result->bank_mb;
                $_SESSION["bankacc_mb"] = $result->bankacc_mb;
                $_SESSION["phone_mb"] = $result->phone_mb;
                $_SESSION["status_mb"] = $result->status_mb;
                $_SESSION["confirm_mb"] = $result->confirm_mb;
                $_SESSION["aff"] = $result->aff;
                $_SESSION["status"] = $result->status;
                $_SESSION["password_ufa"] = $result->password_ufa;
                $_SESSION["ip"] = $result->ip;
                $_SESSION["phone_true"] = $result->phone_true;
                $_SESSION["creditspin"] = $result->creditspin;
                $_SESSION["point"] = $result->point;
				$_SESSION["diamond"] = $result->diamond;
				
				$this->load_session();

		}else{

			$message['status'] = "error";
			$message['info'] = "รหัสผ่านไม่ถูกต้อง";

		}

		return $message;

	}
	
	public function showprofile(){

		$stmt = $this->db->prepare("SELECT * FROM member WHERE id_mb = :id_mb");

		$stmt->execute([':id_mb'=>$_SESSION["id_mb"]]);

		return $stmt->fetch();

	}
	
	public function show_promotion(){

		$stmt = $this->db->prepare("SELECT * FROM promotion WHERE status_pro = 'เปิด'");

		$stmt->execute();
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}

		//return $stmt->fetch();

	}
	
	
	//ดึงยอดเงินฝากล่าสุด
	public function user_get_deposit_latest(){

		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE confirm_dp = 'อนุมัติ' AND phone_dp = :phone_dp ORDER BY id DESC limit 1");

		$stmt->execute([':phone_dp'=>$_SESSION["phone_mb"]]);
		
		return $stmt->fetch();
		
	}
	
	public function load_db_setting(){

		$stmt = $this->db->prepare("SELECT * FROM setting ORDER BY id DESC LIMIT 1");

		$stmt->execute();

		return $stmt->fetch();

	}
	
	public function load_key_agent(){

		$stmt = $this->db->prepare("SELECT * FROM apikey ORDER BY id DESC LIMIT 1");

		$stmt->execute();

		return $stmt->fetch();

	}
	
	public function load_bank(){

		$stmt = $this->db->prepare("SELECT * FROM bank WHERE bankfor LIKE '%ฝาก%' AND status_bank ='เปิด'");

		$stmt->execute();
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}

	}
	
	
	public function update_balance_db($credit){
		
		$update_balance = $this->db->prepare("UPDATE member SET credit = :credit WHERE id_mb = :id_mb");
		$update_balance->execute([':credit' => $credit, ':id_mb' => $_SESSION["id_mb"]]);
		
	}
	
	public function load_session(){
		
		$date_setting = $this->load_db_setting();
		/////////////////////////////////////////////////
		
		$_SESSION["lineoa"] = $date_setting->lineoa;
		$_SESSION["UsernameUFA"] = $date_setting->agent .$_SESSION["username_mb"];
		$this->check_balance_agent();
		$this->check_withdraw_aff_1();
		$this->Check_Deposit_All();
		$this->Check_Withdraw_All();
		/////////////////////////////////////////////////
		
		//$_SESSION["UsernameUFA"] = "b42ppkrk1fhqo";
		//$_SESSION["Balance"] = "100";
		/////////////////////////////////////////////////
		
		
		

		//==> สร้าง session UsernameUFA
		

		//$data2 = $this->check_balance_agent("b42ppkrk1fhqo");
		//$Balance1 = json_decode($data2);
		//$Balance = $Balance1->data->balance;
		//$_SESSION["UsernameUFA"] = $date_setting->agent .$_SESSION["username_mb"];
		//$_SESSION["UsernameUFA"] = "b42ppkrk1fhqo";
		
		
		//==> สร้าง session ยอดเงิน agent
		//$data2 = $this->check_balance_agent($_SESSION["UsernameUFA"]);
		//$data2 = $this->check_balance_agent($_SESSION["UsernameUFA"]);
		//$Balance1 = json_decode($data2);
		//$Balance = $Balance1->data->balance;
		//$_SESSION["Balance"] = $Balance;
		
		

	}
	
	
	public function getapigame($link){

		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $link,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_SSL_VERIFYPEER => false,
		));
		$result = curl_exec($ch);
		curl_close ($ch);
		$result_json = json_decode($result,true);
		
		return $result_json;

	}
	
	public function LoadGame($Link){
		
		$key_agent = $this->load_key_agent();

		$ch = curl_init();
		curl_setopt_array($ch, array(
			CURLOPT_URL => $Link,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.$key_agent->x_api_betflix,
					'x-api-key: '.$key_agent->x_api_key
				  ),
		));
		$result = curl_exec($ch);
		curl_close ($ch);
		$result_json = json_decode($result,true);
		
		return $result_json;

	}
	
	public function PlayGame($NameGame,$CodeGame){
		
		$key_agent = $this->load_key_agent();
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => 'https://api.bfx.fail/v4/play/login',
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_POSTFIELDS => 'username='.$_SESSION["UsernameUFA"].'&provider='. $NameGame .'&gamecode='. $CodeGame .'&language=thai',
			CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.$key_agent->x_api_betflix,
					'x-api-key: '.$key_agent->x_api_key,
					'Content-Type: application/x-www-form-urlencoded'
				  ),
		));
		
		$response = curl_exec($curl);
       
		 
		if(curl_errno($curl)){
			
			$message['status'] = "error";
			$message['launch_url'] = "";
			
		}else{
			
			$date_decode = json_decode($response);
			$date_response = $date_decode->data->launch_url;
			$message['status'] = "success";
			$message['launch_url'] = $date_response;
		}
		
		curl_close($curl);
		return $message;
        //return $response;

	}
	
	
	public function register_agent($username,$password){
		
		$key_agent = $this->load_key_agent();
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/user/register',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => 'username='.$username.'&password='.$password,
		  CURLOPT_HTTPHEADER => array(
			'x-api-betflix: '.$key_agent->x_api_betflix,
			'x-api-key: '.$key_agent->x_api_key,
			'Content-Type: application/x-www-form-urlencoded'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);

		return $response;

	}
	
	public function check_balance_agent(){

		$key_agent = $this->load_key_agent();
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/user/balance',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => 'username='.$_SESSION["UsernameUFA"],
		  CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.$key_agent->x_api_betflix,
					'x-api-key: '.$key_agent->x_api_key,
					'Content-Type: application/x-www-form-urlencoded'
				  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		
		if(curl_errno($curl)){
			
			$_SESSION["Balance"] = "0";
			return 0;
			
		}else{
			
			$status_response = json_decode($response);
			if($status_response->status == 'success'){
				$_SESSION["Balance"] = $status_response->data->balance;
				return $status_response->data->balance;
			}else{
				$_SESSION["Balance"] = "0";
				return 0;
			}
			
		}
		

	}
	
	public function refresh_balance_agent(){
		
		
		$key_agent = $this->load_key_agent();
		
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/user/balance',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => 'username='.$_SESSION["UsernameUFA"],
		  CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.$key_agent->x_api_betflix,
					'x-api-key: '.$key_agent->x_api_key,
					'Content-Type: application/x-www-form-urlencoded'
				  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		if(curl_errno($curl))
		{
			$message['status'] = "error";
			$message['Balance'] = "0";
			$_SESSION["Balance"] = "0";
			
		}else{
			
			$status_response = json_decode($response);
			if($status_response->status == 'success'){
				$balance = $status_response->data->balance;
				
				if($balance > $_SESSION["Balance"]){
					
					$message['status'] = "newbalance";
					$message['Balance'] = $balance;
					$_SESSION["Balance"] = $balance;
				}else{
					
					$message['status'] = "success";
					$message['Balance'] = $balance;
					$_SESSION["Balance"] = $balance;
				}

			}else{
				
				$message['status'] = "error";
				$message['Balance'] = "0";
				$_SESSION["Balance"] = "0";
				
			}
			
		}
		$message['Deposit_All'] = $this->Check_Deposit_All();
		$message['Withdraw_All'] = $this->Check_Withdraw_All();
		$message['countdeposit'] = $this->countdeposit();
		return $message;

	}
	
	
	public function countdeposit(){
		
		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE confirm_dp = 'อนุมัติ' AND username_dp = :username_dp");
		$stmt->execute([':username_dp'=>$_SESSION["username_mb"]]);
		return $stmt->rowcount();
		
	}
	
	
	public function check_Balance_api(){
		
		$key_agent = $this->load_key_agent();
		
		$ch = curl_init();
		curl_setopt_array($ch, array(
				CURLOPT_URL => 'https://api.bfx.fail/v4/user/balance',
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_PROXY => false,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_POSTFIELDS => 'username='.$_SESSION["UsernameUFA"],
				CURLOPT_HTTPHEADER => array(
					'x-api-betflix: '.$key_agent->x_api_betflix,
					'x-api-key: '.$key_agent->x_api_key,
					'Content-Type: application/x-www-form-urlencoded'
				  ),
			));
			$result = curl_exec($ch);
			curl_close ($ch);
			return $result;
		
	}
	
	public function withdraw_agent($username,$credit){

		$key_agent = $this->load_key_agent();
		
		$ran = $this->generateRandomString();
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/user/transfer',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => 'username='.$username.'&amount=-'.$credit.'&ref=with'.$ran,
		  CURLOPT_HTTPHEADER => array(
			'x-api-betflix: '.$key_agent->x_api_betflix,
			'x-api-key: '.$key_agent->x_api_key,
			'Content-Type: application/x-www-form-urlencoded'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		
		return $response;

	}
	
	public function deposit_agent($username,$credit){
		
		$key_agent = $this->load_key_agent();
		
		$ran = $this->generateRandomString();
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/user/transfer',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => 'username='.$username.'&amount='.$credit.'&ref=dps'.$ran,
		  CURLOPT_HTTPHEADER => array(
			'x-api-betflix: '.$key_agent->x_api_betflix,
			'x-api-key: '.$key_agent->x_api_key,
			'Content-Type: application/x-www-form-urlencoded'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		
		return $response;

	}
	
	public function turnover_agent(){
		
		$key_agent = $this->load_key_agent();
		
		
		date_default_timezone_set("Asia/Bangkok");
		$start_date=date('Y-m-d');  
		$end_date=date('Y-m-d');

		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/report/summary?start='.$start_date.'&end='.$end_date.'&username='.$_SESSION["UsernameUFA"],
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'x-api-betflix: '.$key_agent->x_api_betflix,
			'x-api-key: '.$key_agent->x_api_key,
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		
		$turnover_decode = json_decode($response);
		$turnover_data = $turnover_decode->data->turnover;
		
		return $turnover_data;
		//return json_decode($response);

	}
	
	public function turnoveryu_agent(){
		
		
		$key_agent = $this->load_key_agent();
		
		date_default_timezone_set("Asia/Bangkok");
		$start_date=date('Y-m-d',strtotime('-1 day'));  
		$end_date=date('Y-m-d',strtotime('-1 day'));  

		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.bfx.fail/v4/report/summary?start='.$start_date.'&end='.$end_date.'&username='.$_SESSION["UsernameUFA"],
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'x-api-betflix: '.$key_agent->x_api_betflix,
			'x-api-key: '.$key_agent->x_api_key,
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		
		$dataresponse = $response;
		$decode_date = json_decode($dataresponse);
		return $decode_date->data->winloss;

	}
	
	///////////////////////////////////////////////////////////
	
	
	//เซ้คฝากกดรับโปร
	public function check_pro(){
		
		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE phone_dp = :phone_dp AND confirm_dp = 'อนุมัติ' AND promotion_dp!='แจกฟรีเพียงแค่สมัคร'");
		$stmt->execute([':phone_dp'=>$_SESSION["phone_mb"]]);
		return $stmt->rowcount();
		
	}
	public function show_pro1(){
		
		$stmt = $this->db->prepare("SELECT * FROM promotion WHERE time_pro!='สมาชิกใหม่' AND showpic!='เปิด' ORDER BY id desc");
		$stmt->execute();
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	public function show_pro2(){
		
		$stmt = $this->db->prepare("SELECT * FROM promotion WHERE showpic!='เปิด' ORDER BY id desc");
		$stmt->execute();
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		

		
	}
	
	public function line_notify(){
		
		
		
	}
	//ถอน
	public function get_withdraw(){
		
		$stmt = $this->db->prepare("SELECT * FROM withdraw WHERE phone_wd = :phone_wd");
		$stmt->execute([':phone_wd'=>$_SESSION["phone_mb"]]);
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	//ดึงรายการฝาก
	public function get_list_deposit(){
		
		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE id_dp = :id_mb ORDER BY id DESC limit 10");
		$stmt->execute([':id_mb'=>$_SESSION["id_mb"]]);
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	//ดึงรายการถอน
	public function get_list_withdraw(){
		
		$stmt = $this->db->prepare("SELECT * FROM withdraw WHERE username_wd = :username_mb AND amount_wd != '' ORDER BY id DESC limit 20");
		$stmt->execute([':username_mb'=>$_SESSION["username_mb"]]);
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////
	//รับค่า ถอน
	public function withdraw_wd($lastpro,$id_wd,$username_wd,$bank_wd,$bankacc_wd,$name_wd,$phone_wd,$turnover_wd,$confirm_wd,$creditufa,$amount_wd){

		$get_deposit_latest = $this->user_get_deposit_latest();

		$Balance3 = array(",");
		$get_creditufa = $this->check_balance_agent();
		$balance = str_replace($Balance3, "", $get_creditufa);
		
		
		$setting = $this->load_db_setting();
		$setwd = $setting->set_wd;
		//////////////////////////////////////////////////
		
		
		//เช็ค
		$check_list_wd = $this->check_list_wd();
		$check_confirm_dp = $this->check_confirm_dp();
		
		
		
		
		
		
		if ($check_confirm_dp<1) {
			
			$message['status'] = "error";
			$message['info'] = "ติดต่อแอดมิน";
			
		}else{
			
			
			if (empty($get_deposit_latest)) {
			
				$message['status'] = "error";
				$message['info'] = "ไม่เคยฝาก";
				
			}else{
				$replace_text = $this->extract_int($get_deposit_latest->turnover);
				$newstr = $replace_text;
				
				if ($creditufa == 'Total Bet Credit') {
				
					$message['status'] = "error";
					$message['info'] = "ถอนเงินผิดพลาด กรุณาติดต่อแอดมิน !";
					
				}else{
					
					if($amount_wd < $newstr){
						
						$message['status'] = "error";
						$message['info'] = "ยอดเทิร์นยังไม่ครบ";
						
					}else{
						
						if($amount_wd > $balance){
							
							$message['status'] = "error";
							$message['info'] = "เครดิตไม่เพียงพอ";
							
						}else{
							
							if($amount_wd < $setwd){
								
								$message['status'] = "error";
								$message['info'] = "ถอนเงินขั้นต่ำ " . $setwd . " บาท !";
								
							}else{
								
								if($check_list_wd > 0){
									
									$message['status'] = "error";
									$message['info'] = "ท่านมีรายถอนที่กำลังรอดำเนืนการอยู่ !";
								
								}else{
									
									

									$status5 = $this->withdraw_agent($_SESSION["UsernameUFA"],$amount_wd); 
									$status2 = json_decode($status5,true);
									$status = $status2['status'];
									
									if ($status=='success') {
										
										$withdraw_insert = $this->db->prepare("INSERT INTO withdraw (id_wd, username_wd, phone_wd, bank_wd, bankacc_wd, name_wd, lastpro, confirm_wd, pin_wd, amount_wd, add_wd) VALUES (:id_wd,:username_wd,:phone_wd,:bank_wd,:bankacc_wd,:name_wd,:lastpro,:confirm_wd,:pin_wd,:amount_wd,:add_wd)");
										
										try {
											$withdraw_insert->execute([':id_wd'=>$id_wd,':username_wd'=>$username_wd,':phone_wd'=>$phone_wd,':bank_wd'=>$bank_wd,':bankacc_wd'=>$bankacc_wd,':name_wd'=>$name_wd,':lastpro'=>$lastpro,':confirm_wd'=>'รอดำเนินการ',':pin_wd'=>'unknown6134',':amount_wd'=>$amount_wd,':add_wd'=>'MEMBER']);
											
											
											//$sMessage = "แจ้งถอนเงิน \nจำนวนเงิน ".$amount_wd." บาท\nเบอร์ ".$phone_wd." \nเลขบัญชี ".$bankacc_wd." \nธนาคาร ".$bank_wd." \nชื่อ ".$name_wd;
											//$token = $setting->linewithdraw;
											//$run_class = $this->notify_line_user($sMessage,$token);
											
											
											$message['status'] = "success";
											$message['info'] = "แจ้งถอนสำเร็จ กรุณารอทำรายการใน 3 นาที";
										} catch (Exception $e) {
											$message['status'] = "error";
											$message['info'] = $e->getmessage();
										}
										
									}else{
											$message['status'] = "error";
											$message['info'] = $e->getmessage();
									}
									
								}							
							}
							
						}
						
					}
					
				}
				
			}
			
			
			
			
			
		}
		$message['balance'] = $get_creditufa;
		
		return $message;

	}
	
	public function extract_int($str){
		
		$str = str_replace(",","",$str);
		preg_match('/[[:digit:]]+\.?[[:digit:]]*/', $str, $regs);
		
		return (doubleval($regs[0]));
		
	}
	
	public function check_list_wd(){
		
		$stmt = $this->db->prepare("SELECT  username_wd FROM withdraw  WHERE confirm_wd = 'รอดำเนินการ' AND id_wd = :id_wd ");
		$stmt->execute([':id_wd'=>$_SESSION["id_mb"]]);
		return $stmt->rowcount();
		
	}
	
	public function check_confirm_dp(){
		
		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE confirm_dp = 'อนุมัติ' AND phone_dp = :phone_dp ORDER BY id DESC");
		$stmt->execute([':phone_dp'=>$_SESSION["phone_mb"]]);
		return $stmt->rowcount();
		
	}
	
	
	
	
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////
	//รับค่า ฝาก
	public function deposit_dp($id_dp,$username_dp,$amount_dp,$phone_dp,$bank_dp,$bankacc_dp,$name_dp,$confirm_dp,$promotion_dp,$aff_dp,$note_dp,$bonus_dp,$fromTrue){
		
		
		//รอแก้
		$game_dp = "";
		
		
		//เช็ค
		$check_list_prodp = $this->check_list_prodp();
		$check_list_prodp2 = $this->check_list_prodp2($promotion_dp);
		$check_list_prodp3 = $this->check_list_prodp3($promotion_dp);
		if($check_list_prodp > 0){
			
			$message['status'] = "error";
			$message['info'] = "ท่านมีรายการฝากอยู่ 1 รายการ !";
			
		}else{
			
			if($check_list_prodp2 > 0){
				
				$message['status'] = "error";
				$message['info'] = "ท่านรับโปรโมชั่นนี้ไปแล้ว ! กรุณาเลือกโปรโมชั่นอื่น !";
				
			}else{
				
				if($check_list_prodp3 > 0){
					
					$message['status'] = "error";
					$message['info'] = "วันนี้ท่านรับโปรโมชั่นรายวันนี้ไปแล้ว ! กรุณาเลือกโปรโมชั่นอื่น";
					
				}else{
					
					$deposit_insert = $this->db->prepare("INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, game_dp, fromTrue) VALUES (:id_dp,:username_dp,:phone_dp,:bank_dp,:bankacc_dp,:name_dp,:confirm_dp,:amount_dp,:promotion_dp,:aff_dp,:note_dp,:bonus_dp,:game_dp,:fromTrue)");
									
					try {
						$deposit_insert->execute([':id_dp'=>$id_dp,':username_dp'=>$username_dp,':phone_dp'=>$phone_dp,':bank_dp'=>$bank_dp,':bankacc_dp'=>$bankacc_dp,':name_dp'=>$name_dp,':confirm_dp'=>$confirm_dp,':amount_dp'=>$amount_dp,':promotion_dp'=>$promotion_dp,':aff_dp'=>$aff_dp,':note_dp'=>$note_dp,':bonus_dp'=>$bonus_dp,':game_dp'=>$game_dp,':fromTrue'=>$fromTrue]);
						
						$message['status'] = "success";
						$message['info'] = "เลือกโปรโมชั่นเรียบร้อย กรุณาฝากเงินตามจำนวน";
					} catch (Exception $e) {
						$message['status'] = "error";
						$message['info'] = $e->getmessage();
					}
					
				}
				
			}
			
		}
		return $message;

	}
	public function check_list_prodp(){
		
		$stmt = $this->db->prepare("SELECT username_dp FROM deposit WHERE confirm_dp = 'รอดำเนินการ' AND id_dp = :id_dp AND username_dp = :username_dp");
		$stmt->execute([':id_dp'=>$_SESSION["id_mb"],':username_dp'=>$_SESSION["username_mb"]]);
		return $stmt->rowcount();
		
	}
	public function check_list_prodp2($promotion_dp){
		
		$stmt = $this->db->prepare("SELECT username_dp FROM deposit , promotion WHERE username_dp = :username_dp AND time_pro = 'รับได้ครั้งเดียว' AND promotion_dp = :promotion_dp AND confirm_dp = 'อนุมัติ' AND name_pro = :name_pro");
		$stmt->execute([':username_dp'=>$_SESSION["username_mb"],':promotion_dp'=>$promotion_dp,':name_pro'=>$promotion_dp]);
		return $stmt->rowcount();
		
	}
	public function check_list_prodp3($promotion_dp){
		
		$date = date("Y-m-d");
		$stmt = $this->db->prepare("SELECT username_dp FROM deposit , promotion WHERE username_dp = :username_dp AND promotion_dp = :promotion_dp AND time_pro = 'รับได้วันละ 1 ครั้ง' AND confirm_dp = 'อนุมัติ' AND name_pro = :name_pro AND date_dp LIKE '%$date%'");
		$stmt->execute([':username_dp'=>$_SESSION["username_mb"],':promotion_dp'=>$promotion_dp,':name_pro'=>$promotion_dp]);
		return $stmt->rowcount();
		
	}
	
	
	
	
	
	
	
	
	
	public function deposit_dp_free($id_dp,$username_dp,$amount_dp,$phone_dp,$bank_dp,$bankacc_dp,$name_dp,$confirm_dp,$promotion_dp,$aff_dp,$note_dp,$bonus_dp,$turnover,$bankin_dp,$ip_dp){
		
		$check_deposit_free1 = $this->check_deposit_free1($promotion_dp);
		$check_deposit_free2 = $this->check_deposit_free2();
		$check_deposit_free3 = $this->check_deposit_free3($promotion_dp);
		$check_deposit_free4 = $this->check_deposit_free4();
		$load_activity = $class->load_activity();
		
		$amount = $load_activity->credit_at;
		$numat = $load_activity->amount_at;
		 if($check_deposit_free1 > 0){
			 
			 $message['status'] = "error";
			 $message['info'] = "ท่านรับเครดิตฟรีไปแล้ว !";
			 
		 }else{
			 
			 if ($load_activity->status_at != 'เปิด') {
				 
				 $message['status'] = "error";
				 $message['info'] = "กิจกรรมปิดอยู่ ไม่สามารถรับได้ !";
				 
			 }else{
				 
				 if ($check_deposit_free4 >= $numat) {
				 
					 $message['status'] = "error";
					 $message['info'] = "วันนี้แจกเครดิตฟรีครบแล้ว กรุณามารับใหม่นะคะ !";
				 
				 }else{
					 
					 if($check_deposit_free2 > 0){
						 
						 $message['status'] = "error";
						 $message['info'] = "รายการของท่าน รออนุมัติอยู่ !";
					 
					 }else{
						 
						 if($check_deposit_free3 > 0){
							 
							 $message['status'] = "error";
							 $message['info'] = "ไอพีนี้รับเครดิตฟรีไปแล้ว ! รับอีกไม่ได้"; 
							 
						 }else{
							 
							 $status5 = $this->deposit_agent($_SESSION["UsernameUFA"],$amount); 
							 $status55 = json_decode($status5);
							 $status = $status55->status;
							 
							 if ($status=='success'){
								 
								 
								 $deposit_insert_free = $this->db->prepare("INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, turnover, bankin_dp, ip_dp) VALUES (:id_dp,:username_dp,:phone_dp,:bank_dp,:bankacc_dp,:name_dp,:confirm_dp,:amount_dp,:promotion_dp,:aff_dp,:note_dp,:bonus_dp,:turnover,:bankin_dp,:ip_dp)");
									
								 try {
									$deposit_insert_free->execute([':id_dp'=>$id_dp,':username_dp'=>$username_dp,':phone_dp'=>$phone_dp,':bank_dp'=>$bank_dp,':bankacc_dp'=>$bankacc_dp,':name_dp'=>$name_dp,':confirm_dp'=>$confirm_dp,':amount_dp'=>$amount_dp,':promotion_dp'=>$promotion_dp,':aff_dp'=>$aff_dp,':note_dp'=>$note_dp,':bonus_dp'=>$bonus_dp,':turnover'=>$turnover,':bankin_dp'=>$bankin_dp,':ip_dp'=>$ip_dp]);
									
									$message['status'] = "success";
									$message['info'] = "รับเครดิตฟรีสำเร็จ";
								 } catch (Exception $e) {
									$message['status'] = "error";
									$message['info'] = $e->getmessage();
								 }
								 
							 }
							 
						 }
						 
					 }
					 
				 }
				 
			 }
			 
		 }
		
		return $message;
	}
	
	
	public function check_deposit_free1($promotion_dp){
		
		$stmt = $this->db->prepare("SELECT phone_dp FROM deposit WHERE phone_dp = :phone_dp AND promotion_dp = :promotion_dp AND amount_dp = 'กิจกรรม' AND confirm_dp = 'อนุมัติ' ");
		$stmt->execute([':phone_dp'=>$_SESSION["phone_mb"],':promotion_dp'=>$promotion_dp]);
		return $stmt->rowcount();
		
	}
	public function check_deposit_free2(){
		
		$stmt = $this->db->prepare("SELECT username_dp FROM deposit WHERE confirm_dp = 'รอดำเนินการ' AND id_dp = :id_dp AND username_dp = :username_dp");
		$stmt->execute([':id_dp'=>$_SESSION["id_mb"],':username_dp'=>$_SESSION["username_mb"]]);
		return $stmt->rowcount();
		
	}
	public function check_deposit_free3($promotion_dp){
		
		$stmt = $this->db->prepare("SELECT phone_dp FROM deposit WHERE ip_dp = :ip_dp AND promotion_dp = :promotion_dp AND amount_dp = 'กิจกรรม'");
		$stmt->execute([':ip_dp'=>$_SESSION["ip"],':promotion_dp'=>$promotion_dp]);
		return $stmt->rowcount();
		
	}
	
	public function check_deposit_free4(){
		
		$stmt = $this->db->prepare("SELECT * FROM deposit WHERE confirm_dp = 'อนุมัติ' AND amount_dp='กิจกรรม'");
		$stmt->execute();
		return $stmt->rowcount();
		
	}
	
	
	
	public function load_activity(){
		
		$stmt = $this->db->prepare("SELECT * FROM activity ORDER BY id DESC LIMIT 1");

		$stmt->execute();

		return $stmt->fetch();
		
	}
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	public function withdraw_cashback($amount,$id_cb,$username_cb,$bank_cb,$bankacc_cb,$name_cb,$phone_cb,$confirm_cb){
		
		$load_setting = $this->load_db_setting();
		$check_withdraw_cashback_1 = $this->check_withdraw_cashback_1();
		$winlose = $this->turnoveryu_agent();
		$winlose2 = $winlose*-$load_setting->cashback/100;
		
		
		if ($winlose2<=0) {
			
			$message['status'] = "error";
			$message['info'] = "ท่านไม่ได้รับยอดเสีย";
			
		}else{
			
			if($check_withdraw_cashback_1 > 0){
				
				$message['status'] = "error";
				$message['info'] = "ท่านทำรายการนี้ไปแล้ว";
				
			}else{
				
				$status1 = $this->deposit_agent($_SESSION["UsernameUFA"],$winlose2); 
				$status2 = json_decode($status1);
				$status = $status2->status;
				
				if ($status=='success') {
					
					$withdraw_cashback_insert = $this->db->prepare("INSERT INTO withdraw (id_wd, username_wd, phone_wd, bank_wd, bankacc_wd, name_wd, confirm_wd, amount_cashback, bankout_wd) VALUES 
					(:id_wd, :username_wd, :phone_wd, :bank_wd, :bankacc_wd,:name_wd, 'อนุมัติ', :winlose2, 'คืนยอดเสีย')");
									
					try {
						
						$withdraw_cashback_insert->execute([':id_wd'=>$id_cb,':username_wd'=>$username_cb,':phone_wd'=>$phone_cb,':bank_wd'=>$bank_cb,':bankacc_wd'=>$bankacc_cb,':name_wd'=>$name_cb,':winlose2'=>$winlose2]);
									
						$message['status'] = "success";
						$message['info'] = "รับยอดเสียสำเร็จ";
						
					} catch (Exception $e) {
						$message['status'] = "error";
						$message['info'] = $e->getmessage();
					}
					
					
				}
				
				
			}
			
			
			
		}

		return $message;
	}
	
	public function check_withdraw_cashback_1(){
		
		$month_wd = date('Y-m-d');
		$stmt = $this->db->prepare("SELECT phone_wd FROM withdraw WHERE phone_wd = :phone_wd AND amount_cashback != '' AND date_wd LIKE :month_wd ");
		$stmt->execute([':phone_wd'=>$_SESSION["phone_mb"],':month_wd'=>'%'.$month_wd.'%']);
		
		return $stmt->rowcount();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function withdraw_aff($id_aff,$username_aff,$bank_aff,$phone_aff,$bankacc_aff,$name_aff,$confirm_aff){
		
		$check_withdraw_aff_1 = $this->check_withdraw_aff_1();
		$check_withdraw_aff_2 = $this->check_withdraw_aff_2();
		
		if ($check_withdraw_aff_1 == 0) {
			
			$message['status'] = "error";
			$message['info'] = "ยอดเงินไม่เพียงพอ";
			
		}else{
			
			if($check_withdraw_aff_2 > 0){
				
				$message['status'] = "error";
				$message['info'] = "ท่านทำรายการนี้ไปแล้ว";
				
			}else{
				
				$withdraw_aff_insert = $this->db->prepare("INSERT INTO withdrawaff (id_aff, username_aff, phone_aff, bank_aff, bankacc_aff, name_aff, confirm_aff, amount_aff) VALUES (:id_aff, :username_aff, :phone_aff, :bank_aff, :bankacc_aff,:name_aff, 'อนุมัติ', :amount)");
									
				try {
					$withdraw_aff_insert->execute([':id_aff'=>$id_aff,':username_aff'=>$username_aff,':phone_aff'=>$phone_aff,':bank_aff'=>$bank_aff,':bankacc_aff'=>$bankacc_aff,':name_aff'=>$name_aff,':amount'=>$check_withdraw_aff_1]);
									
					$message['status'] = "success";
					$message['info'] = "รับยอดแนะนำเพื่อน เรียบร้อย";
					
				} catch (Exception $e) {
					$message['status'] = "error";
					$message['info'] = $e->getmessage();
				}
				
				
			}
			
			
		}

		return $message;
	}
	
	public function check_withdraw_aff_1(){
		
		$load_setting = $this->load_db_setting();

		date_default_timezone_set('asia/bangkok');
		$month_dp = date('Y-m',strtotime('-1 month')) ;
		
		$stmt = $this->db->prepare("SELECT SUM(amount_dp) FROM deposit WHERE confirm_dp = 'อนุมัติ' AND aff_dp = :aff5 AND date_dp LIKE :month_dp AND amount_dp != :amount_dp");
		$stmt->execute([':aff5'=>$_SESSION["username_mb"],':month_dp'=>'%'.$month_dp.'%',':amount_dp'=>'กิจกรรม']);
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))  {
			$amount = $row['SUM(amount_dp)'] * $load_setting->affcashback / 100;
		}
		
		$_SESSION["amount_aff"] = $amount;
		
		return $amount;
		
	}
	
	public function check_withdraw_aff_2(){
		
		$month_aff = date('Y-m');
		$stmt = $this->db->prepare("SELECT phone_aff FROM withdrawaff WHERE phone_aff = :phone_aff AND date_aff LIKE :month_aff ");
		$stmt->execute([':phone_aff'=>$_SESSION["phone_mb"],':month_aff'=>'%'.$month_aff.'%']);
		return $stmt->rowcount();
		
	}
	
	public function check_withdraw_aff_3(){
		
		$load_setting = $this->load_db_setting();

		date_default_timezone_set('asia/bangkok');
		$month_dp = date('Y-m') ;
		
		$stmt = $this->db->prepare("SELECT SUM(amount_dp) FROM deposit WHERE confirm_dp = 'อนุมัติ' AND aff_dp = :aff5 AND date_dp LIKE :month_dp AND amount_dp != :amount_dp");
		$stmt->execute([':aff5'=>$_SESSION["username_mb"],':month_dp'=>'%'.$month_dp.'%',':amount_dp'=>'กิจกรรม']);
		
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))  {
			$amount = $row['SUM(amount_dp)'] * $load_setting->affcashback / 100;
		}
		
		
		return $amount;
		
	}
	
	
	public function check_withdraw_aff_4(){
		
		$stmt = $this->db->prepare("SELECT * FROM member WHERE aff = :aff5 ");
		$stmt->execute([':aff5'=>$_SESSION["username_mb"]]);
		
		return $stmt->rowcount();
		
	}
	
	
	//ยอดฝากรวมทั้งหมด
	public function Check_Deposit_All(){
		
		$stmt = $this->db->prepare("SELECT SUM(amount_dp) FROM deposit WHERE confirm_dp = 'อนุมัติ' AND phone_dp = :phone_dp AND amount_dp != :amount_dp");
		$stmt->execute([':phone_dp'=>$_SESSION["phone_mb"],':amount_dp'=>'กิจกรรม']);
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))  {
			$amount = $row['SUM(amount_dp)'];
		}
		
		if(empty($amount)) {
			$_SESSION["Deposit_All"] = 0;
			return 0;
		}else{
			$_SESSION["Deposit_All"] = $amount;
			return $amount;
		}
		
	}
	
	//ยอดถอนรวมทั้งหมด
	public function Check_Withdraw_All(){
		
		$stmt = $this->db->prepare("SELECT SUM(amount_wd) FROM withdraw WHERE confirm_wd = 'อนุมัติ' AND phone_wd = :phone_wd");
		$stmt->execute([':phone_wd'=>$_SESSION["phone_mb"]]);
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC))  {
			$amount = $row['SUM(amount_wd)'];
		}
		
		if(empty($amount)) {
			$_SESSION["Withdraw_All"] = 0;
			return 0;
		}else{
			$_SESSION["Withdraw_All"] = $amount;
			return $amount;
		}
		
	}
	

	
	
	
	//ดึงประวิติลิงค์รับทรัพย์
	public function withdraw_aff_history(){

		$stmt = $this->db->prepare("SELECT * FROM withdrawaff WHERE id_aff = :id_mb ORDER BY id DESC limit 5");
		
		$stmt->execute([':id_mb'=>$_SESSION["id_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	
	//ดึงประวัติรับยอดเสีย
	public function withdraw_history(){

		$stmt = $this->db->prepare("SELECT * FROM withdraw WHERE id_wd = :id_mb AND amount_cashback!='' ORDER BY id DESC limit 10");
		
		$stmt->execute([':id_mb'=>$_SESSION["id_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	
	public function code_reward_history(){

		$stmt = $this->db->prepare("SELECT * FROM code_reward WHERE phone = :phone ORDER BY id DESC limit 10");
		
		$stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	public function change_credit($id,$username,$phone){
		
		$profile = $this->showprofile();
		$load_setting = $this->load_db_setting();
		

		$point = $profile->point;
		$total1 = $point*$load_setting->change_point;
		
		
		if ($point<=0) {
			
			$message['status'] = "error";
			$message['info'] = "ยอดเงินไม่เพียงพอ";
			
		}else{
			
			$status1= $this->deposit_agent($_SESSION["UsernameUFA"],$total1); 
			$status2 = json_decode($status1);
			$status = $status2->status;
			
			if ($status=='success') {
				
				
				$update_change_credit = $this->db->prepare("UPDATE member SET point = 0 WHERE username_mb = :username");
				$update_change_credit->execute([':username' => $username]);
				
				
				$change_credit_insert = $this->db->prepare("INSERT INTO changepoint (id_change, username, phone, name, amount, confirm_change) VALUES (:id, :username, :phone, :name, :point, 'อนุมัติ')");
									
				try {
					$change_credit_insert->execute([':id'=>$id,':username'=>$username,':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':point'=>$point]);
									
					$message['status'] = "success";
					$message['info'] = "แลกรางวัลสำเร็จ";
					
				} catch (Exception $e) {
					
					$message['status'] = "error";
					$message['info'] = $e->getmessage();
				}
				
				
				
				
			}else{
				
				
				
			}
			
		}
		
		return $message;

	}

	
	public function GetDiamond(){
  
	  date_default_timezone_set("Asia/Bangkok");
	  
	  $start_date = date('Y-m-d');
	  $stmt = $this->db->prepare("SELECT * FROM history_diamond WHERE phone = :phone AND date_time LIKE '%$start_date%' ORDER BY id DESC limit 1");
	  $stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
	  
	  $GetReward = rand(1,5);
	  
	  if ($stmt->rowcount() > 0) {
	   
	   $result = $stmt->fetch();
	   
	   if($result->date_time > $start_date){
		$message['status'] = "error";
		$message['status1'] = $result->date_time;
		$message['status2'] = $start_date;
	   }else{
		$message['status'] = "success";
		$message['diamond'] = $_SESSION["diamond"] + $GetReward;
		$message['RewardDiamond'] = $GetReward;
		$this->GetDiamond_INSERT($GetReward);
	   }
	   
	  } else {
	   
	   $message['status'] = "success";
	   $message['diamond'] = $_SESSION["diamond"] + $GetReward;
	   $message['RewardDiamond'] = $GetReward;
	   $this->GetDiamond_INSERT($GetReward);
	  }
	  
	  
	  return $message;
	 }
	
	public function GetDiamond_INSERT($GetReward){
		
		date_default_timezone_set("Asia/Bangkok");
		$Today = date("Y-m-d H:i:s");
		
		$Diamond_Insert = $this->db->prepare("INSERT INTO history_diamond (reward, username, phone, name, date_time) VALUES (:reward,:username,:phone,:name,:date_time)");
		
		$Diamond_Insert->execute([':reward'=>$GetReward,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':date_time'=>$Today]);
		
		$update_diamond = $this->db->prepare("UPDATE member SET diamond = diamond + :diamond WHERE phone_mb = :phone_mb");
		$update_diamond->execute([':diamond'=>$GetReward,':phone_mb'=>$_SESSION["phone_mb"]]);
		
		$_SESSION["diamond"] = $_SESSION["diamond"] + $GetReward;
		
	}
	
	public function Diamond_History(){

		$stmt = $this->db->prepare("SELECT * FROM history_diamond WHERE phone = :phone ORDER BY id DESC limit 10");
		
		$stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	public function history_Change_Diamond(){
		
		$stmt = $this->db->prepare("SELECT * FROM change_diamond WHERE phone = :phone ORDER BY id DESC limit 10");
		
		$stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	public function Change_Diamond(){
		
		date_default_timezone_set("Asia/Bangkok");
		$Today = date("Y-m-d H:i:s");

		$stmt = $this->db->prepare("SELECT * FROM member WHERE phone_mb = :phone_mb");
		
		$stmt->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
		
		$result = $stmt->fetch();
		
		if($result->diamond <= 0) {
			
			$message['status'] = "error";
			$message['info'] = "คุณไม่มี เพชร";
			
		}else{
			
			$load_setting = $this->load_db_setting();
			$values = $result->diamond * $load_setting->change_diamond;
			
			
			
			$api_deposit_agent = $this->deposit_agent($_SESSION["UsernameUFA"],$values);
			if (empty($api_deposit_agent)) {
				$status_deposit_agent = "error";
			}else{
				$data_deposit = json_decode($api_deposit_agent);
				$status_deposit_agent = $data_deposit->status;
			}
			
			
			
			if ($status_deposit_agent=='success') {
				
				

				$update_diamond = $this->db->prepare("UPDATE member SET diamond = '0' WHERE phone_mb = :phone_mb");
				
				$change_diamond_insert = $this->db->prepare("INSERT INTO change_diamond (amount, phone, name, username, date_change) VALUES (:amount,:phone,:name,:username,:date_change)");
				
				
				
				try {
					
					$New_Balance = $_SESSION["Balance"] + $values;
					$message['status'] = "success";
					$message['info'] = $New_Balance;
					$_SESSION["diamond"] = "0";
					$_SESSION["Balance"] = $New_Balance;
					
					$update_diamond->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
					
					$change_diamond_insert->execute([':amount'=>$values,':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':username'=>$_SESSION["username_mb"],':date_change'=>$Today]);
								
				} catch (Exception $e) {
					
					$message['status'] = "error";
					$message['info'] = "มีบางอย่างผิดพลาด";

				}
				
			}else{
					
				$message['status'] = "error";
				$message['info'] = "กรุณาลองใหม่อีกครั้ง";
					
			}
				
		}
		
		return $message;
	}
	
	
	
	
	
	public function code_reward_test($code_id){
		
		$chcode = $this->db->prepare("SELECT * FROM code_reward WHERE code = :code AND status <=> null");
		$chcode->execute([':code'=>$code_id]);
		return $code_id;
	}
	
	
	public function code_reward($code_id){
		
		$chcode = $this->db->prepare("SELECT * FROM code_reward WHERE code = :code AND phone = ''");
		$chcode->execute([':code'=>$code_id]);
		if ($chcode->rowcount() > 0) {
				
				$resultcode = $chcode->fetch();
				$result_reward = $resultcode->reward;
				$result_turnover = $resultcode->turnover;
				
				$api_deposit_agent = $this->deposit_agent($_SESSION["UsernameUFA"],$result_reward);
				
				if (empty($api_deposit_agent)) {
					$status_deposit_agent = "error";
				}else{
					$data_deposit = json_decode($api_deposit_agent);
					$status_deposit_agent = $data_deposit->status;
				}

				
				
				if ($status_deposit_agent=='success') {

					$message['status'] = "success";
					$message['info'] = "คุณได้รับ " . $result_reward . " เครดิต";
					
					$update_code = $this->db->prepare("UPDATE code_reward SET status = :status , phone = :phone WHERE code = :code");
					$update_code->execute([':status'=>'สำเร็จ',':phone'=>$_SESSION["phone_mb"],':code'=>$code_id]);
					
					$this->deposit_dp_code($result_reward,$result_turnover);
				
				}else{
					
					$message['status'] = "error";
					$message['info'] = "กรุณาลองใหม่อีกครั้ง";
					
				}
			
			
		}else{
			
			$message['status'] = "error";
			$message['info'] = "โค้ดไม่ถูกต้อง";
			
		}
		
		return $message;
		
	}
	
	
	
	
	public function deposit_dp_code($reward,$turnover){
		
		
		$deposit_code_insert = $this->db->prepare("INSERT INTO deposit (id_dp, username_dp, phone_dp, bank_dp, bankacc_dp, name_dp, confirm_dp, amount_dp, promotion_dp, aff_dp, note_dp, bonus_dp, turnover, fromTrue) VALUES (:id_dp,:username_dp,:phone_dp,:bank_dp,:bankacc_dp,:name_dp,:confirm_dp,:amount_dp,:promotion_dp,:aff_dp,:note_dp,:bonus_dp,:turnover,:fromTrue)");
									
		try {
			$deposit_code_insert->execute([':id_dp'=>$_SESSION["id_mb"],':username_dp'=>$_SESSION["username_mb"],':phone_dp'=>$_SESSION["phone_mb"],':bank_dp'=>$_SESSION["bank_mb"],':bankacc_dp'=>$_SESSION["bankacc_mb"],':name_dp'=>$_SESSION["name_mb"],':confirm_dp'=>'อนุมัติ',':amount_dp'=>'กรอกโค้ด',':promotion_dp'=>'กรอกโค้ด',':aff_dp'=>$_SESSION["aff"],':note_dp'=>'',':bonus_dp'=>$reward,':turnover'=>$turnover,':fromTrue'=>'']);
						
		} catch (Exception $e) {

		}
		
		
	}
	
	
	
	
	public function w_rand($samples, $weights){
		
		if ( count($samples) != count($weights) ) 
		{
			return null; 
		}
		$sum 	= array_sum($weights) * 100;  
		$rand 	= mt_rand(1, $sum);  
		foreach ($weights as $i=>$w) 
		{  
			$weights[$i] = $w * 100 + ( $i > 0 ? $weights[$i-1] : 0 );  
			if ( $rand <= $weights[$i] ) { return $samples[$i]; }  
		}  
	}
	
	public function spinner(){
		
		date_default_timezone_set("Asia/Bangkok");
		$Today = date("Y-m-d H:i:s");
		$load_setting = $this->load_db_setting();

		$weights = array($load_setting->Change1,$load_setting->Change2,$load_setting->Change3,$load_setting->Change4,$load_setting->Change5,$load_setting->Change6,$load_setting->Change7,$load_setting->Change8);
		$samples = array(1,3,4,5,7,8,2,6);
		$response_Random = $this->w_rand($samples, $weights);
		$message['response'] = $response_Random;
		
		$profile = $this->showprofile();
		
		if ($profile->creditspin <= 0) {
			$message['status'] = "No_Creditspin";
			$message['message'] = 'สิทธิ์การหมุนไม่พอ';
		}else{
			$message['status'] = "success";
			
			$history_insert = $this->db->prepare("INSERT INTO history_spin (reward,username,phone,name,time) VALUES (:reward,:username,:phone,:name,:time)");
			$update_success = $this->db->prepare("UPDATE member SET point = point + :point , creditspin = creditspin -1 WHERE phone_mb = :phone_mb");
			$update_fall = $this->db->prepare("UPDATE member SET creditspin = creditspin -1 WHERE phone_mb = :phone_mb");
			
			if ($response_Random == 1){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward1 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward1,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward1,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 2){
				$message['message'] = 'เสียใจด้วยคุณไม่ได้รางวัล';
				$history_insert->execute([':reward'=>'ไม่ได้รับรางวัล',':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_fall->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 3){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward2 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward2,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward2,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 4){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward3 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward3,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward3,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 5){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward4 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward4,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward4,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 6){
				$message['message'] = 'เสียใจด้วยคุณไม่ได้รางวัล';
				$history_insert->execute([':reward'=>'ไม่ได้รับรางวัล',':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_fall->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 7){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward5 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward5,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward5,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			if ($response_Random == 8){
				$message['message'] = 'ยินดีด้วยคุณได้ '. $load_setting->reward6 . ' พ้อยด์';
				$history_insert->execute([':reward'=>$load_setting->reward6,':username'=>$_SESSION["username_mb"],':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':time'=>$Today]);
				$update_success->execute([':point'=>$load_setting->reward6,':phone_mb'=>$_SESSION["phone_mb"]]);
			}
			
			
			$new_profile = $this->showprofile();
			$_SESSION['creditspin'] = $new_profile->creditspin;
			$message['Credit'] = $_SESSION['creditspin'];
			$_SESSION['point'] = $new_profile->point;
			$message['Point'] = $_SESSION['point'];
			
			
		}
		
		$dete_call = json_encode($message);
		$encrypted = CryptoJsAes::encrypt($dete_call, "Asadayut");
		return $encrypted;
		//return $message;
		
	}
	
	public function spinner_history(){

		$stmt = $this->db->prepare("SELECT * FROM history_spin WHERE phone = :phone ORDER BY id DESC limit 10");
		
		$stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	public function history_change_spinner(){
		
		$stmt = $this->db->prepare("SELECT * FROM change_spinner WHERE phone = :phone ORDER BY id DESC limit 10");
		
		$stmt->execute([':phone'=>$_SESSION["phone_mb"]]);
		
		if ($stmt->rowcount() > 0) {
			while ($row = $stmt->fetch()) {
				$result[] = $row;
			}
			return $result;
		} else {
			return 0;
		}
		
	}
	
	
	public function Change_Spinner(){
		
		date_default_timezone_set("Asia/Bangkok");
		$Today = date("Y-m-d H:i:s");

		$stmt = $this->db->prepare("SELECT * FROM member WHERE phone_mb = :phone_mb");
		
		$stmt->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
		
		$result = $stmt->fetch();
		
		if($result->point <= 0) {
			
			$message['status'] = "error";
			$message['info'] = "คุณไม่มี พ้อยด์";
			
		}else{
			
			$load_setting = $this->load_db_setting();
			$values = $result->point * $load_setting->change_point;
			
			
			
			$api_deposit_agent = $this->deposit_agent($_SESSION["UsernameUFA"],$values);
			if (empty($api_deposit_agent)) {
				$status_deposit_agent = "error";
			}else{
				$data_deposit = json_decode($api_deposit_agent);
				$status_deposit_agent = $data_deposit->status;
			}
			
			
			if ($status_deposit_agent=='success') {
				
				

				$update_point = $this->db->prepare("UPDATE member SET point = '0' WHERE phone_mb = :phone_mb");
				
				$change_spinner_insert = $this->db->prepare("INSERT INTO change_spinner (amount, phone, name, username, date_change) VALUES (:amount,:phone,:name,:username,:date_change)");
				
				
				
				try {
					
					$New_Balance = $_SESSION["Balance"] + $values;
					$message['status'] = "success";
					$message['info'] = $New_Balance;
					$_SESSION["point"] = "0";
					$_SESSION["Balance"] = $New_Balance;
					
					$update_point->execute([':phone_mb'=>$_SESSION["phone_mb"]]);
					
					$change_spinner_insert->execute([':amount'=>$values,':phone'=>$_SESSION["phone_mb"],':name'=>$_SESSION["name_mb"],':username'=>$_SESSION["username_mb"],':date_change'=>$Today]);
								
				} catch (Exception $e) {
					
					$message['status'] = "error";
					$message['info'] = "มีบางอย่างผิดพลาด";

				}
				
			}else{
					
				$message['status'] = "error";
				$message['info'] = "กรุณาลองใหม่อีกครั้ง";
					
			}
				
		}
		
		return $message;
	}
	
	
	
	
	
	
	
	
	
	
	
	public function load_my_sqli(){
		
		$my_con = mysqli_connect("localhost","root","","rukbetna_369") or die("Error: " . mysqli_error($my_con));
		mysqli_query($my_con, "SET NAMES 'utf8' ");
		
		return $my_con;
		
	}
	
	
	public function notify_line_user($message,$token){
		define('LINE_API',"https://notify-api.line.me/api/notify");
		 $queryData = array(
		  'message' => $message
		 );
		 $queryData = http_build_query($queryData,'','&');
		 $headerOptions = array(
			'http'=>array(
				'method'=>'POST',
				'header'=> "Content-Type: application/x-www-form-urlencoded\r\n"
					."Authorization: Bearer ".$token."\r\n"
					."Content-Length: ".strlen($queryData)."\r\n",
				'content' => $queryData
			),
		);
		$context = stream_context_create($headerOptions);
		$result = file_get_contents(LINE_API,FALSE,$context);
		$res = json_decode($result);
		return $res;
	}
	
	
	
	
	
	
	public function update_time_refresh($time){

		$_SESSION["savetime"] = $time;
		
		return $_SESSION["savetime"];
		
	}
	


	public function json_error($text){

		$message['status'] = "error";

		$message['info'] = $text;

		return json_encode($message);

	}

	public function json_success($text){

		$message['status'] = "success";

		$message['info'] = $text;

		return json_encode($message);

	}

}

?>