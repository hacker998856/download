<?php
require_once 'config.db.php';
class KBankClass
{
	private $endpoint;
    public function __construct()
    {
		$Apiendpoint = new ConfigDB_Class();
        $this->endpoint = $Apiendpoint->ENDPOINT;
    }
	
	public function getBalance()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://' . $this->endpoint . '/balance');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //ดึงรายการ
    public function getTransactions()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://' . $this->endpoint . '/activities');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //ดึงรายการ เจาะจง
    public function getTransactionDetail($rqUid)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://' . $this->endpoint . '/activity-detail/' . $rqUid);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return array();
        }
        return json_decode($result, true);
    }

    //ตรวจสอบผู้รับก่อนโอนเงิน
    public function transferVerify($toBankCode, $toAccount, $amount)
    {
        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://' . $this->endpoint . '/inquire-for-transfer-money/');
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'toBankCode=' . $toBankCode . '&toAccount=' . $toAccount . '&amount=' . $amount . '');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        
        $result = curl_exec($ch);
        $data =  json_decode($result, true);
        if (curl_errno($ch)) {
            return ['status' => false, 'msg' => $data];
        }
        return $data;
    }

    //ยืนยันโอนเงิน
   

    public function transferConfrim78($kbankInternalSessionId)
    {
        $headers = array();
        $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://' . $this->endpoint . '/transfer-money78/' . $kbankInternalSessionId);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return json_decode($result, true);
        }
        curl_close($ch);
        return json_decode($result, true);
    }

}
