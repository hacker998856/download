<?php
class ConfigDB_Class {
    public $DB_HOST = "localhost"; 
    public $DB_USER = "hibetcas_hc";
    public $DB_PASS = "YHozp4fNe";
	public $DB_NAME = "hibetcas_hc";
	public $ENDPOINT = "141.98.17.72:10022";
}
?>