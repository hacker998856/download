<?php
if(isset($_SESSION['id_ad'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>ระบบหลังบ้าน</title>
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script><!-- v4.0.0-alpha.6 -->
<link rel="stylesheet" href="/assets/admin/bootstrap/css/bootstrap.min.css">
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
<!-- Theme style -->
<link rel="stylesheet" href="/assets/admin/font-awesome-pro-5.15.4/css/all.css">
<!--<link rel="stylesheet" href="/assets/admin/css/font-awesome/css/font-awesome.min.css">-->
<link rel="stylesheet" href="/assets/admin/css/style.css">
<link rel="stylesheet" href="/assets/admin/css/et-line-font/et-line-font.css">
<link rel="stylesheet" href="/assets/admin/css/themify-icons/themify-icons.css">
<!-- Font Awesome fas fa icon -->

<!-- DataTables -->
<link rel="stylesheet" href="/assets/admin/plugins/bootstrap-switch/bootstrap-switch1.css">

<!-- dropify -->
<link rel="stylesheet" href="/assets/admin/plugins/dropify/dropify.min.css">

<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.4/jquery.datetimepicker.min.css" />

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.all.min.js"></script>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php
			$sql = "SELECT * FROM setting";
			$result = $class_admin->load_date_sql($sql);
			$row = mysqli_fetch_array($result);
			$logo = $row['logo_web'];
			
		?>

<div class="wrapper boxed-wrapper">
<header class="main-header">
	<a href="/admin" class="logo blue-bg"><span class="logo-mini"><img src="<?php echo $logo; ?>" width="120" height="50" alt=""></span> <span class="logo-lg"><img src="<?php echo $logo; ?>" width="120" height="50" alt=""></span> </a>
	<nav class="navbar blue-bg navbar-static-top">
		<ul class="nav navbar-nav pull-left justify-content-between align-items-center">
			<li>
				<a class="sidebar-toggle" data-toggle="push-menu" href=""> <i class="fas fa-bars"></i></a>
			</li>
		</ul>
		
		
		<?php
			$statuskbank = "SELECT * FROM bank WHERE name_bank = 'ธนาคารกสิกรไทย'";
			$load_status_kbank = $class_admin->load_date_sql($statuskbank);
			$num_status_kbank = mysqli_num_rows($load_status_kbank);
			if($num_status_kbank > 0){
		?>
		<div class="nav navbar-nav pull-left pr-1">
		<img src="/assets/img/bank_logo/KPlus.png" class="img-circle img-w-30 mt-3" alt="User Image">
		<div class="notify position-sticky" style="top: -18px; right: 0;" id="status_bank_kbank">

		</div>
		</div>
		<?php } ?>
		
		<?php
			$statusscb = "SELECT * FROM bank WHERE name_bank = 'ธนาคารไทยพาณิชย์'";
			$load_status_scb = $class_admin->load_date_sql($statusscb);
			$num_status_scb = mysqli_num_rows($load_status_scb);
			if($num_status_scb > 0){
		?>
		<div class="nav navbar-nav pull-left pr-1">
		<img src="/assets/img/bank_logo/scb.png" class="img-circle img-w-30 mt-3" alt="User Image">
		<div class="notify position-sticky" style="top: -18px; right: 0;" id="status_bank_scb">
			
		</div>
		</div>
		<?php } ?>
		
		<?php
			$statustruewallet = "SELECT * FROM bank WHERE name_bank = 'ทรูวอเล็ต'";
			$load_status_truewallet = $class_admin->load_date_sql($statustruewallet);
			$num_status_truewallet = mysqli_num_rows($load_status_truewallet);
			if($num_status_truewallet > 0){
		?>
		<div class="nav navbar-nav pull-left pr-1">
		<img src="/assets/img/bank_logo/truemoneywallet.png" class="img-circle img-w-30 mt-3" alt="User Image">
		<div class="notify position-sticky" style="top: -18px; right: 0;" id="status_bank_truewallet">

		</div>
		</div>
		<?php } ?>
		
		
		<div class="navbar-custom-menu">
			<ul class="nav navbar-nav">
				<li class="dropdown user user-menu p-ph-res">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<img src="/assets/admin/img/administrator.png" class="user-image" style="margin-top: -5px;"" alt="User Image">
						<span class="hidden-xs"><?php echo $_SESSION["name_ad"]; ?></span>
					</a>
					<ul class="dropdown-menu">
						<li role="separator" class="divider"></li>
						<li><a href="javascript:void(0)" class="check-out"><i class="fas fa-sign-out"></i> ออกจากระบบ</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
</header>
<aside class="main-sidebar">
	<div class="sidebar">
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header">
				<div class="d-flex justify-content-between align-items-center">
				   <div class="text-success"><span class="h6">สถานะระบบออโต้</span></div>
				   <div class="">
						<div class="form-check form-switch form-switch-md pull-right-container pull-right">
							<input class="form-check-input pull-right-container" onclick='CheckedMain(this);' type="checkbox" <?php if ($Get_Setting->status_auto2 == "เปิด")  { ?> checked <?php } ?>>
						</div>
				   </div>
				</div>
			</li>
			<li class="header">
				<div class="d-flex justify-content-between align-items-center">
				   <div class="text-success"><span class="h6">สถานะถอนออโต้</span></div>
				   <div class="">
						<div class="form-check form-switch form-switch-md pull-right-container pull-right">
							<input class="form-check-input pull-right-container" onclick='CheckedMain2(this);' type="checkbox" <?php if ($Get_Setting->status_auto == "เปิด")  { ?> checked <?php } ?>>
						</div>
				   </div>
				</div>
			</li>
			<li class="treeview">
				<a href="/admin"> <i class="fas fa-tachometer-alt"></i> <span>แดชบอร์ด</span> </a>
			</li>
			<li class="treeview">
				<a href="/admin/report"> <i class="fas fa-money-check-alt"></i> <span>รายงานรายได้</span> </a>
			</li>
			<li class="treeview">
				<a href="/admin/allmember"> <i class="fas fa-users"></i> <span>สมาชิกทั้งหมด</span> </a>
			</li>
			<li class="treeview">
				<a href="javascript:void(0)"> <i class="fas fa-cogs"></i> <span>ตั้งค่า</span> <span class="pull-right-container"><i class="fas fa-chevron-left"></i></span> </a>
				<ul class="treeview-menu">
					<li><a href="/admin/settingweb">เว็บไซต์</a></li>
					<li><a href="/admin/settingapikey">APIKEY</a></li>
					<li><a href="/admin/settingspinner">วงล้อ</a></li>
					<li><a href="/admin/settingbank">ธนาคาร</a></li>
					<li><a href="/admin/settingstaff">พนักงาน</a></li>
					<li><a href="/admin/settingpromotion">โปรโมชั่น</a></li>
					<li><a href="/admin/settingannounce">ประกาศ</a></li>
				</ul>
			</li>
			<li class="treeview">
				<a href="/admin/member">
					<i class="fas fa-user-chart"></i>
					<span>สมาชิกใหม่วันนี้</span>
					<span class="pull-right-container label label-success" id="count_member">0</span>
				</a>
			</li>
			<li class="treeview">
				<a href="/admin/deposit">
					<i style="font-size: 17px; padding-left: 2px;" class="fas fa-clipboard-list"></i>
					<span>ฝากมือ / กดรับโปร</span>
					<span class="pull-right-container label label-success" id="count_deposit">0</span>
				</a>
			</li>
			
			<li class="treeview">
				<a href="/admin/withdraw">
					<i style="font-size: 17px; padding-left: 2px;" class="fas fa-clipboard-list"></i>
					<span>รายการถอน</span>
					<span class="pull-right-container label label-success" id="count_withdraw">0</span>
				</a>
			</li>
			<li class="treeview">
				<a href="/admin/withdrawaff">
					<i class="fas fa-money-check-edit-alt"></i>
					<span>ถอนแนะนำเพื่อน</span>
					<span class="pull-right-container label label-success" id="count_withdrawaff">0</span>
				</a>
			</li>
			<li class="treeview">
				<a href="/admin/generatecode"> <i style="font-size: 17px; padding-left: 2px;" class="fas fa-clipboard-list"></i> <span>รายการโค้ด</span> </a>
			</li>
			<li class="treeview">
				<a href="javascript:void(0)"> <i class="fas fa-history"></i> <span>ประวัติ</span> <span class="pull-right-container"><i class="fas fa-chevron-left"></i></span> </a>
				<ul class="treeview-menu">
					<li><a href="/admin/deposit_history">รายการฝาก</a></li>
					<li><a href="/admin/withdraw_history">รายการถอน</a></li>
					<li><a href="/admin/spin_history">หมุนวงล้อ</a></li>
					<li><a href="/admin/changespin_history">แลกพ้อยด์วงล้อ</a></li>
					<li><a href="/admin/changediamond_history">รายการแลกเพชร</a></li>
				</ul>
			</li>
			<li class="treeview">
				<a href="/admin/aff_report"> <i class="fas fa-sitemap"></i> <span>แนะนำเพื่อน</span> </a>
			</li>
			<li class="treeview">
				<a href="javascript:void(0)"> <i class="fas fa-landmark"></i> <span>ประวัติธนาคาร</span> <span class="pull-right-container"><i class="fas fa-chevron-left"></i></span> </a>
				<ul class="treeview-menu">
					<li><a href="/admin/kbank_history">รายการ KBNAK</a></li>
					<li><a href="/admin/scb_history">รายการ SCB</a></li>
					<li><a href="/admin/true_history">รายการ TRUE</a></li>
				</ul>
			</li>
			<!--
			<li class="treeview">
				<a href="javascript:void(0)"> <i class="fas fa-hands-helping"></i> <span>พันธมิตร</span> </a>
			</li>
			-->
			<li class="treeview">
				<a href="javascript:void(0)" class="check-out"> <i class="fas fa-sign-out"></i> <span>ออกจากระบบ</span> </a>
			</li>
		</ul>
	</div>
</aside>

<script type="text/javascript">
function CheckedMain(checkbox) {
    if(checkbox.checked){
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:"setting",
				SET_NAME:"status_auto2",
				SET_VALUE:"เปิด",
				WHERE_NAME:"id",
				WHERE_VALUE:"1",
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
    else{
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:"setting",
				SET_NAME:"status_auto2",
				SET_VALUE:"ปิด",
				WHERE_NAME:"id",
				WHERE_VALUE:"1",
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
}
</script>
<script type="text/javascript">
function CheckedMain2(checkbox) {
    if(checkbox.checked){
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:"setting",
				SET_NAME:"status_auto",
				SET_VALUE:"เปิด",
				WHERE_NAME:"id",
				WHERE_VALUE:"1",
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
    else{
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:"setting",
				SET_NAME:"status_auto",
				SET_VALUE:"ปิด",
				WHERE_NAME:"id",
				WHERE_VALUE:"1",
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
}
</script>
<?php
}
?>