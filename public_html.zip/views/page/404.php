<?php
//echo "<script>window.location = '/'</script>";
header('Location: /');
exit;
?>