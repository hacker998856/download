<?php
if(!isset($_SESSION['id_mb'])){
	echo "<script>window.location = './home'</script>";
	exit;
}else{
	$get_profile = $class->showprofile();
	$load_withdraw_aff1 = $class->check_withdraw_aff_1();
	$load_setting = $class->load_db_setting();
}
?>

<div style="padding-top: 80px;"></div>

<div class="container mt-lg-5">
<div class="row justify-content-center align-items-center">

  <div class="profile-wallet">
    <div class="profile__picture"><img src="./assets/img/profile-wallet/wallet-profile.png" alt="ananddavis"/></div>
    <div class="profile__header">
      <div class="profile__account">
        <h4 class="profile__username"><?php echo $_SESSION["name_mb"]; ?></h4>
      </div>
    </div>
    <div class="profile__stats">
      <div class="profile__stat">
        <div class="profile__icon profile__icon--gold"><i><img src="/assets/img/coin.png" style="width:35px; height:35px;" /></i></div>
        <div class="profile__value" ><span id="id_Balance_2" ><?php echo $_SESSION["Balance"]; ?></span>
          <div class="profile__key">ยอดเงินคงเหลือ</div>
        </div>
      </div>
      <div class="profile__stat">
        <div class="profile__icon profile__icon--pink"><img src="/assets/img/item-notify/hand.png" style="width:35px; height:35px;" /></i></div>
        <div class="profile__value"><span ><?php echo $_SESSION["amount_aff"]; ?></span>
          <div class="profile__key">ยอดเงินรับทรัพย์</div>
        </div>
      </div>
    </div>
	
		<div class="profile__footer">
		  <div class="profile__footer__body">
			<input type="text" value="<?php echo "https://" . $load_setting->link_web . "/?aff=" . $_SESSION["username_mb"]; ?>" />
		  </div>
		   <a href="javascript:void(0)" class="button-copy copy-to-clipboard" data-copy="<?php echo "https://" . $load_setting->link_web . "/?aff=" . $_SESSION["username_mb"]; ?>">คัดลอก</a>
		</div>
	
</div>

<div class="cardback md-mt-2" style="display: none;">
<button class="button-backpage" id="button_back_page" role="button">
<img src="/assets/img/left.png" style="min-width: 10px; width:20px; height:20px;" />
 ย้อนกลับ
</button>
</div>
  
  
<div id="show-withdraw-deposit" class="card-dc-wallet" style="display: none;" >
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#page_deposit" role="page_deposit">ฝาก</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#page_withdraw" role="page_withdraw">ถอน</a>
		</li>
</ul>
<div class="tab-content">
	<div class="tab-pane active" id="page_deposit" role="tabpanel">
	
	<div class="row justify-content-center align-items-center mt-2">
		
		<div class="alert alert-danger text-center" style="width: 85%;" role="alert">
		  <img src="/assets/img/alert/2.png" style="min-width: 20px; width:25px; height:25px;" />
		  <strong>กรุณาใช้เลขบัญชีที่สมัครโอนเข้ามาเท่านั้น</strong>
		</div>
		
		<div class="alert alert-primary text-center" style="width: 85%;" role="alert">
		<img src="/assets/img/alert/bonus.png" style="min-width: 20px; width:45px; height:45px;" /><br>
		 <strong>หากต้องการรับโปรโมชั่น</strong><br><strong>ต้องเลือกโปรโมชั่นก่อนโอนเงินนะคะ</strong>
		</div>
		<div class="card-text" style="width: 85%;">
				<div class="form-group">
					<input type="text" class="form-control" name="id_dp" id="id_dp" value="<?php echo $get_profile->id_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="aff_dp" id="aff_dp" value="<?php echo $get_profile->aff; ?>" hidden="hide">
                    <input type="text" class="form-control" name="confirm_dp" id="confirm_dp" value="รอดำเนินการ" hidden="hide">
                    <input type="text" class="form-control" name="username_dp" id="username_dp" value="<?php echo $get_profile->username_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="phone_dp" id="phone_dp" value="<?php echo $get_profile->phone_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="bank_dp" id="bank_dp" value="<?php echo $get_profile->bank_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="bankacc_dp" id="bankacc_dp" value="<?php echo $get_profile->bankacc_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="name_dp" id="name_dp" value="<?php echo $get_profile->name_mb; ?>" hidden="hide">
                    <input type="text" class="form-control" name="fromTrue" id="fromTrue" value="<?php echo $get_profile->phone_true; ?>" hidden="hide">
                    <input type="text" class="form-control" name="amount_dp" id="amount_dp" value="รอฝาก" hidden="hide">
                    <input type="text" class="form-control" name="note_dp" id="note_dp" value="" hidden="hide">
                    <input type="text" class="form-control" name="bonus_dp" id="bonus_dp" value="" hidden="hide">
					<select name="promotion_dp" id="promotion_dp" class="custom-select">
					<option></option>
					  <?php
					  $get_check_pro = $class->check_pro();
					  $show_pro1 = $class->show_pro1();
					  $show_pro2 = $class->show_pro2();
					  if ($get_check_pro > 0) {
						  
						  foreach ($show_pro1 as  $row) {
							  echo '<option value="'.$row["name_pro"].'">'.$row["name_pro"].' '.$row["time_pro"].'</option>';
						  }
						  
					  }else{
						 
						  foreach ($show_pro2 as  $row) {
							  echo '<option value="'.$row["name_pro"].'">'.$row["name_pro"].' '.$row["time_pro"].'</option>';
						  }
						  
					  }
					  ?>
					</select>
				</div>
				<button id="submit_deposit_dp" class="button-dc-success btn-block">ยืนยัน</button>
		</div>
		
		
		
    </div>
	<div class="row d-flex justify-content-around mt-3">
	<?php ?>
<?php
$load_bank = $class->load_bank();
if ($load_bank == 0) {
	echo "NoBank";

}else{
	
foreach ($load_bank as $data) {
		
	$check_bank = $data->name_bank;
	$class_bank = "";
	if ($check_bank == "ธนาคารกสิกรไทย"){
		$class_bank = "credit-card-kplus";
		$images_bank = "/assets/img/bank_logo/KPlus.png";
	} elseif ($check_bank == "ธนาคารไทยพาณิชย์"){
		$class_bank = "credit-card-scb";
		$images_bank = "/assets/img/bank_logo/scb.png";
	} elseif ($check_bank == "ทรูวอเล็ต"){
		$class_bank = "credit-card-wallet";
		$images_bank = "/assets/img/bank_logo/truemoneywallet.png";
	} elseif ($check_bank == "ธนาคารออมสิน"){
		$class_bank = "credit-card-saving";
		$images_bank = "/assets/img/bank_logo/ธนาคารออมสิน.png";
	}else{
		$class_bank = "credit-card-general";
		$images_bank = "/assets/img/bank_logo/". $check_bank .".png";
	}
?>


			<section role="<?php echo $class_bank; ?>" style="max-width: 85%;">
					<div class="credit-card-img">
						<img style="border-radius: 100%;" src="<?php echo $images_bank;?>" />
					</div>
					
					<div class="ccBottom">
						<div class="ccValidThru">
							<label>เลขที่บัญชี</label>

							<span style="text-decoration: none !important;"><?php echo $data->bankacc_bank; ?></span>
						</div>
						<div class="ccCardHolder ">
							<button class="btn-copy copy-to-clipboard" data-copy="<?php echo $data->bankacc_bank; ?>">คัดลอก</button>
						</div>
					</div>
					<div class="ccBottom">
						<div class="ccValidThru">
							<label>ชื่อบัญชี</label>
							<span><?php echo $data->nameacc_bank; ?></span>
						</div>
						<div class="ccValidThru">
							<label>บัญชี</label>
							<span><?php echo $data->name_bank; ?></span>
						</div>
					</div>
			</section>
			
			
<?php		
}
}
?>


	</div>
	
	
	</div>
	
	<div class="tab-pane" id="page_withdraw" role="tabpanel">
	<div class="tab-dc-body2 mt-2 mb-2">
	
<?php
$get_setting = $class->load_db_setting();
$deposit_latest = $class->user_get_deposit_latest();

if (empty($deposit_latest)) {
	$show_promotion_dp = "";
}else{
	$show_promotion_dp = $deposit_latest->promotion_dp;
}

$Get_balance_agent = $class->check_balance_agent();
$Get_turnover_agent = $class->turnover_agent();
?>

<div class="alert alert-primary" style="width: 70%;" role="alert">
  ยอดเทิร์นโอเวอร์   <strong><?php echo $_SESSION["Balance"]; ?></strong> / <strong><?php if (empty($deposit_latest->turnover)) { echo "0"; }else{ echo $deposit_latest->turnover; } ?></strong>
</div>



<div class="card-text" style="width: 70%;">
				<div class="form-group text-center">
				
				
				<input type="text" class="form-control" name="lastpro" id="lastpro" value="<?php echo $show_promotion_dp; ?>" hidden="hide">
				<input type="text" class="form-control" name="id_wd" id="id_wd" value="<?php echo $get_profile->id_mb; ?>" hidden="hide">
				<input type="text" class="form-control" name="username_wd" id="username_wd" value="<?php echo $get_profile->username_mb; ?>" hidden="hide">
				<input type="text" class="form-control" name="bank_wd" id="bank_wd" value="<?php echo $get_profile->bank_mb; ?>" hidden="hide">
				<input type="text" class="form-control" name="bankacc_wd" id="bankacc_wd" value="<?php echo $get_profile->bankacc_mb; ?>" hidden="hide">
				<input type="text" class="form-control" name="name_wd" id="name_wd" value="<?php echo $get_profile->name_mb; ?>" hidden="hide">
				<input type="number" class="form-control" name="phone_wd" id="phone_wd" value="<?php echo $get_profile->phone_mb; ?>" hidden="hide">
				<input type="number" class="form-control" name="turnover_wd" id="turnover_wd" value="<?php echo $Get_turnover_agent; ?>" hidden="hide">
				<input type="text" class="form-control" name="confirm_wd" id="confirm_wd" value="รอดำเนินการ" hidden="hide">
				<input type="text" class="form-control" name="aff_wd" id="aff_wd" value="<?php echo $get_profile->aff; ?>" hidden="hide">
				<input type="text" class="form-control" name="creditufa" id="creditufa" value="<?php echo $Get_balance_agent; ?>" hidden="hide">
				<h6 class="d-inline-flex p-1 text-white bg-danger badge-pill">เงินถอนขั้นต่ำ <?php echo $get_setting->set_wd; ?></h6>
				<input type="text" class="form-control" type="text" name="amount_wd" id="amount_wd" placeholder="จำนวนเงิน">
				
				</div>
				<button type="button" id="submit_withdraw_wd" class="button-dc-success btn-block btn-block">ยืนยัน</button>
</div>






						

	</div>
	</div>
</div>


</div>





<div id="show-spinner" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" id="open-spinner2" data-toggle="tab" href="#spinner" role="spinner">หมุนวงล้อ</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#change_credit_spinnet" role="change_credit_spinnet">แลกเครดิตวงล้อ</a>
		</li>
</ul>
<div class="tab-content">
	<div class="tab-pane active" id="spinner" role="tabpanel">
	
<script type="text/javascript">
var Image1 = "<?php echo $get_setting->Image1; ?>";
var Image2 = "<?php echo $get_setting->Image2; ?>";
var Image3 = "<?php echo $get_setting->Image3; ?>";
var Image4 = "<?php echo $get_setting->Image4; ?>";
var Image5 = "<?php echo $get_setting->Image5; ?>";
var Image6 = "<?php echo $get_setting->Image6; ?>";
var Image7 = "<?php echo $get_setting->Image7; ?>";
var Image8 = "<?php echo $get_setting->Image8; ?>";
var ImageCenter = "<?php echo $get_setting->ImageCenter; ?>";
</script>	
<div class="row justify-content-center align-items-center">	
               <div class="col-12 px-4">
                  <div class="wheel-with-image"></div>
               </div>
</div>		 
<div class="row justify-content-center align-items-center mt-2">		
		<div class="col-10 col-sm-10 col-md-6 mb-5">
					<div class="alert alert-primary d-flex justify-content-around px-3">
						<strong class="">สิทธิ์หมุนวงล้อ</strong>
						<strong class="pr-3"><span id="id_CreditSpin_1"><?php echo $get_profile->creditspin; ?></span></strong>
					</div>
				  <div class="d-flex justify-content-center align-items-center">
					<button type="button" class="button-dc-success btn-block btn-block wheel-with-image-spin-button">หมุนวงล้อ</button>
				  </div>
		</div>
		
		
	
<?php
$load_history_spinner = $class->spinner_history();
if ($load_history_spinner == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_history_spinner as $data) {
	
	$status_confirm = $data->reward;
	$data_status_confirm = "";
	if ($status_confirm == "ไม่ได้รับรางวัล"){
		$data_status_confirm = "<span style='color:#bd0243;'><i class='fas fa-times'></i> ไม่ได้รับรางวัล</span>";
	}else{
		$data_status_confirm = "<span style='color:#00C851;'>". $data->reward ." พ้อยด์</span>";;
	}

	
?>
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/lucky-wheel.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">หมุนวงล้อ</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><small style='color:#00C851;'><i class='fas fa-check'></i> สำเร็จ</small></div>
					<div class="float-right align-middle font-weight-bold"><?php echo $data_status_confirm; ?></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->time; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?>


	
						
</div>
	
		
	
		
		
		
	</div>
	<div class="tab-pane" id="change_credit_spinnet" role="tabpanel">
	<div class="tab-dc-body2 mt-2 mb-2">
	
				
				<div class="alert alert-warning text-center mt-2" style="width: 85%;" role="alert">
<strong>1 พ้อยด์</strong> สามารถแลกได้  <strong><?php echo $get_setting->change_point; ?> เครดิต</strong>
		</div>
				
				
				<div class="col-12 col-sm-12 col-md-6 mb-5">
					<div class="alert alert-primary d-flex justify-content-around px-3">
						<strong class="">พ้อยด์ของท่าน</strong>
						<strong class="pr-3"><span id="id_Point_1"><?php echo $get_profile->point; ?></span></strong>
					</div>
				  <div class="d-flex justify-content-center align-items-center">
					<button type="button" id="Submit_Change_Spinner" class="button-dc-success btn-block btn-block">แลกพ้อยด์</button>
				  </div>
				</div>


	
	
	


<?php
$load_history_change_spinner = $class->history_change_spinner();
if ($load_history_change_spinner == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_history_change_spinner as $data) {
	
	//$status_confirm = $data->reward;
	//$data_status_confirm = "";
	//if ($status_confirm == "ไม่ได้รับรางวัล"){
	//	$data_status_confirm = "<span style='color:#bd0243;'><i class='fas fa-times'></i> ไม่ได้รับรางวัล</span>";
	//}else{
	//	$data_status_confirm = "<span style='color:#00C851;'><i class='fas fa-check'></i> ". $data->reward ." พ้อยด์</span>";;
	//}

	
?>
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/money.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">แลกพ้อยด์</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><small style='color:#00C851;'><i class='fas fa-check'></i> สำเร็จ</small></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'> <?php echo $data->amount; ?> พ้อยด์</span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_change; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?>




</div>
	
	
</div>
</div>
</div>











<div id="show-LinkMoney" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#LinkMoney1" role="LinkMoney1">รับรายได้</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#LinkMoney2" role="LinkMoney2">ประวัติ</a>
		</li>
</ul>
<div class="tab-content">

<div class="tab-pane active" id="LinkMoney1" role="tabpanel">
<div class="tab-dc-body d-flex justify-content-center align-items-center">
	

<?php
$load_withdraw_aff3 = $class->check_withdraw_aff_3();
$load_withdraw_aff4 = $class->check_withdraw_aff_4();
?>		
		
						<input type="text" class="form-control" name="id_aff" id="id_aff" value="<?php echo $get_profile->id_mb; ?>" hidden="hide" >
						<input type="text" class="form-control" name="username_aff" id="username_aff" value="<?php echo $get_profile->username_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="bank_aff" id="bank_aff" value="<?php echo $get_profile-> bank_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="bankacc_aff" id="bankacc_aff" value="<?php echo $get_profile->bankacc_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="name_aff" id="name_aff" value="<?php echo $get_profile->name_mb; ?>" hidden="hide">
                        <input type="number" class="form-control" name="phone_aff" id="phone_aff" value="<?php echo $get_profile->phone_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="confirm_aff" id="confirm_aff" value="รอดำเนินการ" hidden="hide">
<div class="alert alert-warning text-center mt-2" style="width: 85%;" role="alert">

		<img src="/assets/img/alert/1.png" alt="" class="d-flex mx-auto" style="min-width: 20px; width:35px; height:35px; margin-bottom: 2px;" />
		<strong>สามารถรับได้เดือนละ 1 ครั้ง จากยอดฝากเพื่อนทั้งเดือน</strong>
		</div>
		
		<div class="col-12 col-sm-12 col-md-6">
					<div class="alert alert-primary d-flex justify-content-around px-3 mb-1">
						<strong class="">รายได้ของท่านที่กดรับได้</strong>
						<strong class="pr-3"><?php echo $load_withdraw_aff1; ?></strong>
					</div>
					<div class="alert alert-primary d-flex justify-content-around px-3 mb-1">
						<strong class="">รายได้ของท่านปัจจุบัน(เดือนนี้)</strong>
						<strong class="pr-3"><?php echo $load_withdraw_aff3; ?></strong>
					</div>
					<div class="alert alert-primary d-flex justify-content-around px-3">
						<strong class="">จำนวนเพื่อนทั้งหมด</strong>
						<strong class="pr-3"><?php echo $load_withdraw_aff4; ?></strong>
					</div>
				  <div class="d-flex justify-content-center align-items-center">
					<button type="button" id="submit_LinkMoney" class="button-dc-success btn-block btn-block">กดรับค่าแนะนำเพื่อน</button>
				  </div>
		</div>	
		
			  
				  
				  
						
		

		
</div>
</div>

<div class="tab-pane" id="LinkMoney2" role="tabpanel">
<div class="row justify-content-center align-items-center mt-2">




<?php
$load_withdraw_aff_history = $class->withdraw_aff_history();
if ($load_withdraw_aff_history == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_withdraw_aff_history as $data) {
	
	$status_confirm = $data->confirm_aff;
	$data_status_confirm = "";
	if ($status_confirm == "ปฏิเสธ"){$data_status_confirm="<small style='color:#bd0243;'><i class='fas fa-times'></i> ปฏิเสธ</small>";}
	if ($status_confirm == "รอดำเนินการ"){$data_status_confirm="<small style='color:#07c9f0;'><i class='fas fa-spinner fa-spin'></i> รอดำเนินการ</small>";}
	if ($status_confirm == "อนุมัติ"){$data_status_confirm="<small style='color:#00C851;'><i class='fas fa-check'></i> อนุมัติ</small>";}
	
?>
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/deposit.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">แนะนำเพื่อน</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><?php echo $data_status_confirm; ?></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'><?php echo $data->amount_aff; ?></span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_aff; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?> 



</div>
</div>


</div>
</div>










<div id="show-cashback" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#cashback" role="cashback">คืนยอดเสีย</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#cashback2" role="cashback2">ประวัติ</a>
		</li>
</ul>
<div class="tab-content">
<div class="tab-pane active" id="cashback" role="tabpanel">
<div class="tab-dc-body">
	
<?php
$winlose = $class->turnoveryu_agent();
$winlose2 = $winlose*-$get_setting->cashback/100;
?>



						<input type="text" class="form-control" name="amount" id="amount" value="<?php echo $winlose2; ?>" readonly hidden>
                        <input type="text" class="form-control" name="id_cb" id="id_cb" value="<?php echo $get_profile->id_mb; ?>" hidden="hide" >
                        <input type="text" class="form-control" name="username_cb" id="username_cb" value="<?php echo $get_profile->username_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="bank_cb" id="bank_cb" value="<?php echo$get_profile-> bank_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="bankacc_cb" id="bankacc_cb" value="<?php echo $get_profile->bankacc_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="name_cb" id="name_cb" value="<?php echo $get_profile->name_mb; ?>" hidden="hide">
                        <input type="number" class="form-control" name="phone_cb" id="phone_cb" value="<?php echo $get_profile->phone_mb; ?>" hidden="hide">
                        <input type="text" class="form-control" name="confirm_cb" id="confirm_cb" value="อนุมัติ" hidden="hide">



<div class="text-white text-center mb-2" style="width: 90%;">
<strong>คำแนะนำ</strong><br>
โบนัสยอดเสียสามารถรับได้ทุกวันหลังเที่ยงคืน <br>
ยอดเสียของท่านทั้งหมด : <kbd><?php if ($winlose>=0) { echo 'ท่านไม่มียอดเสีย'; }else{ echo $winlose; }?></kbd><br>
ยอดเงินที่ได้คืน : <kbd><?php if ($winlose>=0) { echo 'วันนี้ท่านไม่ได้รับเงินคืน'; }else{ echo $winlose2; }?></kbd>

</div>
<button class="button-submit" id="submit_cashback" type="button">กดรับยอดเสีย</button>
		
		
		
		
</div>
</div>

<div class="tab-pane" id="cashback2" role="tabpanel">
<div class="row justify-content-center align-items-center mt-2">

<?php
$load_withdraw_history = $class->withdraw_history();
if ($load_withdraw_history == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_withdraw_history as $data) {
	
	$status_confirm = $data->confirm_wd;
	$data_status_confirm = "";
	if ($status_confirm == "ปฏิเสธ"){$data_status_confirm="<small style='color:#bd0243;'><i class='fas fa-times'></i> ปฏิเสธ</small>";}
	if ($status_confirm == "รอดำเนินการ"){$data_status_confirm="<small style='color:#07c9f0;'><i class='fas fa-spinner fa-spin'></i> รอดำเนินการ</small>";}
	if ($status_confirm == "อนุมัติ"){$data_status_confirm="<small style='color:#00C851;'><i class='fas fa-check'></i> อนุมัติ</small>";}
	
?>

			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/deposit.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">คืนยอดเสีย</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><?php echo $data_status_confirm; ?></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'> <?php echo $data->amount_cashback; ?></span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_wd; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?> 







</div>
</div>

</div>
</div>






<div id="show-promotion" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#promotion" role="promotion">โปรโมชั่น</a>
		</li>
</ul>
<div class="tab-content">
<div class="tab-pane active" id="promotion" role="tabpanel">



	
<div class="owl-slider py-2">
<div id="carousel" class="owl-carousel">
<?php
$show_promotion = $class->show_promotion();
foreach ($show_promotion as  $row) {
	if ($row["bonus_pro"]==0) {
		$row["bonus_pro"]=$row["bonusper_pro"].'%';
	}
	echo '<div class="item">';
	echo '<img class="classviewpro" src="/slip/'.$row["fileupload_pro"].'" alt="" data-no1="'.$row["time_pro"].'" data-no2="'.$row["dp_pro"].'" data-no3="'.$row["bonus_pro"].'" data-no4="'.$row["max_pro"].'" data-no5="'.$row["games_pro"].'" data-no6="'.$row["turn_pro"].'" data-no7="'.$row["rules_pro"].'" data-no8="'.$row["wd_pro"].'" >';
	echo '</div>';
}
?>
</div>
</div>

		
		
</div>
</div>
</div>







<div id="show-code-reward" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#code" role="code">กรอกโค้ด</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#code_history" role="code_history">ประวัติ</a>
		</li>
</ul>
<div class="tab-content">
<div class="tab-pane active" id="code" role="tabpanel">
<div class="row justify-content-center align-items-center py-2">

<div class="alert alert-warning text-center mt-2" style="width: 85%;" role="alert">
<img src="/assets/img/alert/1.png" alt="" class="d-flex mx-auto" style="min-width: 20px; width:35px; height:35px; margin-bottom: 2px;" />
<strong>คำแนะนำ</strong><br>
<strong>โค้ด รับได้จากกิจกรรม เท่านั้น</strong>
</div>

						<div class="card-text" style="width: 70%;">
						<div class="form-group text-center">
							<input type="text" class="form-control" name="code_id" id="code_id" placeholder="โค้ด" >
						</div>
						<button class="button-dc-success btn-block btn-block" id="submit_code_reward" type="button">ยืนยัน</button>
						</div>
</div>
</div>

<div class="tab-pane" id="code_history" role="tabpanel">
<div class="row justify-content-center align-items-center mt-2">
	
<?php
$load_code_reward_history = $class->code_reward_history();
if ($load_code_reward_history == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>


<?php foreach ($load_code_reward_history as $data) {

?>
			
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/coupon.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">กรอกโค้ด</h5>
					<div class="float-left align-middle"><span style='color:#bd0243;'>เทิร์นโอเวอร์ : <?php echo $data->turnover; ?></span></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'> <?php echo $data->reward; ?></span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_code; ?></small>
					</div>
				  </div>
				</div>
            </div>
	
	
<?php } ?>
<?php } ?> 


	
						
</div>
</div>

</div>
</div>











<div class="card-dc-wallet" id="page-transaction-history" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#page_list_deposit" role="tab">รายการเงินฝาก</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#transaction-history2" role="tab">รายการถอน</a>
		</li>
</ul>

<div class="tab-content">
	<div class="tab-pane active" id="page_list_deposit" role="tabpanel">
		<div class="row justify-content-center align-items-center mt-2">
		
<?php
$load_deposit = $class->get_list_deposit();
if ($load_deposit == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>
<?php }else{ ?>

<?php foreach ($load_deposit as $data) {
	
	$status_confirm_dp= $data->confirm_dp;
	$data_status_confirm_dp = "";
	if ($status_confirm_dp == "ปฏิเสธ"){$data_status_confirm_dp="<small style='color:#bd0243;'><i class='fas fa-times'></i> ปฏิเสธ</small>";}
	if ($status_confirm_dp == "รอดำเนินการ"){$data_status_confirm_dp="<small style='color:#07c9f0;'><i class='fas fa-spinner fa-spin'></i> รอดำเนินการ</small>";}
	if ($status_confirm_dp == "อนุมัติ"){$data_status_confirm_dp="<small style='color:#00C851;'><i class='fas fa-check'></i> อนุมัติ</small>";}
	
?>

			<div class="card mb-2 shadow-sm" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/deposit.png" alt="...">
				  <div class="media-body text-nowrap">
					<div class="mt-0 d-flex align-items-center">
						<span class="align-baseline font-weight-bold h5 pr-1" style="color: purple;">ฝากเงิน </span>
						<span class="badge-danger badge-pill align-baseline h7"><?php if (empty($data->promotion_dp)){  }else{ echo $data->promotion_dp; }?></span>
					</div>
					<div class="float-left align-middle"><small>สถานะ : </small><?php echo $data_status_confirm_dp; ?></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'> <?php echo $data->amount_dp; ?></span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_dp; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
			
<?php } ?> 
					

	</div>
	</div>
	<div class="tab-pane" id="transaction-history2" role="tabpanel">
	<div class="row justify-content-center align-items-center mt-2">
	
	
<?php
$load_withdraw = $class->get_list_withdraw();
if ($load_withdraw == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>
<?php }else{ ?>

<?php foreach ($load_withdraw as $data) {
	
	$status_confirm_wd= $data->confirm_wd;
	$data_status_confirm_wd = "";
	if ($status_confirm_wd == "ปฏิเสธ"){$data_status_confirm_wd="<small style='color:#bd0243;'><i class='fas fa-times'></i> ปฏิเสธ</small>";}
	if ($status_confirm_wd == "รอดำเนินการ"){$data_status_confirm_wd="<small style='color:#07c9f0;'><i class='fas fa-spinner fa-spin'></i> รอดำเนินการ</small>";}
	if ($status_confirm_wd == "อนุมัติ"){$data_status_confirm_wd="<small style='color:#00C851;'><i class='fas fa-check'></i> อนุมัติ</small>";}
?>

			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/salary.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">ถอน</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><?php echo $data_status_confirm_wd; ?></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'> <?php echo $data->amount_wd; ?></span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_wd; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
			
<?php } ?>
						

	</div>
	</div>
</div>


</div>

















<div id="show-diamond" class="card-dc-wallet" style="display: none;">
<ul class="nav nav-tabs" role="tablist">
		<li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#Get_D" role="spinner">รับเพชรฟรี</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#change_D" role="change_credit_spinnet">แลกเพชร</a>
		</li>
</ul>
<div class="tab-content">
	<div class="tab-pane active" id="Get_D" role="tabpanel">
		<div class="tab-dc-body">

		<div class="alert alert-warning text-center mt-2" style="width: 85%;" role="alert">
		<img src="/assets/img/alert/1.png" alt="" class="d-flex mx-auto" style="min-width: 20px; width:35px; height:35px; margin-bottom: 2px;" />
		<strong>สามารถรับได้วันละครั้ง<br> ลุ้นรับ 1-5 เพชรฟรี</strong>
		</div>
		
		<div class="col-12 col-sm-12 col-md-6 mb-5">
				  <div class="d-flex justify-content-center align-items-center mb-4">
					<img src="/assets/img/alert/giftbox.png" alt="" class="mx-auto giftbox" style="width:150px; height:150px;" />
					<canvas id="canvas-diamond"></canvas>
				  </div>
				  <div class="d-flex justify-content-center align-items-center">
					
					<button type="button" id="get-diamond" class="button-dc-success btn-block btn-block">รับเลย</button>
				  </div>
		</div>
		
</div>



<div class="row justify-content-center align-items-center mt-2">
<?php
$load_Diamond_History = $class->Diamond_History();
if ($load_Diamond_History == 0) { 
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_Diamond_History as $data) {
	
	$status_confirm = $data->reward;
	$data_status_confirm = "";
	if ($status_confirm == "ไม่ได้รับรางวัล"){
		$data_status_confirm = "<span style='color:#bd0243;'><i class='fas fa-times'></i> ไม่ได้รับรางวัล</span>";
	}else{
		$data_status_confirm = "<span style='color:#00C851;'>". $data->reward ." พ้อยด์</span>";;
	}

	
?>
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/diamond.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">รับเพชร</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><small style='color:#00C851;'><i class='fas fa-check'></i> สำเร็จ</small></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'>ได้รับ <?php echo $data->reward; ?> เพชร</span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_time; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?>
</div>

<script type="text/javascript">		 
const confettiCount = 100
const sequinCount = 10
const gravityConfetti = 0.3
const gravitySequins = 0.55
const dragConfetti = 0.075
const dragSequins = 0.02
const terminalVelocity = 3

// init other global elements
const button = document.getElementById('get-diamond')
var disabled = false
const canvas = document.getElementById('canvas-diamond')
const ctx = canvas.getContext('2d')
canvas.width = window.innerWidth
canvas.height = window.innerHeight
let cx = ctx.canvas.width / 2
let cy = ctx.canvas.height / 2

// add Confetto/Sequin objects to arrays to draw them
let confetti = []
let sequins = []

// colors, back side is darker for confetti flipping
const colors = [
  { front : '#7b5cff', back: '#6245e0' }, // Purple
  { front : '#b3c7ff', back: '#8fa5e5' }, // Light Blue
  { front : '#5c86ff', back: '#345dd1' }  // Darker Blue
]

// helper function to pick a random number within a range
randomRange = (min, max) => Math.random() * (max - min) + min

// helper function to get initial velocities for confetti
// this weighted spread helps the confetti look more realistic
initConfettoVelocity = (xRange, yRange) => {
  const x = randomRange(xRange[0], xRange[1])
  const range = yRange[1] - yRange[0] + 1
  let y = yRange[1] - Math.abs(randomRange(0, range) + randomRange(0, range) - range)
  if (y >= yRange[1] - 1) {
    // Occasional confetto goes higher than the max
    y += (Math.random() < .25) ? randomRange(1, 3) : 0
  }
  return {x: x, y: -y}
}

// Confetto Class
function Confetto() {
  this.randomModifier = randomRange(0, 99)
  this.color = colors[Math.floor(randomRange(0, colors.length))]
  this.dimensions = {
    x: randomRange(5, 9),
    y: randomRange(8, 15),
  }
  this.position = {
    x: randomRange(canvas.width/2 - button.offsetWidth/4, canvas.width/2 + button.offsetWidth/4),
    y: randomRange(canvas.height/2 + button.offsetHeight/2 + 8, canvas.height/2 + (1.5 * button.offsetHeight) - 8),
  }
  this.rotation = randomRange(0, 2 * Math.PI)
  this.scale = {
    x: 1,
    y: 1,
  }
  this.velocity = initConfettoVelocity([-9, 9], [6, 11])
}
Confetto.prototype.update = function() {
  // apply forces to velocity
  this.velocity.x -= this.velocity.x * dragConfetti
  this.velocity.y = Math.min(this.velocity.y + gravityConfetti, terminalVelocity)
  this.velocity.x += Math.random() > 0.5 ? Math.random() : -Math.random()
  
  // set position
  this.position.x += this.velocity.x
  this.position.y += this.velocity.y

  // spin confetto by scaling y and set the color, .09 just slows cosine frequency
  this.scale.y = Math.cos((this.position.y + this.randomModifier) * 0.09)    
}

// Sequin Class
function Sequin() {
  this.color = colors[Math.floor(randomRange(0, colors.length))].back,
  this.radius = randomRange(1, 2),
  this.position = {
    x: randomRange(canvas.width/2 - button.offsetWidth/3, canvas.width/2 + button.offsetWidth/3),
    y: randomRange(canvas.height/2 + button.offsetHeight/2 + 8, canvas.height/2 + (1.5 * button.offsetHeight) - 8),
  },
  this.velocity = {
    x: randomRange(-6, 6),
    y: randomRange(-8, -12)
  }
}
Sequin.prototype.update = function() {
  // apply forces to velocity
  this.velocity.x -= this.velocity.x * dragSequins
  this.velocity.y = this.velocity.y + gravitySequins
  
  // set position
  this.position.x += this.velocity.x
  this.position.y += this.velocity.y   
}

// add elements to arrays to be drawn
initBurst = () => {
  for (let i = 0; i < confettiCount; i++) {
    confetti.push(new Confetto())
  }
  for (let i = 0; i < sequinCount; i++) {
    sequins.push(new Sequin())
  }
}

// draws the elements on the canvas
render = () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  
  confetti.forEach((confetto, index) => {
    let width = (confetto.dimensions.x * confetto.scale.x)
    let height = (confetto.dimensions.y * confetto.scale.y)
    
    // move canvas to position and rotate
    ctx.translate(confetto.position.x, confetto.position.y)
    ctx.rotate(confetto.rotation)

    // update confetto "physics" values
    confetto.update()
    
    // get front or back fill color
    ctx.fillStyle = confetto.scale.y > 0 ? confetto.color.front : confetto.color.back
    
    // draw confetto
    ctx.fillRect(-width / 2, -height / 2, width, height)
    
    // reset transform matrix
    ctx.setTransform(1, 0, 0, 1, 0, 0)

    // clear rectangle where button cuts off
    if (confetto.velocity.y < 0) {
      ctx.clearRect(canvas.width/2 - button.offsetWidth/2, canvas.height/2 + button.offsetHeight/2, button.offsetWidth, button.offsetHeight)
    }
  })

  sequins.forEach((sequin, index) => {  
    // move canvas to position
    ctx.translate(sequin.position.x, sequin.position.y)
    
    // update sequin "physics" values
    sequin.update()
    
    // set the color
    ctx.fillStyle = sequin.color
    
    // draw sequin
    ctx.beginPath()
    ctx.arc(0, 0, sequin.radius, 0, 2 * Math.PI)
    ctx.fill()

    // reset transform matrix
    ctx.setTransform(1, 0, 0, 1, 0, 0)

    // clear rectangle where button cuts off
    if (sequin.velocity.y < 0) {
      ctx.clearRect(canvas.width/2 - button.offsetWidth/2, canvas.height/2 + button.offsetHeight/2, button.offsetWidth, button.offsetHeight)
    }
  })

  // remove confetti and sequins that fall off the screen
  // must be done in seperate loops to avoid noticeable flickering
  confetti.forEach((confetto, index) => {
    if (confetto.position.y >= canvas.height) confetti.splice(index, 1)
  })
  sequins.forEach((sequin, index) => {
    if (sequin.position.y >= canvas.height) sequins.splice(index, 1)
  })

  window.requestAnimationFrame(render)
}

// cycle through button states when clicked
clickButton = () => {
  if (!disabled) {
    //disabled = true
    window.initBurst()

  }
}

// re-init canvas if the window size changes
resizeCanvas = () => {
  canvas.width = window.innerWidth
  canvas.height = window.innerHeight
  cx = ctx.canvas.width / 2
  cy = ctx.canvas.height / 2
}

// resize listenter
window.addEventListener('resize', () => {
  resizeCanvas()
})


render()	
</script>

		
        
		
		
	</div>
	<div class="tab-pane" id="change_D" role="tabpanel">
	<div class="tab-dc-body">
	
	
	<div class="alert alert-success text-center mt-2" style="width: 85%;" role="alert">
		<img src="/assets/img/alert/diamond.png" alt="" class="d-flex mx-auto" style="min-width: 20px; width:35px; height:35px; margin-bottom: 2px;" />
		<strong>1 เพชร สามารถแลกได้ <?php echo $get_setting->change_diamond; ?> เครดิต</strong>
		</div>
		

		
		
		<div class="col-12 col-sm-12 col-md-6">
					<div class="alert alert-primary d-flex justify-content-around px-3">
						<strong class="">เพชรของท่าน</strong>
						<strong class="pr-3"><span id="id_diamond_1" ><?php echo $_SESSION["diamond"]; ?></span></strong>
					</div>
				  <div class="d-flex justify-content-center align-items-center">
					<button type="button" id="Submit_Change_Diamond" class="button-dc-success btn-block btn-block">แลกรางวัล</button>
				  </div>
		</div>
		
</div>		


<div class="row justify-content-center align-items-center mt-2">
<?php
$load_History_Change_Diamond = $class->history_Change_Diamond();
if ($load_History_Change_Diamond == 0) {  
?>
<div class="alert alert-primary text-center" style="width: 90%;" role="alert"><strong>ไม่พบรายการ</strong></div>

<?php }else{ ?>

<?php foreach ($load_History_Change_Diamond as $data) {
	
?>
			<div class="card mb-2" style="width: 90%; border-radius: 100px;">
                <div class="media py-2 px-3">
				  <img class="align-self-center mr-2" style="width: 60px; height 60;" src="./assets/img/item-notify/money.png" alt="...">
				  <div class="media-body text-nowrap">
					<h5 class="mt-0" style="color: purple;">แลกเพชร</h5>
					<div class="float-left align-middle"><small>สถานะ : </small><small style='color:#00C851;'><i class='fas fa-check'></i> สำเร็จ</small></div>
					<div class="float-right align-middle font-weight-bold"><span style='color:#00C851;'>ได้รับ <?php echo $data->amount; ?> เครดิต</span></div><br>
					<div class="float-none text-muted">
						<small><?php echo $data->date_change; ?></small>
					</div>
				  </div>
				</div>
            </div>

<?php } ?>
<?php } ?>
</div>


	
</div>
</div>
</div>














  

  




<div id="open-withdraw-deposit" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/money.png" class="img-fluid" alt="">
          <div class="nav-profile-text">ฝาก-ถอน</div>
	</div>    
</div>

<div id="open-transaction-history" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/transactional.png" class="img-fluid" alt="">
          <div class="nav-profile-text">ประวัติธุรกรรม</div>
	</div>    
</div>


<div id="open-code-reward" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/code.png" class="img-fluid" alt="">
          <div class="nav-profile-text">กรอกโค้ด</div>
	</div>    
</div>

<div id="open-spinner" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/spin.png" class="img-fluid" alt="">
          <div class="nav-profile-text">หมุนวงล้อ</div>
	</div>    
</div>

<div id="open-LinkMoney" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/affiliate.png" class="img-fluid" alt="">
          <div class="nav-profile-text">รับรายได้</div>
	</div>    
</div>

<div id="open-cashback" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/cashback.png" class="img-fluid" alt="">
          <div class="nav-profile-text">คืนยอดเสีย</div>
	</div>    
</div>

<div id="open-promotion" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/promotion.png" class="img-fluid" alt="">
          <div class="nav-profile-text">โปรโมชั่น</div>
	</div>    
</div>

<div id="open-diamond" class="nav-profile">
	<div class="nav-profile-body">
		  <img src="./assets/img/profile-wallet/point.png" class="img-fluid" alt="">
          <div class="nav-profile-text">รับเพชรฟรี</div>
	</div>    
</div>

<div id="ComingSoon" class="nav-profile">
	<div class="nav-profile-body">
		  <a href="affiliate/index.php"><img src="./assets/img/profile-wallet/handshake.png" class="img-fluid" alt="">
          <div class="nav-profile-text">พันธมิตร</div></a>
	</div>    
</div>





</div>
</div>



<script type="text/javascript">
$('#ComingSoon').click(function(e){
e.preventDefault();
	Swal.fire({
		icon: 'warning',
		title: 'พบกันเร็วๆนี้',
		showConfirmButton: true,
		timer: 3000,
		timerProgressBar: true,
	})
});
</script>



<script>
var submit_get_diamond = document.getElementById('get-diamond');
var submit_Change_Diamond = document.getElementById('Submit_Change_Diamond');
var Submit_Change_Spinner = document.getElementById('Submit_Change_Spinner');

Submit_Change_Spinner.addEventListener('click', function handleClick() {
	
	$.ajax({
        type: "POST",
        url: "api/v2/ChangeSpinner",
        data: {},
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'แลกพ้อยด์ สำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				$('#id_Balance_1').text(obj.info);
				$('#id_Balance_2').text(obj.info);
				$('#id_Point_1').text('0');
			}
			if (obj.status=="error"){
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
			}
        }
    });
	
});

submit_Change_Diamond.addEventListener('click', function handleClick() {
	
	$.ajax({
        type: "POST",
        url: "api/v2/ChangeDiamond",
        data: {},
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'แลกเพชร สำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				$('#id_Balance_1').text(obj.info);
				$('#id_Balance_2').text(obj.info);
				$('#id_diamond_1').text('0');
				$('#id_diamond_2').text('0');
			}
			if (obj.status=="error"){
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
			}
        }
    });
	
});

submit_get_diamond.addEventListener('click', function handleClick() {

$.ajax({
        type: "POST",
        url: "api/v2/GetDiamond",
        data: {},
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				clickButton();
				$('#id_diamond_1').text(obj.diamond);
				$('#id_diamond_2').text(obj.diamond);
				Swal.fire({
     toast: true,
     icon: 'success',
     title: 'คุณได้รับ ' + obj.RewardDiamond + ' เพชร',
     position: 'top-right',
     showConfirmButton: false,
     timer: 3000,
     timerProgressBar: true,
    })
			}
			if (obj.status=="error"){
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: 'วันนี้ คุณรับเพชรไปแล้ว',
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
				
			}
        }
    });
	
	
});
</script>






<script>
var submit_withdraw_wd = document.getElementById('submit_withdraw_wd');
var submit_deposit_dp = document.getElementById('submit_deposit_dp');
var submit_code_reward = document.getElementById('submit_code_reward');
var submit_LinkMoney = document.getElementById('submit_LinkMoney');
var submit_cashback = document.getElementById('submit_cashback');

submit_withdraw_wd.addEventListener('click', function handleClick() {
api_withdraw_wd();
});

submit_deposit_dp.addEventListener('click', function handleClick() {
api_deposit_dp();
});

submit_code_reward.addEventListener('click', function handleClick() {
api_code_reward();
});

submit_LinkMoney.addEventListener('click', function handleClick() {
api_LinkMoney();
});

submit_cashback.addEventListener('click', function handleClick() {
api_cashback();
});




function api_withdraw_wd() {


	var lastpro = document.getElementById("lastpro").value;
	var id_wd = document.getElementById("id_wd").value;
	var username_wd = document.getElementById("username_wd").value;
	var bank_wd = document.getElementById("bank_wd").value;
	var bankacc_wd = document.getElementById("bankacc_wd").value;
	var name_wd = document.getElementById("name_wd").value;
	var phone_wd = document.getElementById("phone_wd").value;
	var turnover_wd = document.getElementById("turnover_wd").value;
	var confirm_wd = document.getElementById("confirm_wd").value;
	var creditufa = document.getElementById("creditufa").value;
	var amount_wd = document.getElementById("amount_wd").value;
	
    $.ajax({
        type: "POST",
        url: "api/v2/withdraw_wd",
        data: {
            lastpro:lastpro,
            id_wd:id_wd,
			username_wd:username_wd,
            bank_wd:bank_wd,
			bankacc_wd:bankacc_wd,
            name_wd:name_wd,
			phone_wd:phone_wd,
            turnover_wd:turnover_wd,
			confirm_wd:confirm_wd,
			creditufa:creditufa,
            amount_wd:amount_wd,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 4000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='wallet';
				})
				
			}else{
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
					
			}
        }
    });

}




function api_deposit_dp() {

	var id_dp = document.getElementById("id_dp").value;
	var aff_dp = document.getElementById("aff_dp").value;
	var confirm_dp = document.getElementById("confirm_dp").value;
	var username_dp = document.getElementById("username_dp").value;
	var phone_dp = document.getElementById("phone_dp").value;
	var bank_dp = document.getElementById("bank_dp").value;
	var bankacc_dp = document.getElementById("bankacc_dp").value;
	var name_dp = document.getElementById("name_dp").value;
	var fromTrue = document.getElementById("fromTrue").value;
	var amount_dp = document.getElementById("amount_dp").value;
	var note_dp = document.getElementById("note_dp").value;
	var bonus_dp = document.getElementById("bonus_dp").value;
	var promotion_dp = document.getElementById("promotion_dp").value;
	
    $.ajax({
        type: "POST",
        url: "api/v2/deposit_dp",
        data: {
            id_dp:id_dp,
			aff_dp:aff_dp,
			confirm_dp:confirm_dp,
			username_dp:username_dp,
			phone_dp:phone_dp,
			bank_dp:bank_dp,
			bankacc_dp:bankacc_dp,
			name_dp:name_dp,
			fromTrue:fromTrue,
			amount_dp:amount_dp,
			note_dp:note_dp,
			bonus_dp:bonus_dp,
			promotion_dp:promotion_dp,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 4000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='wallet';
				})
				
			}else{
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
					
			}
        }
    });

}



function api_code_reward() {

	var code_id = document.getElementById("code_id").value;
	
    $.ajax({
        type: "POST",
        url: "api/v2/code_reward",
        data: {
            code_id:code_id,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='wallet';
				})
			}else{
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
					
			}
        }
    });

}


function api_LinkMoney() {

	var id_aff = document.getElementById("id_aff").value;
	var username_aff = document.getElementById("username_aff").value;
	var bank_aff = document.getElementById("bank_aff").value;
	var bankacc_aff = document.getElementById("bankacc_aff").value;
	var name_aff = document.getElementById("name_aff").value;
	var phone_aff = document.getElementById("phone_aff").value;
	var confirm_aff = document.getElementById("confirm_aff").value;
	
    $.ajax({
        type: "POST",
        url: "api/v2/withdraw_aff",
        data: {
            id_aff:id_aff,
			username_aff:username_aff,
			bank_aff:bank_aff,
			bankacc_aff:bankacc_aff,
			name_aff:name_aff,
			phone_aff:phone_aff,
			confirm_aff:confirm_aff,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='wallet';
				})
			}else{
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
					
			}
        }
    });

}





function api_cashback() {

	var amount = document.getElementById("amount").value;
	var id_cb = document.getElementById("id_cb").value;
	var username_cb = document.getElementById("username_cb").value;
	var bank_cb = document.getElementById("bank_cb").value;
	var bankacc_cb = document.getElementById("bankacc_cb").value;
	var name_cb = document.getElementById("name_cb").value;
	var phone_cb = document.getElementById("phone_cb").value;
	var confirm_cb = document.getElementById("confirm_cb").value;
	
    $.ajax({
        type: "POST",
        url: "api/v2/withdraw_cashback",
        data: {
            amount:amount,
			id_cb:id_cb,
			username_cb:username_cb,
			bank_cb:bank_cb,
			bankacc_cb:bankacc_cb,
			name_cb:name_cb,
			phone_cb:phone_cb,
			confirm_cb:confirm_cb,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='wallet';
				})
			}else{
				
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 3000,
					timerProgressBar: true,
				})
				
					
			}
        }
    });

}

</script>


<script>
$( document ).ready(function() {
	
	var URL_Location = window.location.search;
	var UrlParams = new URLSearchParams(URL_Location);
	var ParamValue = UrlParams.get('open');
	
	if (ParamValue=="withdraw_deposit"){
		document.getElementById("open-withdraw-deposit").click();
	}
	if (ParamValue=="spinner"){
		document.getElementById("open-spinner").click();
	}
	if (ParamValue=="cashback"){
		document.getElementById("open-cashback").click();
	}
	if (ParamValue=="credit_free"){
		document.getElementById("open-diamond").click();
	}
	
});


var button_back_page = document.getElementById('button_back_page');

button_back_page.addEventListener('click', function handleClick() {
  
  document.getElementsByClassName("cardback")[0].style.display = "none";
  var boxes1 = document.getElementsByClassName('card-dc-wallet');
  var boxes2 = document.getElementsByClassName('nav-profile');
  for (var box1 of boxes1) {
    box1.style.display = 'none';
  }
  for (var box2 of boxes2) {
    box2.style.display = 'block';
  }
  
});

var button_withdraw_deposit = document.getElementById('open-withdraw-deposit');
var button_transaction_history = document.getElementById('open-transaction-history');
var button_open_code_reward = document.getElementById('open-code-reward');

var button_open_spinner = document.getElementById('open-spinner');
var button_open_LinkMoney = document.getElementById('open-LinkMoney');
var button_open_cashback = document.getElementById('open-cashback');

var button_open_promotion = document.getElementById('open-promotion');
var button_open_diamond = document.getElementById('open-diamond');
//var button_open_ = document.getElementById('open-');

button_withdraw_deposit.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-withdraw-deposit").style.display = "block";
  
});
button_transaction_history.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("page-transaction-history").style.display = "block";
  
});
button_open_code_reward.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-code-reward").style.display = "block";
  
});
button_open_spinner.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-spinner").style.display = "block";
  
});
button_open_LinkMoney.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-LinkMoney").style.display = "block";
  
});
button_open_cashback.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-cashback").style.display = "block";
  
});
button_open_promotion.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-promotion").style.display = "block";
  
});
button_open_diamond.addEventListener('click', function handleClick() {
  
  hiddenprofile();
  document.getElementById("show-diamond").style.display = "block";
  
});


function hiddenprofile() {

document.getElementsByClassName("cardback")[0].style.display = "block";
var boxes = document.getElementsByClassName('nav-profile');
  for (var box of boxes) {
	  
    box.style.display = 'none';
	
  }
  
}



</script>
