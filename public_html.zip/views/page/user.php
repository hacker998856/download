<?php
if(!isset($_SESSION['id_mb'])){
	echo "<script>window.location = './home'</script>";
	exit;
}
?>



<div style="padding-top: 80px;"></div>

<div class="container-fluid mt-3">
	<div class="wrap-nav-categorygame">
	  <ul id="nav-categorygame">
		<li class="nav-item">
		  <a id="menu-HOT" class="nav-link dc-shadow-3d tablinks-main">
			<img src="./assets/img/nav-category/star.png" alt="">
			<div class="text-wrap">
			  <span>เกมส์ยอดฮิต</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a id="menu-Casino" class="nav-link dc-shadow-3d tablinks-main">
			<img src="./assets/img/nav-category/casino.png" alt="">
			<div class="text-wrap">
			  <span>คาสิโนสด</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a id="menu-Slots" class="nav-link dc-shadow-3d tablinks-main">
			<img src="./assets/img/nav-category/slot.png" alt="">
			<div class="text-wrap">
			  <span>สล็อต</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a id="menu-Fish" class="nav-link dc-shadow-3d tablinks-main">
			<img src="./assets/img/nav-category/fish.png" alt="">
			<div class="text-wrap">
			  <span>ยิงปลา</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a id="menu-Pokdeng" class="nav-link dc-shadow-3d tablinks-main">
			<img src="./assets/img/nav-category/pokdeng.png" alt="">
			<div class="text-wrap">
			  <span>เกมส์ไพ่</span>
			</div>
		  </a>
		</li>
	  </ul>
	</div>
</div>

<div class="container-fluid Tab-Menu-2" id="Tab-HOT">
		<div class="menu-wrapper">
		  <div class="menu-item">
			<a id="HOT-JILI" class="tablinks"><img src="assets/img/ApiImages/Tabs/JILI.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-PG" class="tablinks"><img src="assets/img/ApiImages/Tabs/PG.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-Joker" class="tablinks"><img src="assets/img/ApiImages/Tabs/Joker.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-PragmaticPlay" class="tablinks"><img src="assets/img/ApiImages/Tabs/PragmaticPlay.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-KINGMAKER" class="tablinks"><img src="assets/img/ApiImages/Tabs/KINGMAKER.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-CQ9" class="tablinks"><img src="assets/img/ApiImages/Tabs/CQ9.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-AMBPoker" class="tablinks"><img src="assets/img/ApiImages/Tabs/AMBPoker.png" alt="" class="img-fluid mx-auto"></a>
			<a id="HOT-Fachai" class="tablinks"><img src="assets/img/ApiImages/Tabs/Fachai.png" alt="" class="img-fluid mx-auto"></a>
		  </div> 
		  <span class="pointer left-pointer dis">
			<i class="fas fa-angle-left"></i>
		  </span>
		  <span class="pointer right-pointer">
			<i class="fas fa-angle-right"></i>
		  </span>
		</div>
</div>

<div class="container-fluid Tab-Menu-2" id="Tab-Casino">
		<div class="menu-wrapper">
		  <div class="menu-item">
			<a id="Casino-SAGaming" onclick="Start_Game_Api('sa')" class="tablinks"><img src="assets/img/ApiImages/Tabs/SAGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-AESexy" onclick="Start_Game_Api('sexy')" class="tablinks"><img src="assets/img/ApiImages/Tabs/AESexy.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-AsiaGaming" onclick="Start_Game_Api('ag')" class="tablinks"><img src="assets/img/ApiImages/Tabs/AsiaGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-WM" onclick="Start_Game_Api('wm')" class="tablinks"><img src="assets/img/ApiImages/Tabs/WM.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-DG" onclick="Start_Game_Api('dg')" class="tablinks"><img src="assets/img/ApiImages/Tabs/dg.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-WEEntertainment" onclick="Start_Game_Api('we')" class="tablinks"><img src="assets/img/ApiImages/Tabs/WEEntertainment.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-EvolutionGaming" onclick="Start_Game_Api('eg')" class="tablinks"><img src="assets/img/ApiImages/Tabs/EvolutionGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Casino-XtreamGaming" onclick="Start_Game_Api('xg')" class="tablinks"><img src="assets/img/ApiImages/Tabs/XtreamGaming.png" alt="" class="img-fluid mx-auto"></a>
		  </div> 
		  <span class="pointer left-pointer dis">
			<i class="fas fa-angle-left"></i>
		  </span>
		  <span class="pointer right-pointer">
			<i class="fas fa-angle-right"></i>
		  </span>
		</div>
		
		
<div class="d-flex justify-content-around">
		
<div class="cards-list-home">

	<a onclick="Start_Game_Api('sexy')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/AE-Sexy-Logo.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('wm')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/wm.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('ag')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/asiagaming.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('sa')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/saGame.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('dg')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/dg.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('we')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/we.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('eg')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/eg.png" />
			</div>	
		</div>
	</a>
	<a onclick="Start_Game_Api('xg')">
		<div class="card-home">
			<div class="card_image">
				<img src="assets/img/homegame/xg.png" />
			</div>	
		</div>
	</a>
</div>


</div>
		
		
</div>


<div class="container-fluid Tab-Menu-2" id="Tab-Slots">
		<div class="menu-wrapper">
		  <div class="menu-item">
			<a id="Slots-Joker" class="tablinks"><img src="assets/img/ApiImages/Tabs/Joker.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-PG" class="tablinks"><img src="assets/img/ApiImages/Tabs/PG.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-PragmaticPlay" class="tablinks"><img src="assets/img/ApiImages/Tabs/PragmaticPlay.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-SkyWindGroup" class="tablinks"><img src="assets/img/ApiImages/Tabs/SkyWindGroup.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-AEGamingSlot" class="tablinks"><img src="assets/img/ApiImages/Tabs/AEGamingSlot.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-1x2Gaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/1x2Gaming.png" alt="" class="img-fluid mx-auto"></a>
			
			<a id="Slots-HacksawGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/HacksawGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-CQ9" class="tablinks"><img src="assets/img/ApiImages/Tabs/CQ9.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-KAGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/KAGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-FantasmaGames" class="tablinks"><img src="assets/img/ApiImages/Tabs/FantasmaGames.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-NetGamesEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/NetGamesEnt.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Rich88" class="tablinks"><img src="assets/img/ApiImages/Tabs/Rich88.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-JILI" class="tablinks"><img src="assets/img/ApiImages/Tabs/JILI.png" alt="" class="img-fluid mx-auto"></a>
			
			
			<a id="Slots-PushGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/PushGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-GameArt" class="tablinks"><img src="assets/img/ApiImages/Tabs/GameArt.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-PlaynGo" class="tablinks"><img src="assets/img/ApiImages/Tabs/PlaynGo.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-NolimitCity" class="tablinks"><img src="assets/img/ApiImages/Tabs/NolimitCity.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Thunderkick" class="tablinks"><img src="assets/img/ApiImages/Tabs/Thunderkick.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Yggdrasil" class="tablinks"><img src="assets/img/ApiImages/Tabs/Yggdrasil.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Quickspin" class="tablinks"><img src="assets/img/ApiImages/Tabs/Quickspin.png" alt="" class="img-fluid mx-auto"></a>
			
			
			<a id="Slots-Habanero" class="tablinks"><img src="assets/img/ApiImages/Tabs/Habanero.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-RelaxGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/RelaxGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-DragoonSoft" class="tablinks"><img src="assets/img/ApiImages/Tabs/DragoonSoft.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-RedTiger" class="tablinks"><img src="assets/img/ApiImages/Tabs/RedTiger.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Booongo" class="tablinks"><img src="assets/img/ApiImages/Tabs/Booongo.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-IronDog" class="tablinks"><img src="assets/img/ApiImages/Tabs/IronDog.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-KalambaGames" class="tablinks"><img src="assets/img/ApiImages/Tabs/KalambaGames.png" alt="" class="img-fluid mx-auto"></a>
			
			
			<a id="Slots-KINGMAKER" class="tablinks"><img src="assets/img/ApiImages/Tabs/KINGMAKER.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Fachai" class="tablinks"><img src="assets/img/ApiImages/Tabs/Fachai.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-FunkyGames" class="tablinks"><img src="assets/img/ApiImages/Tabs/FunkyGames.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Gamatron" class="tablinks"><img src="assets/img/ApiImages/Tabs/Gamatron.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-PlayStar" class="tablinks"><img src="assets/img/ApiImages/Tabs/PlayStar.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-SimplePlay" class="tablinks"><img src="assets/img/ApiImages/Tabs/SimplePlay.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-EvoplayEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/EvoplayEnt.png" alt="" class="img-fluid mx-auto"></a>
			
			
			<a id="Slots-NetEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/NetEnt.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-AMBPoker" class="tablinks"><img src="assets/img/ApiImages/Tabs/AMBPoker.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-TTG" class="tablinks"><img src="assets/img/ApiImages/Tabs/TTG.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-BlueprintGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/BlueprintGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Slots-Maverick" class="tablinks"><img src="assets/img/ApiImages/Tabs/Maverick.png" alt="" class="img-fluid mx-auto"></a>

			
			
		  </div> 
		  <span class="pointer left-pointer dis">
			<i class="fas fa-angle-left"></i>
		  </span>
		  <span class="pointer right-pointer">
			<i class="fas fa-angle-right"></i>
		  </span>
		</div>
</div>

<div class="container-fluid Tab-Menu-2" id="Tab-Fish">
		<div class="menu-wrapper">
		  <div class="menu-item">
		    <a id="Fish-Joker" class="tablinks"><img src="assets/img/ApiImages/Tabs/Joker.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-SkyWind" class="tablinks"><img src="assets/img/ApiImages/Tabs/SkyWindGroup.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-CQ9" class="tablinks"><img src="assets/img/ApiImages/Tabs/CQ9.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-JILI" class="tablinks"><img src="assets/img/ApiImages/Tabs/JILI.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-KAGaming" class="tablinks"><img src="assets/img/ApiImages/Tabs/KAGaming.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-Fachai" class="tablinks"><img src="assets/img/ApiImages/Tabs/Fachai.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-FunkyGames" class="tablinks"><img src="assets/img/ApiImages/Tabs/FunkyGames.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-Gamatron" class="tablinks"><img src="assets/img/ApiImages/Tabs/Gamatron.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-BG" class="tablinks"><img src="assets/img/ApiImages/Tabs/BG.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-SimplePlay" class="tablinks"><img src="assets/img/ApiImages/Tabs/SimplePlay.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-EvoplayEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/EvoplayEnt.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Fish-AMBPoker" class="tablinks"><img src="assets/img/ApiImages/Tabs/AMBPoker.png" alt="" class="img-fluid mx-auto"></a>
		  </div> 
		  <span class="pointer left-pointer dis">
			<i class="fas fa-angle-left"></i>
		  </span>
		  <span class="pointer right-pointer">
			<i class="fas fa-angle-right"></i>
		  </span>
		</div>
</div>


<div class="container-fluid Tab-Menu-2" id="Tab-Pokdeng">
		<div class="menu-wrapper">
		  <div class="menu-item">
			<a id="Pokdeng-KINGMAKER" class="tablinks"><img src="assets/img/ApiImages/Tabs/KINGMAKER.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-AEGamingSlot" class="tablinks"><img src="assets/img/ApiImages/Tabs/AEGamingSlot.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-SkyWindGroup" class="tablinks"><img src="assets/img/ApiImages/Tabs/SkyWindGroup.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-JILI" class="tablinks"><img src="assets/img/ApiImages/Tabs/JILI.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-FunkyGames" class="tablinks"><img src="assets/img/ApiImages/Tabs/FunkyGames.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-EvoplayEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/EvoplayEnt.png" alt="" class="img-fluid mx-auto"></a>
			<a id="Pokdeng-NetEnt" class="tablinks"><img src="assets/img/ApiImages/Tabs/NetEnt.png" alt="" class="img-fluid mx-auto"></a>
		  </div> 
		  <span class="pointer left-pointer dis">
			<i class="fas fa-angle-left"></i>
		  </span>
		  <span class="pointer right-pointer">
			<i class="fas fa-angle-right"></i>
		  </span>
		</div>
</div>


<div id="show_game_list" class="container-fluid">		

</div>

<div id="loading-dc" class="spinner-loading invisible">
    <div class="lds-roller">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div>กรุณารอสักครู่</div>
</div>




<script>
        $(".tablinks-main").click(function() {
            var listItems = $(".tablinks-main");
            for (let i = 0; i < listItems.length; i++) {
                listItems[i].classList.remove("listmainactive");
            }
            this.classList.add("listmainactive");
        });
</script>
<script>
        $(".tablinks").click(function() {
            var listItems = $(".tablinks");
            for (let i = 0; i < listItems.length; i++) {
                listItems[i].classList.remove("listactive");
            }
            this.classList.add("listactive");
        });
</script>


<script type="text/javascript">
$("#menu-HOT").click(function(){
	Hidden_Tab_Menu_2("Tab-HOT");
	$("#HOT-JILI").click();
	sessionStorage.setItem("menu", "menu-HOT");
});
///////////////////////////////////////////////////
$("#HOT-JILI").click(function(){
	show_game("jl", "", "https://img.betflix777.com", "https://betflik.com/games_share/jl.txt");
});
$("#HOT-PG").click(function(){
	Start_Game_Api("pg");
});
$("#HOT-Joker").click(function(){
	show_game("joker", "", "https://img.betflix777.com", "https://betflik.com/games_share/joker.txt");
});
$("#HOT-PragmaticPlay").click(function(){
	show_game("pp", "", "", "https://betflik.com/games_share/pp.txt");
});
$("#HOT-KINGMAKER").click(function(){
	show_game("km", "", "https://img.betflix777.com", "https://betflik.com/games_share/km.txt");
});
$("#HOT-CQ9").click(function(){
	Start_Game_Api("cq9");
});
$("#HOT-AMBPoker").click(function(){
	Start_Game_Api("amb");
});
$("#HOT-Fachai").click(function(){
	show_game("fc", "", "https://img.betflix777.com", "https://betflik.com/games_share/fc.txt");
});
</script>

<script type="text/javascript">
$("#menu-Casino").click(function(){
	Hidden_Tab_Menu_2("Tab-Casino");
	sessionStorage.setItem("menu", "menu-Casino");
});
</script>


<script type="text/javascript">
$("#menu-Pokdeng").click(function(){
	Hidden_Tab_Menu_2("Tab-Pokdeng");
	$("#Pokdeng-KINGMAKER").click();
	sessionStorage.setItem("menu", "menu-Pokdeng");
});
///////////////////////////////////////////////////
$("#Pokdeng-KINGMAKER").click(function(){
	show_game("km", "", "https://img.betflix777.com", "https://betflik.com/games_share/km.txt");
});
$("#Pokdeng-AEGamingSlot").click(function(){
	show_game("aws", "TABLE", "https://img.betflix777.com", "https://betflik.com/games_share/aws.txt");
});
$("#Pokdeng-SkyWindGroup").click(function(){
	show_game("swg", "table", "https://img.betflix777.com", "https://betflik.com/games_share/swg.txt");
});
$("#Pokdeng-JILI").click(function(){
	show_game("jl", "TABLE", "https://img.betflix777.com", "https://betflik.com/games_share/jl.txt");
});
$("#Pokdeng-FunkyGames").click(function(){
	show_game("funky", "table game", "https://img.betflix777.com", "https://betflik.com/games_share/funky.txt");
});
$("#Pokdeng-EvoplayEnt").click(function(){
	show_game("ep", "table-games", "", "https://betflik.com/games_share/ep.txt");
});
$("#Pokdeng-NetEnt").click(function(){
	show_game("netent", "Table ", "https://img.betflix777.com", "https://betflik.com/games_share/netent.txt");
});
</script>


<script type="text/javascript">
$("#menu-Fish").click(function(){
	Hidden_Tab_Menu_2("Tab-Fish");
	$("#Fish-Joker").click();
	sessionStorage.setItem("menu", "menu-Fish");
});
///////////////////////////////////////////////////
$("#Fish-SkyWind").click(function(){
	show_game("swg", "action", "https://img.betflix777.com", "https://betflik.com/games_share/swg.txt");
});
$("#Fish-CQ9").click(function(){
	Start_Game_Api("cq9");
});
$("#Fish-JILI").click(function(){
	show_game("jl", "FH", "https://img.betflix777.com", "https://betflik.com/games_share/jl.txt");
});
$("#Fish-KAGaming").click(function(){
	show_game("kg", "fishing", "", "https://betflik.com/games_share/kg.txt");
});
$("#Fish-Fachai").click(function(){
	show_game("fc", "FH", "https://img.betflix777.com", "https://betflik.com/games_share/fc.txt");
});
$("#Fish-FunkyGames").click(function(){
	show_game("funky", "fish game", "https://img.betflix777.com", "https://betflik.com/games_share/funky.txt");
});
$("#Fish-Gamatron").click(function(){
	show_game("gamatron", "Fishing", "https://img.betflix777.com", "https://betflik.com/games_share/gamatron.txt");
});
$("#Fish-BG").click(function(){
	Start_Game_Api("bg");
});
$("#Fish-SimplePlay").click(function(){
	Start_Game_Api("sp");
});
$("#Fish-EvoplayEnt").click(function(){
	show_game("ep", "", "", "https://betflik.com/games_share/ep.txt");
});
$("#Fish-AMBPoker").click(function(){
	Start_Game_Api("amb");
});
$("#Fish-Joker").click(function(){
	show_game("joker", "Fishing", "https://img.betflix777.com", "https://betflik.com/games_share/joker.txt");
});
</script>


<script type="text/javascript">
$("#menu-Slots").click(function(){
	Hidden_Tab_Menu_2("Tab-Slots");
	$("#Slots-Joker").click();
	sessionStorage.setItem("menu", "menu-Slots");
});
///////////////////////////////////////////////////
$("#Slots-PG").click(function(){

Start_Game_Api("pg");


$('#show_game_list').html('');

});


$("#Slots-Joker").click(function(){
	show_game("joker", "Slot", "https://img.betflix777.com", "https://betflik.com/games_share/joker.txt");
});
$("#Slots-JILI").click(function(){
	show_game("jl", "SLOT", "https://img.betflix777.com", "https://betflik.com/games_share/jl.txt");
});
$("#Slots-PragmaticPlay").click(function(){
	show_game("pp", "Video Slots", "", "https://betflik.com/games_share/pp.txt");
});

$("#Slots-KINGMAKER").click(function(){
	show_game("km", "", "https://img.betflix777.com", "https://betflik.com/games_share/km.txt");
});
$("#Slots-Fachai").click(function(){
	show_game("fc", "SLOT", "https://img.betflix777.com", "https://betflik.com/games_share/fc.txt");
});
$("#Slots-Habanero").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/hab.txt");
});
$("#Slots-NetEnt").click(function(){
	show_game("netent", "Slot", "https://img.betflix777.com", "https://betflik.com/games_share/netent.txt");
});
$("#Slots-RedTiger").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/red.txt");
});
$("#Slots-SkyWindGroup").click(function(){
	show_game("swg", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/swg.txt");
});
$("#Slots-FunkyGames").click(function(){
	show_game("funky", "slot game", "https://img.betflix777.com", "https://betflik.com/games_share/funky.txt");
});
$("#Slots-AEGamingSlot").click(function(){
	show_game("aws", "SLOT", "https://img.betflix777.com", "https://betflik.com/games_share/aws.txt");
});
$("#Slots-1x2Gaming").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/1x2.txt");
});


$("#Slots-HacksawGaming").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/hak.txt");
});
$("#Slots-CQ9").click(function(){
	Start_Game_Api("cq9");
});
$("#Slots-KAGaming").click(function(){
	show_game("kg", "slots", "", "https://betflik.com/games_share/kg.txt");
});
$("#Slots-FantasmaGames").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/fng.txt");
});
$("#Slots-NetGamesEnt").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/nge.txt");
});
$("#Slots-Rich88").click(function(){
	Start_Game_Api("r88");
});
$("#Slots-PushGaming").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/pug.txt");
});
$("#Slots-GameArt").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/ga.txt");
});
$("#Slots-PlaynGo").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/png.txt");
});
$("#Slots-NolimitCity").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/nlc.txt");
});
$("#Slots-Thunderkick").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/tk.txt");
});
$("#Slots-Yggdrasil").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/ygg.txt");
});
$("#Slots-Quickspin").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/qs.txt");
});
$("#Slots-RelaxGaming").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/rlx.txt");
});
$("#Slots-DragoonSoft").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/ds.txt");
});
$("#Slots-Booongo").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/bng.txt");
});
$("#Slots-IronDog").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/ids.txt");
});
$("#Slots-KalambaGames").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/kgl.txt");
});
$("#Slots-Gamatron").click(function(){
	show_game("gamatron", "Slot", "https://img.betflix777.com", "https://betflik.com/games_share/gamatron.txt");
});
$("#Slots-PlayStar").click(function(){
	Start_Game_Api("ps");
});
$("#Slots-SimplePlay").click(function(){
	Start_Game_Api("sp");
});
$("#Slots-EvoplayEnt").click(function(){
	show_game("ep", "slots", "https://img.betflix777.com", "https://betflik.com/games_share/ep.txt");
});
$("#Slots-AMBPoker").click(function(){
	Start_Game_Api("amb");
});
$("#Slots-TTG").click(function(){
	Start_Game_Api("ttg");
});
$("#Slots-BlueprintGaming").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/bpg.txt");
});
$("#Slots-Maverick").click(function(){
	show_game("qtech", "slot", "https://img.betflix777.com", "https://betflik.com/games_share/mav.txt");
});

</script>


<script type="text/javascript">

function show_game(NameGame, NameType, LinkImages, Link){
document.getElementById("loading-dc").classList.remove('invisible');


Hidden_Show_Game_List();

$.ajax({
        url: 'api/v2/LoadGame',
        type: 'POST',
		dataType: 'json',
        data: {
           'Link' : Link
        },
        success: function(data){
			
			
html = "";
html += '<div class="columns-list-dc">';

$.each(data, function( index, value ) {

var str = value.img;
var value_img = str.replace('http://','https://');

//var check_type = ["slot game", "Slot", "SLOT", "Video Slots"];
//if(check_type.includes(value.type)){
if(NameType == ""){
	
	html += '<div class="elem">';
	html += '<a href="javascript:void(0)" class="classrungame" data-namegame="' + NameGame + '" data-codegame="' + value.code + '">';
	html += '<img src="' + LinkImages + value_img + '">';
	html += '<div class="elem-over">';
	html += '<button class="button-play" role="button">เล่นเกม</button>';
	html += '</div>';
	html += '<div class="title">' + value.name + '</div>';
	html += '</a>';
	html += '</div>';
	
}else{
	
	if(value.type == NameType){	

	html += '<div class="elem">';
    html += '<a href="javascript:void(0)" class="classrungame" data-namegame="' + NameGame + '" data-codegame="' + value.code + '">';
	html += '<img src="' + LinkImages + value_img + '">';
	html += '<div class="elem-over">';
	html += '<button class="button-play" role="button">เล่นเกม</button>';
	html += '</div>';
	html += '<div class="title">' + value.name + '</div>';
	html += '</a>';
	html += '</div>';
	
	}
	
}
	
});

html += '</div>';
document.getElementById("loading-dc").classList.add('invisible');
$('#show_game_list').html(html);		


var seleterungame = document.querySelectorAll('.classrungame');
seleterungame.forEach(function(element) {

	element.addEventListener('click', function() {
		var Date_Codegame = $(this).data('codegame');
		var Date_Namegame = $(this).data('namegame');
		
		Swal.fire({
			title: "กรุณารอสักครู่",
			text: "กำลังนำท่านไปยังหน้าเกมส์",
			allowOutsideClick: false,
			didOpen: () => {
				Swal.showLoading()
		  }
		})
		
		$.ajax({
			url: 'api/v2/Play',
			type: 'POST',
			data: {
			   'NameGame' : Date_Namegame,
			   'CodeGame' : Date_Codegame
			},
			success: function(data){
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					window.location.href = obj.launch_url;
				}
				if (obj.status=="error"){
					Swal.fire({
						toast: true,
						icon: 'error',
						title: 'กรุณาลองใหม่ภายหลัง',
						position: 'top-right',
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}

			}
		});
	})

})


			
} 
});



	
}

</script>


<script type="text/javascript">

function Hidden_Tab_Menu_2(Tab_Active) {
$('#show_game_list').html('');
var i, boxes, boxes2;
boxes = document.getElementsByClassName('Tab-Menu-2');
  for (var box of boxes) {
    box.style.display = 'none';
  }
boxes2 = document.getElementsByClassName("Tab-Menu-2");
  for (i = 0; i < boxes2.length; i++) {
	  
	  boxes2[i].className = boxes2[i].className.replace(" sele-active", "");
	  
  }  
document.getElementById(Tab_Active).classList.add('sele-active');
document.getElementById(Tab_Active).style.display = "block";
selete_menu_item();
}

function Hidden_Show_Game_List() {

$('#show_game_list').html('');
  
}




function Start_Game_Api(NameGame) {
var Codegame = "-";
let Loading_status;
Swal.fire({
	title: "กรุณารอสักครู่",
	text: "กำลังนำท่านไปยังหน้าเกมส์",
	timer: 3000,
	allowOutsideClick: false,
	didOpen: () => {

        Swal.showLoading()
		
		$.ajax({
		url: 'api/v2/Play',
		type: 'POST',
		data: {
           'NameGame' : NameGame,
		   'CodeGame' : Codegame
        },
		success: function(data){
			Loading_status = JSON.parse(data);
		}
	});
	
  }
}).then((result) => {
	
  if (result.dismiss === Swal.DismissReason.timer) {
	  
	if (Loading_status.status=="success"){
		
		window.location.href = Loading_status.launch_url;
			
	}else{
		
		Swal.fire({
			toast: true,
			icon: 'error',
			title: 'โปรดลองใหม่ภายหลัง',
			position: 'top-right',
			showConfirmButton: false,
			timer: 2000,
			timerProgressBar: true,
		})


	}
    
  }
  
});
  
  
  
}

</script>


<script type="text/javascript">
function selete_menu_item() {

var parentElement = document.querySelector("div.container-fluid.Tab-Menu-2.sele-active");
var allChildren = parentElement.querySelector(".menu-wrapper");

var lp, rp, mItems, menu, sc, pos;
lp = $(".left-pointer");
rp = $(".right-pointer");
mItems = $(".sele-active .menu-item");
lp.click(function(){
	sc = mItems.width() - 0;
  pos = mItems.scrollLeft() - sc;
  mItems.animate({'scrollLeft': pos}, 'slow');
});
rp.click(function(){
  sc = mItems.width() - 0;
  pos = mItems.scrollLeft() + sc;
  mItems.animate({'scrollLeft': pos}, 'slow');
});
var scrollLeftPrev = 0; 
mItems.scroll(function(){
  var newScrollLeft = mItems.scrollLeft(),width=mItems.width(), scrollWidth=mItems.get(0).scrollWidth;
  var offset=8;
  if (scrollWidth - newScrollLeft - width < offset) {
    $(".right-pointer").addClass("dis");
  }else{
    $(".right-pointer").removeClass("dis");
  }
  if( $(this).scrollLeft() == 0){
    $(".left-pointer").addClass("dis");
  }else{
    $(".left-pointer").removeClass("dis");
  }
  scrollLeftPrev = newScrollLeft;
});
mItems.scrollLeft(0);

var slider1 = allChildren.querySelector(".menu-item");
var isDown = false;
var startX;
var scrollLeft;
slider1.addEventListener('mousedown', (e) => {
  isDown = true;
  slider1.classList.add('active');
  startX = e.pageX - slider1.offsetLeft;
  scrollLeft = slider1.scrollLeft;
});
slider1.addEventListener('mouseleave', () => {
  isDown = false;
  slider1.classList.remove('active');
});
slider1.addEventListener('mouseup', () => {
  isDown = false;
  slider1.classList.remove('active');
});
slider1.addEventListener('mousemove', (e) => {
  if(!isDown) return;
  e.preventDefault();
  var x = e.pageX - slider1.offsetLeft;
  var walk = (x - startX) * 1; //scroll-fast
  slider1.scrollLeft = scrollLeft - walk;
});

}
</script>

<?php
$files = glob('assets/img/popup/*');
foreach($files as $file){
	if(is_file($file)) {
	  $load_img_popup = $file;
	}
}
?>


<div id="myModal-popup" class="modal-popup">
  <span class="close">&times;</span>
  <img class="modal-content-popup" id="modalImg">
  <div id="caption"></div>
</div>

<script>
var load_img_popup = "<?php echo $load_img_popup; ?>";
if(sessionStorage.getItem("popup")) {
	
if(sessionStorage.getItem("popup") == 0) {
var modal = document.getElementById("myModal-popup");
var modalImg = document.getElementById("modalImg");
modal.style.display = "block";
modalImg.src = load_img_popup;

var span = document.getElementsByClassName("close")[0];

span.onclick = function() { 
  modal.style.display = "none";
  sessionStorage.setItem("popup", "1");
}



$("#menu-HOT").click();

sessionStorage.setItem("menu", "menu-HOT");

}

}else{
sessionStorage.setItem("popup", "0");
}
</script>




<script>

if(sessionStorage.getItem("menu") == "menu-HOT") {
	$("#menu-HOT").click();
}

if(sessionStorage.getItem("menu") == "menu-Casino") {
	$("#menu-Casino").click();
}

if(sessionStorage.getItem("menu") == "menu-Slots") {
	$("#menu-Slots").click();
}

if(sessionStorage.getItem("menu") == "menu-Fish") {
	$("#menu-Fish").click();
}

if(sessionStorage.getItem("menu") == "menu-Pokdeng") {
	$("#menu-Pokdeng").click();
}

</script>


<div class="container-fluid">





</div>


