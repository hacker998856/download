<div style="padding-top: 100px;"></div>
<div class="container-fluid">
<div class="row bg-white justify-content-center align-items-center">


<?php

error_reporting(0);

if (empty($_GET['CodeGame'])) {
	$_GET['CodeGame'] = "-";
}

if (empty($_GET['NameGame'])) {
	
	echo "<script>window.location = 'user'</script>";
	exit;

}else{
	
$PlayGame = $class->PlayGame1($_GET['NameGame'],$_GET['CodeGame']);

if($PlayGame['status'] == "error"){
	
	
	echo '<script type="text/javascript">';
	echo "Swal.fire({
					toast: true,
					icon: 'error',
					title: 'โปรดลองใหม่ภายหลัง',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='user';
				})
		";
	echo '</script>';
	exit;

}else{
	
	
	$Start_Url = $PlayGame['launch_url'];
	echo '<script type="text/javascript">';
	echo "window.location.href='". $Start_Url ."';";
	echo '</script>';
	exit;
	
}


}

?>


</div>
</div>




