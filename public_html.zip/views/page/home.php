<?php
if(!isset($_SESSION['id_mb'])){
	
}else{
	echo "<script>window.location = './user'</script>";
	exit;
}
?>
<div style="padding-top: 50px;"></div>


<div id="carouselExampleControls" class="carousel slide mt-3" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
		<div class="">
			<div class="row">
			  <div class="col-6 align-self-center"><img src="assets/img/imgtop.png" width="400" class="img-fluid rounded float-right dc-animate-1" alt="..."></div>
			  <div class="col-6 align-self-center text-center">
			       <div class="float-left">
					   <div class="dc-animate-text1">
					   <span style="--i:1">H</span>
					   <span style="--i:2">I</span>
					   <span style="--i:3">B</span>
					   <span style="--i:4">E</span>
					   <span style="--i:5">T</span>
					 
					  </div>
					  <span class="dc-text1">เว็บรวมเกมส์อันดับ 1 ของไทย</span><br>
					  <span class="dc-text1">เว็บเกมส์ บนมือถือ กระเป๋าเดียว เล่นได้ทุกเกมส์</span>
				  </div>
			  </div>
			</div>
		</div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<div class="container-fluid">
	<div class="wrap-nav-categorygame">
	  <ul id="nav-categorygame">
		<li class="nav-item">
		  <a class="nav-link dc-shadow-3d ModalSignin">
			<img src="./assets/img/nav-category/star.png" alt="">
			<div class="text-wrap">
			  <span>เกมส์ยอดฮิต</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a class="nav-link dc-shadow-3d ModalSignin">
			<img src="./assets/img/nav-category/casino.png" alt="">
			<div class="text-wrap">
			  <span>คาสิโนสด</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a class="nav-link dc-shadow-3d ModalSignin">
			<img src="./assets/img/nav-category/slot.png" alt="">
			<div class="text-wrap">
			  <span>สล็อต</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a class="nav-link dc-shadow-3d ModalSignin">
			<img src="./assets/img/nav-category/fish.png" alt="">
			<div class="text-wrap">
			  <span>ยิงปลา</span>
			</div>
		  </a>
		</li>
		<li class="nav-item">
		  <a class="nav-link dc-shadow-3d ModalSignin">
			<img src="./assets/img/nav-category/pokdeng.png" alt="">
			<div class="text-wrap">
			  <span>เกมส์ไพ่</span>
			</div>
		  </a>
		</li>
	  </ul>
	</div>
</div>



<div class="container mb-2">

<div class="col-12 text-center">
			    <div class="dc-text1">
					<span class="ts1">โปรโมชั่น</span>
				</div>
			<div class="dc-hr-title-3"></div>
		</div>

<div class="owl-slider py-2">
<div id="carousel" class="owl-carousel">
<?php
$show_promotion = $class->show_promotion();
foreach ($show_promotion as  $row) {
	
	echo '<div class="item">';
	echo '<img class="classviewpro" src="/slip/'.$row["fileupload_pro"].'" alt="" data-no1="'.$row["time_pro"].'" data-no2="'.$row["dp_pro"].'" data-no3="'.$row["bonus_pro"].'" data-no4="'.$row["bonusper_pro"].'" data-no5="'.$row["games_pro"].'" data-no6="'.$row["turn_pro"].'" data-no7="'.$row["rules_pro"].'" data-no8="'.$row["wd_pro"].'" >';
	echo '</div>';
}
?>
</div>
</div>


	
</div>




<div class="container-fluid">
		<div class="col-12 text-center">
			    <div class="dc-text1">
					<span class="ts1">ค่ายเกมส์ดัง</span>
				</div>
			<div class="dc-hr-title-3"></div>
		</div>


<div class="d-flex justify-content-around">
		
<div class="cards-list-home">

<?php
$all_files = glob("assets/img/homegame/*.*");
 for ($i=0; $i<count($all_files); $i++)
 {
  $image_name = $all_files[$i];
  echo '<a class="ModalSignin">';
  echo '<div class="card-home">';
  echo '<div class="card_image">';
  echo '<img src="'.$image_name .'" />';
  echo '</div>';
  echo '</div>';
  echo '</a>';
  
 }
?>
  
</div>


</div>

</div>


	


