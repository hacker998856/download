<?php
date_default_timezone_set("Asia/Bangkok");
$load_setting = $class->load_db_setting();
$css_tag = date('YmdHh');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="format-detection" content="telephone=no">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" >
  <meta name="apple-mobile-web-app-capable" content="yes" >
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title><?php echo $load_setting->name_web; ?></title>
  
  <link rel="canonical" href="<?php echo $load_setting->link_web; ?>" />
  <meta property="og:locale" content="en_US" />
  <meta property="og:description" content="<?php echo $load_setting->name_web; ?>" />
  <meta property="og:url" content="<?php echo $load_setting->link_web; ?>" />
  <meta property="og:site_name" content="<?php echo $load_setting->name_web; ?>" />
  <meta property="og:image" content="<?php echo $load_setting->logo_web; ?>" />
  
  
  
  <link href="https://cdn.jsdelivr.net/gh/lazywasabi/thai-web-fonts@6/fonts/NotoSansThai/NotoSansThai.css" rel="stylesheet" />
  <link rel="icon" href="<?php echo $load_setting->	logo_web; ?>" type="image/x-icon">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/stylelistitem.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/bg.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-menu-mobile.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-menu-top.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-login.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-wallet.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-notify.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-popup.css?v=<?php echo $css_tag; ?>">
  <link rel="stylesheet" href="assets/css/style-buttonAF.css?v=<?php echo $css_tag; ?>">
  
  <link rel="stylesheet" href="assets/css/spinner/superwheel.css?v=<?php echo $css_tag; ?>">

  
  
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css'>
  <link rel="stylesheet" href="assets/css/style-slider-promotion.css?v=<?php echo $css_tag; ?>">
  

  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.all.min.js"></script>

</head>

<body>



<div class="dc-background">
<div class="dc-overlay"></div>
<ul class="item-bg">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
</ul>











