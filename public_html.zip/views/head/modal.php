 <?php
$ipaddress = $_SERVER['REMOTE_ADDR']; //Get user IP
$date = date("Y-m-d  H:i:s");
@$aff = $_GET["aff"];
?>

<div class="modal-login">
    <div class="modal-content">
        <span class="close-button close-modal-login">×</span>
		
		<form id="form-dc-login" class="form-dc form-login" onSubmit="return false">
		  <div class="header-form-dc mt-2">
			<h2>เข้าสู่ระบบ</h2>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-phone-alt icon"></i>
			<input type="text" maxlength="10" name="phone_mb_login" id="phone_mb_login" placeholder="เบอร์โทรศัพท์" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>เบอร์โทรศัพท์</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-key icon"></i>
			<input type="password" name="password_mb_login" id="password_mb_login" placeholder="รหัสผ่าน" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>รหัสผ่าน</small>
		  </div>
		  
		  
		  <div class="row">
			<div class="col-6 col-md-8">
				<button type="submit" class="btn btn-success btn-block">เข้าสู่ระบบ</button>
			</div>
			<div class="col-6 col-md-4">
				<a href="javascript:void(0)" class="btn btn-info btn-block ModalSignup" >สมัครสมาชิก</a>
			</div>
		  </div>
		  
		  <div class="text-center pt-3">
			<span class="txt1">
				ลืมรหัสผ่าน?
			</span>
			<a class="txt2" href="#">
				กู้คืนรหัสผ่าน
			</a>
		  </div>
		</form>
		
    </div>
</div>




<div class="modal-register">
    <div class="modal-content">
        <span class="close-button close-modal-register">×</span>
		
		
		<form id="form-dc-register" class="form-dc form-register" onSubmit="return false">
		  <div class="header-form-dc mt-2">
			<h2>สมัครสมาชิก</h2>
		  </div>
		  
			<input name="status_mb" id="status_mb" type="text" value="2" hidden />
			<input name="ip" id="ip" type="text" value="<?php echo($ipaddress); ?>" hidden />
			<input name="date_mb" id="date_mb" type="text" value="<?php echo $date; ?>" hidden />
			<input name="aff" id="aff" type="text" maxlength="10" value="<?php echo($aff); ?>" hidden />
		
		  <div class="form-control-dc">
			<i class="fas fa-phone-alt icon"></i>
			<input type="text" name="phone_mb" id="phone_mb" maxlength="10" placeholder="เบอร์โทรศัพท์" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>เบอร์โทรศัพท์</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-key icon"></i>
			<input type="password" name="password_mb" id="password_mb" placeholder="รหัสผ่าน" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>รหัสผ่าน</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fab fa-google-wallet icon"></i>
			<input type="text" name="phone_true" id="phone_true" placeholder="ไอดีทรูวอเล็ต หากไม่มีให้ใส่เบอร์โทร" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>ไอดีทรูวอเล็ต หากไม่มีให้ใส่เบอร์โทร</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-university icon"></i>
			<select name="bank_mb" id="bank_mb" class="input100">
			  <option value="">เลือกธนาคาร</option>
			  <option value="ทรูวอเล็ต">ทรูวอเล็ต</option>
			  <option value="ธ.กสิกรไทย">ธ.กสิกรไทย</option>
			  <option value="ธ.กรุงไทย">ธ.กรุงไทย</option>
			  <option value="ธ.กรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
			  <option value="ธ.กรุงเทพ">ธ.กรุงเทพ</option>
			  <option value="ธ.ไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
			  <option value="ธ.ทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
			  <option value="ธ.ออมสิน">ธ.ออมสิน</option>
			  <option value="ธ.ก.ส.">ธ.ก.ส.</option>
			  <option value="ธ.ซีไอเอ็มบี">ธ.ซีไอเอ็มบี</option>
			  <option value="ธ.เกียรตินาคินภัทร">ธ.เกียรตินาคินภัทร</option>
			  <option value="ธ.ทิสโก้">ธ.ทิสโก้</option>
			  <option value="ธ.ยูโอบี">ธ.ยูโอบี</option>
			  <option value="ธ.อิสลาม">ธ.อิสลาม</option>
			  <option value="ธ.ไอซีบีซี">ธ.ไอซีบีซี</option>
			  <option value="ธ.อ.ส">ธ.อ.ส</option>
			  <option value="ธ.แลนด์แอนด์เฮาส์">ธ.แลนด์แอนด์เฮาส์</option>
			</select>
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>เลือกธนาคาร</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-list-ol icon"></i>
			<input type="text" name="bankacc_mb" id="bankacc_mb" maxlength="12" placeholder="เลขบัญชี" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>เลขบัญชี</small>
		  </div>
		  <div class="form-control-dc">
			<i class="fas fa-file-signature icon"></i>
			<input type="text" name="name_mb" id="name_mb" maxlength="50" placeholder="ชื่อ-นามสกุล" />
			<i class="iconst fas fa-check-circle"></i>
			<i class="iconst fas fa-times-circle"></i>
			<small>ชื่อ-นามสกุล</small>
		  </div>
		  
		  
		  <div class="row">
			<div class="col-6 col-md-8">
				<button type="submit" class="btn btn-success btn-block">สมัครสมาชิก</button>
			</div>
			<div class="col-6 col-md-4">
				<a href="javascript:void(0)" class="btn btn-info btn-block ModalSignin" >เข้าสู่ระบบ</a>
			</div>
		  </div>
		</form>
		
		
		
    </div>
</div>



<script>

var form_login = document.getElementById('form-dc-login');
var form_register = document.getElementById('form-dc-register');

form_login.addEventListener('submit', e => {
    e.preventDefault();
    checkInputslogin();
});

form_register.addEventListener('submit', e => {
    e.preventDefault();
    checkInputsregister();
});

function checkInputslogin() {
	
	var phone_mb_login = document.getElementById('phone_mb_login');
	var password_mb_login = document.getElementById('password_mb_login');

    var value_phone_mb = phone_mb_login.value.trim();
    var value_password = password_mb_login.value.trim();
	
	if (value_phone_mb === '') {
	  setErrorFor(phone_mb_login, 'กรุณากรอก เบอร์โทรศัพท์');
	} else if (isPhone(value_phone_mb) === false) {
	  setErrorFor(phone_mb_login, 'เบอร์โทรศัพท์ต้องมีตัวเลข 10 ตัว');
	} else {
	  setSuccessFor(phone_mb_login);
	}

    if (value_password === '') {
        setErrorFor(password_mb_login, 'กรุณากรอก รหัสผ่าน');
    }else {
        setSuccessFor(password_mb_login);
    }
	
	
	var check_login = $('.modal-login .form-login .error');
	if(check_login.length === 0){
		apilogin();
	}

}

function checkInputsregister() {
	
	var phone_mb = document.getElementById('phone_mb');
	var password_mb = document.getElementById('password_mb');
	var phone_true = document.getElementById('phone_true');
	var bank_mb = document.getElementById('bank_mb');
	var bankacc_mb = document.getElementById('bankacc_mb');
	var name_mb = document.getElementById('name_mb');

	
	var value_phone_mb = phone_mb.value.trim();
    var value_password_mb = password_mb.value.trim();
	var value_phone_true = phone_true.value.trim();
    var value_bank_mb = bank_mb.value.trim();
	var value_bankacc_mb = bankacc_mb.value.trim();
    var value_name_mb = name_mb.value.trim();


	if (value_phone_mb === '') {
	  setErrorFor(phone_mb, 'กรุณากรอก เบอร์โทรศัพท์');
	} else if (isPhone(value_phone_mb) === false) {
	  setErrorFor(phone_mb, 'เบอร์โทรศัพท์ต้องมีตัวเลข 10 ตัว');
	} else {
	  setSuccessFor(phone_mb);
	}

	if (value_phone_true === '') {
	  setErrorFor(phone_true, 'กรุณากรอก ไอดีทรู');
	} else {
	  setSuccessFor(phone_true);
	}
	

	if (value_bank_mb === '') {
	  setErrorFor(bank_mb, 'กรุณา เลือกธนาคาร');
	} else {
	  setSuccessFor(bank_mb);
	}
	
	
	if (value_bankacc_mb === '') {
	  setErrorFor(bankacc_mb, 'กรุณากรอก เลขบัญชี');
	} else if (isBankacc(value_bankacc_mb) === false) {
	  setErrorFor(bankacc_mb, 'เลขบัญชีธนาคารมีตั้งแต่ 10 ตัว');
	} else {
	  setSuccessFor(bankacc_mb);
	}
	
	
	if (value_name_mb === '') {
	  setErrorFor(name_mb, 'กรุณากรอก ชื่อจริง-นามสกุลจริง');
	} else {
	  setSuccessFor(name_mb);
	}
	
	
	if (value_password_mb === '') {
	  setErrorFor(password_mb, 'กรุณากรอก รหัสผ่าน');
	} else if (isPassword(value_password_mb) === false) {
	  setErrorFor(password_mb, 'รหัสผ่านต้องมีภาษาอังกฤษและตัวเลข (ผสมกัน) 8-15 ตัว');
	} else {
	  setSuccessFor(password_mb);
	}
	
	
	var check_register = $('.modal-register .form-register .error');
	if(check_register.length === 0){
		apiregister();
	}


}

function setErrorFor(input, message) {
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');
    formControl.className = 'form-control-dc error';
    small.innerText = message;
}

function setSuccessFor(input) {
    const formControl = input.parentElement;
    formControl.className = 'form-control-dc success';
}



//console.log(isPassword2('0945136504dwadfg'));

//console.log(isPhone('0945136504'));

function isPassword1111(password){  
    return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(password);
}


//console.log(isPassword('0945136504sdw'));

function isPassword(password){  
    return /^(?=.*[a-z]).{8,15}$/.test(password);
	//รหัสผ่านต้องมีภาษาอังกฤษและตัวเลข (ผสมกัน) 8-15 ตัว
}

function isPhone(Phone){  
    return /^[0-9]{10,10}$/.test(Phone);
	//เบอร์โทรศัพท์ต้องมีตัวเลข 10 ตัว
}

function isBankacc(Bankacc){  
    return /^[0-9]{10,12}$/.test(Bankacc);
	//เลขบัญชีธนาคารมีตั้งแต่ 10 ตัว
}


function isConfirm(confirm){  
    return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(password);
}




function apilogin() {
    var phone_mb = $("#phone_mb_login").val();
	var password_mb = $("#password_mb_login").val();
    $.ajax({
        type: "POST",
        url: "api/v2/login",
        data: {
            phone_mb:phone_mb,
            password_mb:password_mb,
        },
        success: function(data) {
            var obj = JSON.parse(data);
			if (obj.status=="success"){
				time_add_seconds();
				sessionStorage.setItem("popup", "0");
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='user';
				})
			}else{
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
					
			}
        }
    });

}





function apiregister() {
    var phone_mb = $("#phone_mb").val();
	var phone_true = $("#phone_true").val();
	var password_mb = $("#password_mb").val();
	var bank_mb = $("#bank_mb").val();
	var bankacc_mb = $("#bankacc_mb").val();
    var name_mb = $("#name_mb").val();
	var status_mb = $("#status_mb").val();
	var ip = $("#ip").val();
	var date_mb = $("#date_mb").val();
    var aff = $("#aff").val();
    $.ajax({
        type: "POST",
        url: "api/v2/register",
        data: {
            phone_mb:phone_mb,
            phone_true:phone_true,
            password_mb:password_mb,
            bank_mb:bank_mb,
            bankacc_mb:bankacc_mb,
			name_mb:name_mb,
			status_mb:status_mb,
			ip:ip,
			date_mb:date_mb,
			aff:aff,
        },
        success: function(data) {
            var obj = JSON.parse(data);
            if (obj.status == "success") {
				time_add_seconds();
				
				Swal.fire({
					toast: true,
					icon: 'success',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
                    window.location.href = 'user';
                })
            } else {
				Swal.fire({
					toast: true,
					icon: 'error',
					title: obj.info,
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
            }
        }
    });

}
</script>

