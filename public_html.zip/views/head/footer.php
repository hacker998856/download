


<div style="padding-top: 100px;"></div>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/style-menu-top.js"></script>


<script src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js'></script>
<script src="assets/js/slider-promotion.js"></script>


<?php
if(isset($_SESSION['id_mb'])){
?>

      <script src="assets/js/spinner/superwheel1.js"></script>
      <script src="assets/js/spinner/main1.js"></script>
	  <script src="assets/js/spinner/cryptojs-aes.min.js"></script>
	  <script src="assets/js/spinner/cryptojs-aes-format.js"></script>

<?php
}
?>	

<script type="text/javascript">
console.log(window.location.search);
function time_add_seconds(){

var dd = new Date();
dd.setSeconds(dd.getSeconds() + 31);
var hh = addZero(dd.getHours());
var mm = addZero(dd.getMinutes());
var ss = addZero(dd.getSeconds());
var time = hh + '' + mm + '' + ss;

sessionStorage.setItem("time_session", time);

}

function addZero(i) {
  if (i < 10) {i = "0" + i}
  return i;
}


</script>

<?php
if(!isset($_SESSION['id_mb'])){
?>

<script type="text/javascript">

$(document).ready(function(){
	
	var URL_Aff = window.location.search;
	var AffParams = new URLSearchParams(URL_Aff);
	var AffValue = AffParams.get('aff');
	
	if (AffValue !== null && AffValue !== "") {
		toggleModal_register();
		sessionStorage.setItem("Aff_Session", AffValue);
	}
	
});



</script>


<script type="text/javascript">

const modal_login = document.querySelector(".modal-login");
const modal_register = document.querySelector(".modal-register");

function toggleModal_login() {
	modal_register.classList.remove("show-modal");
    modal_login.classList.toggle("show-modal");
}

function toggleModal_register() {
	modal_login.classList.remove("show-modal");
    modal_register.classList.toggle("show-modal");
}

$('.ModalSignin').click(toggleModal_login);
$('.close-modal-login').click(toggleModal_login);

$('.ModalSignup').click(toggleModal_register);
$('.close-modal-register').click(toggleModal_register);

</script>

<?php
}else{
?>	

<script type="text/javascript">

var function_rungame = document.getElementsByClassName("cn-rungame");
if (function_rungame) {
    Array.from(function_rungame).forEach(function(element) {
        element.addEventListener('click', callrungame);
    });
   }
function callrungame() {
	alert('click');
}

var CopyTo_Clipboard = document.getElementsByClassName("copy-to-clipboard");
if (CopyTo_Clipboard) {
    Array.from(CopyTo_Clipboard).forEach(function(element) {
        element.addEventListener('click', AddToClipboard);
    });
   }
function AddToClipboard() {
   var copyText = $(this).data('copy');
   var elem = document.createElement('textarea');
   elem.value = copyText;
   document.body.appendChild(elem);
   elem.select();
   document.execCommand('copy');
   document.body.removeChild(elem);
   Swal.fire({
		toast: true,
		icon: 'success',
		title: 'คัดลอกแล้ว',
		position: 'top-right',
		showConfirmButton: false,
		timer: 2000,
		timerProgressBar: true,
	})
}

</script>

<script type="text/javascript">
if(sessionStorage.getItem("Aff_Session")) {
	sessionStorage.removeItem("Aff_Session");
}
const modal_Profile = document.querySelector(".modal-profile");

function toggleModal_Profile() {
	$(".menuBtn").click();
    modal_Profile.classList.toggle("show-modal");
}

function CloseModal_Profile() {
    modal_Profile.classList.remove("show-modal");
}

$('.ModalProfile').click(toggleModal_Profile);
$('.close-modal-profile').click(CloseModal_Profile);
</script>

<script type="text/javascript">

function Time_Update_Balance(){

var d = new Date();
var h = addZero(d.getHours());
var m = addZero(d.getMinutes());
var s = addZero(d.getSeconds());
var time = h + '' + m + '' + s;


if(sessionStorage.getItem("time_session")) {
	
	if (time > sessionStorage.getItem("time_session")) {
	
		console.log("Update_Balance");
		time_add_seconds();
		Ajax_Update_Balance();
	
	}
	   
}else{
	
	   time_add_seconds();
	   
}

	 
}


function Check_Deposit(value){
	if (value > sessionStorage.getItem("countdeposit")) {
		Swal.fire({
			icon: 'success',
			title: 'รายการฝากสำเร็จ',
			showConfirmButton: true,
			timer: 5000,
			timerProgressBar: true,
		})
		sessionStorage.setItem("countdeposit", value);
	}else{
		sessionStorage.setItem("countdeposit", value);
	}
}



function Ajax_Update_Balance(){

$.ajax({
        type: "POST",
        url: "api/v2/GetDataResult",
        data: {},
        success: function(data) {
            var obj = JSON.parse(data);
			$('#id_Deposit_All').text(obj.Deposit_All);
			$('#id_Withdraw_All').text(obj.Withdraw_All);
			
			if (sessionStorage.getItem('countdeposit')) {
				Check_Deposit(obj.countdeposit);
			}else{
				sessionStorage.setItem("countdeposit", obj.countdeposit);
			}
			
			if (obj.status=="success"){
				
				$('#id_Balance_1').text(obj.Balance);
				$('#id_Balance_2').text(obj.Balance);

			}
			if (obj.status=="newbalance"){
				
				$('#id_Balance_1').text(obj.Balance);
				$('#id_Balance_2').text(obj.Balance);

			}
			if (obj.status=="error"){
				
				$('#id_Balance_1').text(obj.Balance);
				$('#id_Balance_2').text(obj.Balance);

			}
			
        }
    });	
	
}


$(function(){
	
	Time_Update_Balance();
	setInterval(Time_Update_Balance, 1000);
	
});






</script>

<script type="text/javascript">
$(".check-out").click(function(){

		Swal.fire({
			title: 'คำเตือน',
			text: "คุณต้องการออกจากระบบใช่ไหม",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00C851',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ใช่'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					type:"POST",
					url:"api/v2/logout",
					success:function(data){
						sessionStorage.removeItem("time_session");
						Swal.fire({
							toast: true,
							icon: 'success',
							title: 'ออกจากระบบสำเร็จ',
							position: 'top-right',
							showConfirmButton: false,
							timer: 1000,
							timerProgressBar: true,
						}).then((result) => {
							window.location.href='./home';

						})

					}

				})

			}

		})

	});
</script>



<?php
}
?>


<div id="ProModal-popup" class="modal-popup" >
  <span class="close CloseProModal"><img src="/assets/img/alert/cancel.png" alt="close" style="width:30px; height:30px;"></span>
  <img class="modal-content-popup" id="modalImg">
  
  <div class="modal-body">
		  
		  
			<div class="row justify-content-center align-items-center">
			
			<div class="col-12 col-sm-12 col-md-4 mb-5">
			
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">ลักษณะโบนัส</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no1" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">ยอดฝากขั้นต่ำ</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no2" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">โบนัส</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no3" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">รับโบนัสสูงสุด</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no4" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">เกมส์ที่เล่นได้</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no5" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">เทิร์นโอเวอร์</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no6" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-danger font-weight-bold" style="margin-top: 2px;">ข้อห้าม</h6>
						<span><h6 class="text-danger font-weight-bold h7" style="margin-top: 2px;" id="date_pro_no7" >xxx</h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">ถอนได้</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;" id="date_pro_no8" >xxx</h6></span>
					  </div>
					</div>
				</div>
				
		    </div>
			
			</div>
			
		
		  </div>
  
</div>

<script type="text/javascript">

var modal_view_pro = document.getElementById("ProModal-popup");
var modalImg = document.getElementById("modalImg");

var seleteimg_view_pro = document.querySelectorAll('.classviewpro');
seleteimg_view_pro.forEach(function(element) {
	element.addEventListener('click', function() {
		modal_view_pro.style.display = "block";
		modalImg.src = this.src;
		$('#date_pro_no1').html($(this).data('no1'));
		$('#date_pro_no2').html($(this).data('no2'));
		$('#date_pro_no3').html($(this).data('no3'));
		$('#date_pro_no4').html($(this).data('no4'));
		$('#date_pro_no5').html($(this).data('no5'));
		$('#date_pro_no6').html($(this).data('no6'));
		$('#date_pro_no7').html($(this).data('no7'));
		$('#date_pro_no8').html($(this).data('no8'));
	})
});
var CloseProModal = document.getElementsByClassName("CloseProModal")[0];
CloseProModal.onclick = function() { 
  modal_view_pro.style.display = "none";
}
</script>


</div >
</body>
</html>