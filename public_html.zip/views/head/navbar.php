
<?php if(isset($_SESSION['id_mb'])){ ?>

<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="/"><img src="<?php echo $load_setting->	logo_web; ?>" width="100" class="d-inline-block align-top" alt=""></a>
  
  <div class="collapse navbar-collapse" id="navbarScroll">
    <ul class="navbar-nav mr-auto my-2 my-lg-0 navbar-nav-scroll" style="max-height: 100px;">
	  <li class="nav-item">
        <a class="nav-link" href="/">
			<img src="assets/img/slot.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			เล่นเกมส์
		</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="wallet?open=credit_free">
			<img src="assets/img/bonus.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			เครดิตฟรี
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="wallet?open=spinner">
			<img src="assets/img/spin.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			วงล้อ
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="wallet?open=cashback">
			<img src="assets/img/cashback.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			คืนยอดเสีย
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="wallet">
			<img src="assets/img/wallet.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			กระเป๋า
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="wallet?open=withdraw_deposit">
			<img src="assets/img/money.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			ฝาก-ถอน
		</a>
      </li>
    </ul>
  </div>
<form class="form-inline">
		<div class="dc-navbar-box-item"><img src="assets/img/coin.png" alt="" class="img-fluid"><span id="id_Balance_1"><?php if ($_SESSION["Balance"]=='') { echo "0.00";}else{ echo $_SESSION["Balance"]; }  ?></span></div>
		<div class="dc-navbar-box-item"><img src="assets/img/point.png" alt="" class="img-fluid"><span id="id_diamond_2"><?php if ($_SESSION["diamond"]=='') { echo "0.00";}else{ echo $_SESSION["diamond"]; }  ?></span></div>
	   <div class="menuBtn"><div class="line-1"></div> <div class="line-2"></div> <div class="line-3"></div></div>
</form>
<div class="mainMenu fixed-right">

				<ul>
					<li>
						<div class="mainMenu-box-item"><div class="box-body"><img src="/assets/img/account.png" alt="" class="img-fluid"><span><?php echo $_SESSION["phone_mb"]; ?></span></div></div>
					</li>
					<li>
						
					</li>
					<li>
						<button class="dc-bt-list ModalProfile"><div class="body-img-list"><img src="/assets/img/account.png" /> ข้อมูลบัญชี</div></button>
					</li>
					<li>
						<a href="wallet?open=spinner"><button class="dc-bt-list"><div class="body-img-list"><img src="/assets/img/spin.png" /> วงล้อ</div></button></a>
					</li>
					<li>
						<a href="wallet" ><button class="dc-bt-list"><div class="body-img-list"><img src="/assets/img/wallet.png" /> กระเป๋า</div></button></a>
					</li>
					<li>
						<a href="wallet?open=withdraw_deposit"><button class="dc-bt-list"><div class="body-img-list"><img src="/assets/img/money.png" /> ฝาก-ถอน</div></button></a>
					</li>
					<li>
						<a href="<?php echo $_SESSION["lineoa"]; ?>" ><button class="dc-bt-list"><div class="body-img-list"><img src="/assets/img/line.png" /> ติดต่อพนักงาน</div></button></a>
					</li>
					<li>
						<button class="btn bubbly-button check-out mr-2">ออกจากระบบ</button>
					</li>
				</ul>
		
</div>
</nav>
<div class="showfull"></div>



<div class="modal-profile">
    <div class="modal-content">
        <span class="close-button close-modal-profile">×</span>
		
		  <div class="modal-header">
			<h5 class="modal-title" id="exampleModalLongTitle">ข้อมูลบัญชี</h5>
		  </div>
		  <div class="modal-body">
		  
		  
			<div class="row justify-content-center align-items-center">
			
			<div class="col-12 col-sm-12 col-md-8 mb-5">
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <img class="align-self-center mr-2" style="width: 30px; height 30;" src="./assets/img/item-notify/id.png" alt="...">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">ชื่อนามสกุล</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;"><?php echo $_SESSION["name_mb"]; ?></h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <img class="align-self-center mr-2" style="width: 30px; height 30;" src="./assets/img/item-notify/smartphone.png" alt="...">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">เบอร์โทร</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;"><?php echo $_SESSION["phone_mb"]; ?></h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <img class="align-self-center mr-2" style="width: 30px; height 30;" src="./assets/img/item-notify/bank.png" alt="...">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">ธนาคาร</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;"><?php echo $_SESSION["bank_mb"]; ?></h6></span>
					  </div>
					</div>
				</div>
				<div class="card mb-1" style="border-radius: 10px; background: linear-gradient(rgb(80, 179, 0), rgb(24, 85, 2));">
					<div class="media py-1 px-1">
					  <img class="align-self-center mr-2" style="width: 30px; height 30;" src="./assets/img/item-notify/accountbank.png" alt="...">
					  <div class="media-body text-nowrap pt-2 px-1 d-flex justify-content-between align-items-center" style="border-radius: 10px; background: #fff;">
						<h6 class="text-dark font-weight-bold" style="margin-top: 2px;">เลขบัญชี</h6>
						<span><h6 class="text-dark font-weight-bold" style="margin-top: 2px;"><?php echo $_SESSION["bankacc_mb"]; ?></h6></span>
					  </div>
					</div>
				</div>

				<div class="text-nowrap pt-2 d-flex justify-content-around align-items-center">
						<h6 class="text-success font-weight-bold h7">ยอดฝากรวมทั้งหมด</h6>
						<span><h6 class="text-danger font-weight-bold h7">ยอดถอนรวมทั้งหมด</h6></span>
				</div>
				<div class="text-nowrap d-flex justify-content-around align-items-center">
						<h6 class="text-white font-weight-bold h7" id="id_Deposit_All"><?php echo $_SESSION["Deposit_All"]; ?></h6>
						<span><h6 class="text-white font-weight-bold h7" id="id_Withdraw_All"><?php echo $_SESSION["Withdraw_All"]; ?></h6></span>
				</div>
				
		    </div>
			
			</div>
			
		
		  </div>
		
    </div>
</div>

<?php }else{ ?>

<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="/"><img src="<?php echo $load_setting->	logo_web; ?>" width="100" class="d-inline-block align-top" alt=""></a>
  <div class="collapse navbar-collapse" id="navbarScroll">
    <ul class="navbar-nav mr-auto my-2 my-lg-0 navbar-nav-scroll" style="max-height: 100px;">
      <li class="nav-item">
        <a class="nav-link" href="#">
			<img src="assets/img/bonus.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			เครดิตฟรี
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="#">
			<img src="assets/img/promotion.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			โปรโมชั่น
		</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link ModalSignin" href="javascript:void(0)">
			<img src="assets/img/spin.png" alt="" class="img-fluid d-none d-md-block mx-auto">
			วงล้อ
		</a>
      </li>
    </ul>
  </div>
  <a href="javascript:void(0)" class="ModalSignin" ><button class="btn bubbly-button">เข้าสู่ระบบ</button></a>
</nav>



<?php } ?>

