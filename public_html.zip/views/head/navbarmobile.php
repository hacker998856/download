	
<?php if(isset($_SESSION['id_mb'])){ ?>

<div class="bottom-menu d-xl-none d-lg-none">
	<a href="wallet?open=withdraw_deposit">
    <img src="assets/img/footer-menu/money.png" alt="" class="img-fluid mx-auto">
	ฝาก-ถอน
  </a>
	<a href="wallet?open=cashback">
    <img src="assets/img/footer-menu/cashback.png" alt="" class="img-fluid mx-auto">
	คืนยอดเสีย
  </a>
  <span class="bosluk"></span>
  <a href="/" class="sat">
    <img src="assets/img/footer-menu/slot.png" alt="" class="img-fluid mx-auto">
	เล่นเกม
  </a>
  <a href="wallet?open=credit_free" >
      <img src="assets/img/footer-menu/bonus.png" alt="" class="img-fluid mx-auto">
	เครดิตฟรี
  </a>
   <a href="wallet" >
      <img src="assets/img/footer-menu/wallet.png" alt="" class="img-fluid mx-auto">
	กระเป๋า
  </a>
</div>
	
	

<?php }else{ ?>

<div class="bottom-menu d-xl-none d-lg-none">
	<a href="javascript:void(0)" class="ModalSignin">
      <img src="assets/img/footer-menu/signin.png" alt="" class="img-fluid mx-auto">
      เข้าสู่ระบบ
  </a>
  <span class="bosluk"></span>
  <a href="/" class="sat">
    <img src="assets/img/footer-menu/slot.png" alt="" class="img-fluid mx-auto">
	เล่นเกม
  </a>
   <a href="javascript:void(0)" class="ModalSignup" >
      <img src="assets/img/footer-menu/signup.png" alt="" class="img-fluid mx-auto">
      สมัครสมาชิก
  </a>
</div>



<?php } ?>