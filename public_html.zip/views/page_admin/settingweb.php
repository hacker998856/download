<?php
if($_SESSION["status_ad"] != "Administrator"){
	echo "<script>window.location = './'</script>";
	exit;
}
?>
<?php
$setting = $class_admin->load_db_setting();
?>
<div class="content-wrapper">
	<div class="content">
      <div class="info-box">
		<div class="d-flex">
		  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> ตั้งค่า - เว็บไซต์</h4></div>
		  <div class="col-lg-2 col-4"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
		</div>
		<hr>
		
		<form method="post" id="form_setting" enctype="multipart/form-data">
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ชื่อเว็บไซต์</label>
              <input class="form-control" type="text" name="name_web" id="name_web" value="<?php echo $setting->name_web; ?>" required>
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ลิ้งค์เว็บไซต์</label>
              <input class="form-control" type="text" name="link_web" id="link_web" value="<?php echo $setting->link_web; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ลิ้งค์แนะนำเพื่อน</label>
              <input class="form-control" type="text" name="link_aff" id="link_aff" value="<?php echo $setting->link_aff; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ยูสเซอร์เอเย่นต์</label>
              <input class="form-control" type="text" name="agent" id="agent" value="<?php echo $setting->agent; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รหัสผ่านเอเย่นต์</label>
              <input class="form-control" type="text" name="pass_agent" id="pass_agent" value="<?php echo $setting->pass_agent; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">txtTotal</label>
              <input class="form-control" type="text" name="txtTotal" id="txtTotal" value="<?php echo $setting->txtTotal; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">โลโก้เว็ปไซด์</label>
              <input class="form-control" type="text" name="logo_web" id="logo_web" value="<?php echo $setting->logo_web; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปหน้าปกเว็ปไซด์</label>
              <input class="form-control" type="text" name="pic_web" id="pic_web" value="<?php echo $setting->pic_web; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปหน้า User</label>
              <input class="form-control" type="text" name="pic_user" id="pic_user" value="<?php echo $setting->pic_user; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ข้อความสไลด์ 1</label>
              <input class="form-control" type="text" name="slide_1" id="slide_1" value="<?php echo $setting->slide_1; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ข้อความสไลด์ 2</label>
              <input class="form-control" type="text" name="slide_2" id="slide_2" value="<?php echo $setting->slide_2; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ไลน์ OA</label>
              <input class="form-control" type="text" name="lineoa" id="lineoa" value="<?php echo $setting->lineoa; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ไลน์แจ้งเตือนสมัครสมาชิก</label>
              <input class="form-control" type="text" name="lineregister" id="lineregister" value="<?php echo $setting->lineregister; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ไลน์แจ้งเตือนฝากเงิน</label>
              <input class="form-control" type="text" name="linedeposit" id="linedeposit" value="<?php echo $setting->linedeposit; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ไลน์แจ้งเตือนถอนเงิน</label>
              <input class="form-control" type="text" name="linewithdraw" id="linewithdraw" value="<?php echo $setting->linewithdraw; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">คืนยอดเสีย %</label>
              <input class="form-control" type="text" name="cashback" id="cashback" value="<?php echo $setting->cashback; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">แนะนำเพื่อน %</label>
              <input class="form-control" type="text" name="affcashback" id="affcashback" value="<?php echo $setting->affcashback; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ฝากเงินขั้นต่ำ</label>
              <input class="form-control" type="text" name="set_dp" id="set_dp" value="<?php echo $setting->set_dp; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ถอนเงินขั้นต่ำ</label>
              <input class="form-control" type="text" name="set_wd" id="set_wd" value="<?php echo $setting->set_wd; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">สถานะถอนออโต้</label>
              <select class="custom-select form-control" id="status_auto" name="status_auto">
				  <option selected="selected" value="<?php echo $setting->status_auto; ?>"><?php echo $setting->status_auto; ?></option>
                  <option value="ปิด">ปิด</option>
                  <option value="เปิด">เปิด</option>
              </select>
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">ถอนออโต้สูงสุด</label>
              <input class="form-control" type="text" name="max_autowd" id="max_autowd" value="<?php echo $setting->max_autowd; ?>">
            </fieldset>
          </div>
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">สถานะระบบออโต้</label>
              <select class="custom-select form-control" id="status_auto2" name="status_auto2">
				  <option selected="selected" value="<?php echo $setting->status_auto2; ?>"><?php echo $setting->status_auto2; ?></option>
                  <option value="ปิด">ปิด</option>
                  <option value="เปิด">เปิด</option>
              </select>
            </fieldset>
          </div>
            <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">1 เพชรแลกได้(เครดิต)</label>
              <input class="form-control" type="text" name="change_diamond" id="change_diamond" value="<?php echo $setting->change_diamond; ?>">
            </fieldset>
          </div>
        </div>
		<button type="submit" id="submitclick" class="d-none" ></button>
		</form>
		
    </div>
</div>

<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});

</script>
<script type="text/javascript">
$("#form_setting").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","setting");
formData.append("WHERE_NAME","id");
formData.append("WHERE_VALUE","1");
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				//console.log(data);
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>