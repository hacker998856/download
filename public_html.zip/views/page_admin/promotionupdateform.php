<?php
$id = $_GET['id'];
$sql = "SELECT * FROM promotion WHERE id = '$id' ";
$setting_promotion = $class_admin->load_db_date($sql);
?>
<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/settingpromotion"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> แก้ไข - โปรโมชั่น</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
			</div>
			<hr>
			
			<form id="form_promotionupdateform" method="POST" enctype="multipart/form-data">
			<input class="d-none" type="" name="id" value="<?php echo $id; ?>">
			<div class="row">
			
			  <div class="col-lg-3">
					<img class="card-img-top img-responsive" src="/slip/<?php echo $setting_promotion->fileupload_pro; ?>" alt="Card image cap">
			  </div>
			  
			  <div class="col-lg-9">
				<div class="row">
				
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">ชื่อโปรโมชั่น</label>
					  <input class="form-control" type="text" name="name_pro" value="<?php  echo $setting_promotion->name_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">ลักษณะโบนัส</label>
					  <select class="custom-select form-control" name="time_pro">
						  <option value="<?php echo $setting_promotion->time_pro; ?>"><?php echo $setting_promotion->time_pro; ?></option>
                          <option value="สมาชิกใหม่">สมาชิกใหม่</option>
                          <option value="รับได้ครั้งเดียว">รับได้ครั้งเดียว</option>
                          <option value="รับได้วันละ 1 ครั้ง">รับได้วันละ 1 ครั้ง</option>
                          <option value="รับได้ทุกครั้ง">รับได้ทุกครั้ง</option>
					  </select>
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">ยอดฝากขั้นต่ำ</label>
					  <input class="form-control" type="text" name="dp_pro" value="<?php  echo $setting_promotion->dp_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">โบนัส (แบบกำหนดจำนวนเงิน)</label>
					  <input class="form-control" type="text" name="bonus_pro" value="<?php  echo $setting_promotion->bonus_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">โบนัส (แบบเปอร์เซ็นต์)</label>
					  <input class="form-control" type="text" name="bonusper_pro" value="<?php  echo $setting_promotion->bonusper_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">รับได้สูงสุด</label>
					  <input class="form-control" type="text" name="max_pro" value="<?php  echo $setting_promotion->max_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">เกมส์ที่เล่นได้</label>
					  <input class="form-control" type="text" name="games_pro" value="<?php  echo $setting_promotion->games_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">เทิร์นโอเวอร์</label>
					  <input class="form-control" type="text" name="turn_pro" value="<?php  echo $setting_promotion->turn_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">กติกา</label>
					  <input class="form-control" type="text" name="rules_pro" value="<?php  echo $setting_promotion->rules_pro; ?>">
					</fieldset>
				  </div>
				  <div class="col-lg-4">
					<fieldset class="form-group">
					  <label class="control-label-dc">ถอนได้สูงสุด</label>
					  <input class="form-control" type="text" name="wd_pro" value="<?php  echo $setting_promotion->wd_pro; ?>">
					</fieldset>
				  </div>
				  
				  <div class="col-lg-2">
					<fieldset class="form-group text-center">
						<label class="control-label-dc">แสดงเฉพาะรูป</label>
						<div class="form-check form-switch form-switch-md">
							<input class="form-check-input" type="checkbox" name="showpic" id="showpic" <?php if ($setting_promotion->showpic == "เปิด")  { ?> checked <?php } ?> >
						</div>
					</fieldset>
				  </div>
				  
				  <div class="col-lg-2">
					<fieldset class="form-group text-center">
						<label class="control-label-dc">สถานะ</label>
						<div class="form-check form-switch form-switch-md">
							<input class="form-check-input" type="checkbox" name="status_pro" id="status_pro" <?php if ($setting_promotion->status_pro == "เปิด")  { ?> checked <?php } ?> >
						</div>
					</fieldset>
				  </div>
				  
				</div>
			  </div>
			</div>
			<button type="submit" id="submitclick" class="d-none" ></button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
	$("#form_promotionupdateform").on("submit",function(e){
        e.preventDefault();
		var showpic = $('#showpic').is(":checked") ? 'เปิด':'ปิด';
		var status_pro = $('#status_pro').is(":checked") ? 'เปิด':'ปิด'; 
        var formData = new FormData($(this)[0]);
		formData.append("showpic",showpic);
		formData.append("status_pro",status_pro);
		formData.append("TABLE_NAME","promotion");
		formData.append("WHERE_NAME","id");
		formData.append("WHERE_VALUE",formData.get('id'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='./settingpromotion';
				})
			}
        });    
    });
</script>