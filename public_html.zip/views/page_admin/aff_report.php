<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-clipboard-list"></i> รายการแนะนำเพื่อน</h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-4">
					<div class="form-group has-feedback">
						<label class="control-label">กรอกรหัสแนะนำเพื่อน</label>
						<input class="form-control" id="input_search" type="text"> </div>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="button_input_search" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
				</div>

			</div>
			<hr>
			<h5 class="text-black"><i class="fas fa-file-search"></i><span id="ShowDateAff"> รหัสแนะนำ : </span></h5>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ยอดเงินฝากทั้งหมด</th>
							<th scope="col">ยอดเงินถอนทั้งหมด</th>
							<th scope="col">กำไร-ขาดทุน</th>
						</tr>
					</thead>
					<tbody id="showdateget">

					</tbody>
				</table>
			</div>
		</div>
		
		
		<div class="info-box">
			<h5 class="text-black"><i class="fas fa-check"></i> ทำรายการแล้ว</h5>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">สถานะ</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">ยอดเงินถอน</th>
							<th scope="col">ธนาคารที่ใช้ถอน</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เวลา</th>
							<th scope="col">แก้ไข</th>
						</tr>
					</thead>
					<tbody>
<?php 
$sql_aff = "SELECT * FROM withdrawaff WHERE confirm_aff != 'รอดำเนินการ' ORDER BY id DESC";
$load_date_aff = $class_admin->load_date_sql($sql_aff);
while($row = mysqli_fetch_array($load_date_aff)) {
?>
						<tr>
							<td class="align-middle">
								<div class="btn-group">
<?php
if ($row["confirm_aff"]=="รอดำเนินการ") {
				echo"<span class='btn btn-info btn-sm noHover'><i class='fas fa-spinner fa-spin'></i> กำลังดำเนินการ</span>";
				echo"<a href='/admin/withdrawaffupdateform?id=$row[0]' class='btn btn-success btn-sm'><i class='fas fa-eye'></i> ตรวจสอบ</a>";
}
if ($row["confirm_aff"]=="อนุมัติ") {
				echo"<span class='btn btn-success btn-sm px-4 noHover'><i class='fas fa-check'></i> อนุมัติ</span>";
}
if ($row["confirm_aff"]=="ปฏิเสธ") {
				echo"<span class='btn btn-sm btn-danger px-4 noHover'><i class='fas fa-times'></i> ปฏิเสธ</span>";
}
?>
								</div>
							</td>
							<td class="align-middle"><?php echo $Get_Setting->agent . $row["username_aff"];?></td>
							<td class="align-middle"><?php echo $row["amount_aff"]; ?></td>
							<td class="align-middle"><?php echo $row["bankout_aff"]; ?></td>
							<td class="align-middle"><?php echo $row["phone_aff"]; ?></td>
							<td class="align-middle"><?php echo $row["name_aff"]; ?></td>
							<td class="align-middle"><?php echo $row["date_aff"]; ?></td>
							<td class="align-middle"><a href="/admin/withdrawaffupdateform?id=<?php echo $row[0]; ?>" class="btn btn-sm btn-info px-4"><i class="fas fa-edit"></i> แก้ไข</a></td>
						</tr>
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function showdatelist(GetDate) {
	console.log(GetDate.result);
	$('#showdateget').html('');
	html = "";
	$.each(GetDate.result, function( index, value ) {
		html += '<tr>';
		html += '<th scope="col">' + value.username_mb + '</th>';
		html += '<th scope="col">' + value.name_mb + '</th>';
		html += '<th scope="col">' + value.phone_mb + '</th>';
		html += '<th scope="col">' + value.sumdp + '</th>';
		html += '<th scope="col">' + value.sumwd + '</th>';
		html += '<th scope="col">' + value.summary + '</th>';
		html += '</tr>';
	});
	$('#showdateget').html(html);
	var input_search = $("#input_search").val();
	$('#ShowDateAff').html(' รหัสแนะนำ : <span class="label label-success">' + input_search + '</span> จำนวนสมาชิก : <span class="label label-warning">' + GetDate.numteam + ' คน</span> รายได้ : <span class="label label-warning">' + GetDate.amount + ' บาท</span></span>');
	//$('#ShowToDay').html(GetDate.ShowToDay);
}
</script>
<script type="text/javascript">
$("#button_input_search").click(function(){
	
var input_search = $("#input_search").val();
var search = '';
if (input_search == '') {
	
$('#input_search').closest('.form-group').addClass('has-error');

}else{
$('#input_search').closest('.form-group').removeClass('has-error');
$.ajax({
      type: "POST",
      url: "/api/admin/loadaffreport",
      data: {
          search:search,
          input_search:input_search,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  }
      }
  });
  
}
  
});
</script>