<?php
if($_SESSION["status_ad"] != "Administrator"){
	echo "<script>window.location = './'</script>";
	exit;
}
?>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> ตั้งค่า - โปรโมชั่น</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" class="btn btn-sm btn-success btn-block p-2" data-toggle="modal" data-target="#myModal"><i class="fas fa-plus-circle"></i> เพิ่มโปรโมชั่น</button></div>
			</div>
			<hr>
			<div class="row">
<?php 
$sql_promotion = "SELECT * FROM promotion ORDER BY id desc";
$load_date_promotion = $class_admin->load_date_sql($sql_promotion);
while($row = mysqli_fetch_array($load_date_promotion)) {

if ($row["bonus_pro"]=="0") {
	$status_bonus = $row["bonusper_pro"].' เปอร์เซ็นต์';
}
if ($row["bonus_pro"]!='0') {
	$status_bonus = $row["bonus_pro"];
}
?>
		  <div class="col-lg-3 m-b-3"> 
            <div class="card">
			<img class="card-img-top img-responsive" src="/slip/<?php echo $row["fileupload_pro"]; ?>" alt="Card image cap">
              <div class="card-body">
                <h5 class="card-title"><?php echo $row["name_pro"]; ?></h5>
				  <strong>ลักษณะโบนัส</strong>
				  <p class="text-muted"><?php echo $row["time_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>ยอดฝากขั้นต่ำ</strong>
				  <p class="text-muted"><?php echo $row["dp_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>โบนัส</strong>
				  <p class="text-muted"><?php echo $status_bonus; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>รับโบนัสสูงสุด</strong>
				  <p class="text-muted"><?php echo $row["max_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>เกมส์ที่เล่นได้</strong>
				  <p class="text-muted"><?php echo $row["games_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>เทิร์นโอเวอร์</strong>
				  <p class="text-muted"><?php echo $row["turn_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>ข้อห้าม</strong>
				  <p class="text-muted"><?php echo $row["rules_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <strong>ถอนได้</strong>
				  <p class="text-muted"><?php echo $row["wd_pro"]; ?></p>
				  <hr class="mt-0 m-b-1">
				  <div class="row text-center">
					<div class="col-lg-6 col-6 align-middle">
						<label class="control-label-dc">แสดงเฉพาะรูป</label>
						<div class="form-check form-switch form-switch-md">
							<input class="form-check-input" type="checkbox" value="<?php echo $row[0]; ?>" onclick='ShowpicClick(this);' <?php if ($row["showpic"] == "เปิด")  { ?> checked <?php } ?> >
						</div>
					</div>
					<div class="col-lg-6 col-6">
						<label class="control-label-dc">สถานะ</label>
						<div class="form-check form-switch form-switch-md">
							<input class="form-check-input" type="checkbox" value="<?php echo $row[0]; ?>" onclick='StatusProClick(this);' <?php if ($row["status_pro"] == "เปิด")  { ?> checked <?php } ?> >
						</div>
					</div>
				  </div>
				  <hr class="mt-0">
                <div class="row">
					<div class="col-lg-6 col-6">
						<a href="/admin/promotionupdateform?id=<?php echo $row[0]; ?>" class="btn btn-sm btn-info px-4"><i class="fas fa-edit"></i> แก้ไข</a>
					</div>
					<div class="col-lg-6 col-6">
						<button type="button" class="btn btn-sm btn-danger btn-block startdelete" data-id="<?php echo $row[0]; ?>"><i class="fas fa-trash-alt"></i> ลบ</button>
					</div>
				</div>
			  </div>
            </div>
          </div>
<?php } ?>			  
          
		  
		  
		  
		  
		  
		  
       </div>
		</div>
		
	</div>
</div>
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="card">
      <div class="card-header">
        <div class="clearfix">
          <span class="float-left h4">
            <i class="fas fa-plus-circle"></i> เพิ่ม เพิ่มโปรโมชั่น </span>
          <span class="float-right text-danger" data-dismiss="modal">
            <i class="fas fa-window-close fa-2x"></i>
          </span>
        </div>
      </div>
	  
	  <form method="post" id="form_promotion" enctype="multipart/form-data">
      <div class="card-body">
        <div class="row">
		  <div class="col-lg-12">
            <div class="form-group container">
              <label class="control-label-dc">รูปโปรโมชั่น</label>
               <input type="file" class="dropify" name="fileupload_pro" required>
            </div>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ชื่อโปรโมชั่น</label>
              <input class="form-control" type="text" name="name_pro" required>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ลักษณะโบนัส</label>
              <select class="custom-select form-control" name="time_pro" required>
                <option value="สมาชิกใหม่">สมาชิกใหม่</option>
			    <option value="รับได้ครั้งเดียว">รับได้ครั้งเดียว</option>
			    <option value="รับได้วันละ 1 ครั้ง">รับได้วันละ 1 ครั้ง</option>
			    <option value="รับได้ทุกครั้ง">รับได้ทุกครั้ง</option>
              </select>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ยอดฝากขั้นต่ำ</label>
              <input class="form-control" type="text" name="dp_pro">
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">โบนัส (แบบกำหนดจำนวนเงิน)</label>
              <input class="form-control" type="text" placeholder="ถ้าไม่มีให้ใส่ 0" name="bonus_pro" required>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">โบนัส (แบบเปอร์เซ็นต์)</label>
              <input class="form-control" type="text" name="bonusper_pro" placeholder="ถ้าไม่มีให้ใส่ 0" required>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">รับได้สูงสุด</label>
              <input class="form-control" type="text" name="max_pro" placeholder="ใส่จำนวนโบนัสสูงสุด" required>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">เกมส์ที่เล่นได้</label>
              <input class="form-control" type="text" name="games_pro">
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">เทิร์นโอเวอร์</label>
              <input class="form-control" type="text" name="turn_pro">
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">กติกา</label>
              <input class="form-control" type="text" name="rules_pro">
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ถอนได้สูงสุด</label>
              <input class="form-control" type="text" name="wd_pro">
            </fieldset>
          </div>
          <div class="col-lg-6 col-6">
            <fieldset class="form-group text-center">
              <label class="control-label-dc">แสดงเฉพาะรูปเท่านั้น</label>
              <div class="form-check form-switch form-switch-md">
				<input class="form-check-input" type="checkbox" id="showpic" checked >
			  </div>
            </fieldset>
          </div>
		  <div class="col-lg-6 col-6">
            <fieldset class="form-group text-center">
              <label class="control-label-dc">สถานะ</label>
              <div class="form-check form-switch form-switch-md">
				<input class="form-check-input" type="checkbox" id="status_pro" checked>
			  </div>
            </fieldset>
          </div>
        </div>
      </div>
	  <button type="submit" id="submitclick" class="d-none" ></button>
	  </form>
	  
      <div class="card-footer">
        <button type="button" id="settingsubmit" class="btn btn-success float-right">
          <i class="fas fa-save"></i> ยืนยัน </button>
      </div>
    </div>
  </div>
</div>

<script src="/assets/admin/plugins/dropify/dropify.min.js"></script> 
<script>
$(document).ready(function(){

$('.dropify').dropify({
    messages: {
        'default': 'ลากและวางไฟล์ที่นี่หรือคลิก',
        'replace': 'ลากและวางหรือคลิกเพื่อแทนที่',
        'remove':  'ลบ',
        'error':   'อ๊ะ มีบางอย่างผิดปกติเกิดขึ้น'
    }
});

});
</script>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
$("#form_promotion").on("submit",function(e){
        e.preventDefault();
		var Showpic_checked = $('#showpic').is(":checked") ? 'เปิด':'ปิด';
		var StatusPro_checked = $('#status_pro').is(":checked") ? 'เปิด':'ปิด'; 
        var formData = new FormData($(this)[0]);
		formData.append("showpic",Showpic_checked);
		formData.append("status_pro",StatusPro_checked);
        $.ajax({
            url: '/api/admin/addpromotion',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				//console.log(data);
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					$('#closemodal_1').click();
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					}).then((result) => {
						window.location.href='./settingpromotion';
					})
					
					
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>
<script type="text/javascript">
function ShowpicClick(checkbox) {
var TABLE_NAME = "promotion";
var SET_NAME = "showpic";
var WHERE_NAME = "id";
    if(checkbox.checked){
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"เปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
    else{
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"ปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
}
</script>
<script type="text/javascript">
function StatusProClick(checkbox) {
var TABLE_NAME = "promotion";
var SET_NAME = "status_pro";
var WHERE_NAME = "id";
    if(checkbox.checked){
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"เปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
    else{
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"ปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
}
</script>
<script type="text/javascript">
var function_delete_id = document.getElementsByClassName("startdelete");
if (function_delete_id) {
    Array.from(function_delete_id).forEach(function(element) {
        element.addEventListener('click', Call_delete_id);
    });
   }
function Call_delete_id() {
	    var id = $(this).data('id');
		Swal.fire({
			title: 'คำเตือน',
			text: "คุณต้องการ ลบ ใช่ไหม",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00C851',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ใช่'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					type:"POST",
					data: {
					   'FROM_NAME' : 'promotion',
					   'WHERE_NAME' : 'id',
					   'WHERE_VALUE' : id,
					},
					url:"/api/admin/run_delete_sql",
					success:function(data){
						Swal.fire({
							icon: 'success',
							title: 'ลบรายการ สำเร็จ',
							showConfirmButton: false,
							timer: 2000,
							timerProgressBar: true,
						}).then((result) => {
							window.location.href='./settingpromotion';
						})

					}

				})

			}

		})
}
</script>
