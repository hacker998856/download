<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/settingannounce"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<?php
$dirname = "assets/img/popup/";
$images = scandir($dirname);
$ignore = Array(".", "..");
foreach($images as $curimg){
    if(!in_array($curimg, $ignore)) {
		$showimg = "<img class='card-img-top img-responsive' src='/assets/img/popup/$curimg' style='max-width: 100%;' alt='Card image cap'>";
    }
}
?>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> แก้ไข - ประกาศ</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
			</div>
			<hr>
			
			<form id="form_announcepopup" method="POST" enctype="multipart/form-data">
			<div class="row">
			  <div class="col-lg-3">
					<?php echo $showimg; ?>
			  </div>
			  <div class="col-lg-3">
					<div class="form-group container">
					  <label class="control-label-dc">อัพโหลด รูปประกาศ</label>
					  <input type="file" class="dropify" name="fileupload" accept=".png, .jpg" required>
					</div>
			  </div>
			</div>
			<button type="submit" id="submitclick" class="d-none" ></button>
			</form>
			
		</div>
	</div>
</div>

<script src="/assets/admin/plugins/dropify/dropify.min.js"></script> 
<script>
$(document).ready(function(){

$('.dropify').dropify({
    messages: {
        'default': 'ลากและวางไฟล์ที่นี่หรือคลิก',
        'replace': 'ลากและวางหรือคลิกเพื่อแทนที่',
        'remove':  'ลบ',
        'error':   'อ๊ะ มีบางอย่างผิดปกติเกิดขึ้น'
    }
});

});
</script>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
$("#form_announcepopup").on("submit",function(e){
e.preventDefault();
$.ajax({
    url: "/api/admin/announcepopup",
    type: "POST",
    data: new FormData(this),
    contentType: false,
    cache: false,
    processData: false,
    success: function(data)
    {
		
	Swal.fire({
		icon: 'success',
		title: 'อัพโหลด สำเร็จ',
		showConfirmButton: false,
		timer: 2000,
		timerProgressBar: true,
	}).then((result) => {
		window.location.href='./settingannounce';
	});

    }
});

});
</script>