<?php
$load_page_report = $class_admin->load_page_report();

print "<pre>";
//print_r($load_page_report);
print "</pre>";
?>


<div class="content-wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-clipboard-list"></i> รายการฝากล่าสุด</h4>
					<hr>
					<div class="table-responsive">
						<table id="Table1" class="table table-bordered text-nowrap text-center">
							<thead class="text-black">
								<tr>
									<th scope="col">เบอร์โทรศัพท์</th>
									<th scope="col">ชื่อ-นามสกุล</th>
									<th scope="col">ยอดฝาก</th>
									<th scope="col">โปรโมชั่น</th>
									<th scope="col">วันเวลาที่ฝาก</th>
								</tr>
							</thead>
							<tbody>
<?php 
$sql_deposit = "SELECT * FROM deposit WHERE confirm_dp ='อนุมัติ' AND bankin_dp!='ไม่ถูกต้อง' ORDER BY id desc LIMIT 5";
$load_date_deposit = $class_admin->load_date_sql($sql_deposit);
while($row = mysqli_fetch_array($load_date_deposit)) {
?>
								<tr>
									<td class="align-middle"><?php echo $row["phone_dp"]; ?></td>
									<td class="align-middle"><?php echo $row["name_dp"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_dp"]; ?></td>
									<td class="align-middle"><?php echo $row["promotion_dp"]; ?></td>
									<td class="align-middle"><?php echo $row["date_dp"]; ?></td>
								</tr>	
<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-clipboard-list"></i> รายการถอนล่าสุด</h4>
					<hr>
					<div class="table-responsive">
						<table class="table table-bordered text-nowrap text-center">
							<thead class="text-black">
								<tr>
									<th scope="col">เบอร์โทรศัพท์</th>
									<th scope="col">ชื่อ-นามสกุล</th>
									<th scope="col">ยอดถอน</th>
									<th scope="col">วันเวลาที่ถอน</th>
								</tr>
							</thead>
							<tbody>
<?php
$sql_withdraw = "SELECT * FROM withdraw WHERE confirm_wd ='อนุมัติ' AND amount_wd!='' ORDER BY id desc LIMIT 5";
$load_date_withdraw  = $class_admin->load_date_sql($sql_withdraw);
while($row = mysqli_fetch_array($load_date_withdraw)) {
?>
								<tr>
									<td class="align-middle"><?php echo $row["phone_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["name_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["date_wd"]; ?></td>
								</tr>	
<?php } ?>	
								
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-chart-pie"></i> รายงานสรุปกำไร - ขาดทุน</h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label">จากวันที่ :</label>
						<input class="form-control" id="FromDay" type="text"> </div>
				</div>
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label">ถึงวันที่ :</label>
						<input class="form-control" id="ToDay" type="text"> </div>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonsearch" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttontoday" class="btn btn-sm btn-primary btn-block p-2"> วันนี้</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonyesterday" class="btn btn-sm btn-primary btn-block p-2">เมื่อวาน</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonthismonth" class="btn btn-sm btn-primary btn-block p-2">เดือนนี้</button>
				</div>
			</div>
			<hr>
			<h5 class="text-black"><i class="fas fa-file-search"></i> รายงานประจำวันที่</h5>
			<h6 class="text-black"><span id="ShowFromDay" >×</span> ถึง <span id="ShowToDay" >×</span></h6>
			<hr>
			<div class="table-responsive">
				<table id="testtable" class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">ยอดฝาก</th>
							<th scope="col">ยอดถอน</th>
							<th scope="col">กำไร-ขาดทุน</th>
						</tr>
					</thead>
					<tbody id="showdateget">
						<tr>
							<td></td>
							<td></td>
							<td></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

function showdatelist(GetDate) {
	$('#showdateget').html('');
	html = "";
	html += '<tr>';
	html += '<th scope="col">' + GetDate.totalnumber_deposit + '</th>';
	html += '<th scope="col">' + GetDate.totalnumber_withdraw + '</th>';
	html += '<th scope="col">' + GetDate.total + '</th>';
	html += '</tr>';
	$('#showdateget').html(html);
	$('#ShowFromDay').html(GetDate.ShowFromDay);
	$('#ShowToDay').html(GetDate.ShowToDay);
}
</script>

<script type="text/javascript">
$("#buttonsearch").click(function(){
var FromDay = $("#FromDay").val();
var ToDay = $("#ToDay").val();
$.ajax({
      type: "POST",
      url: "/api/admin/loaddatereport",
      data: {
          FromDay:FromDay,
          ToDay:ToDay,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});

$("#buttontoday").click(function(){
var today = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loaddatereport",
      data: {
          today:today
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});

$("#buttonyesterday").click(function(){
var yesterday = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loaddatereport",
      data: {
          yesterday:yesterday
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});

$("#buttonthismonth").click(function(){
var thismonth = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loaddatereport",
      data: {
          thismonth:thismonth
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
jQuery.datetimepicker.setLocale('th');
jQuery('#FromDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
jQuery('#ToDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
</script>
