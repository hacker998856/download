<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/allmember"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<?php
$id = $_GET['id'];
$sql = "SELECT * FROM member WHERE id_mb = '$id'";
$date_member = $class_admin->load_db_date($sql);
?>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-plus-circle"></i> เพิ่มรายการฝาก</h4>
			<hr>
			<h6 class="text-black"><?php echo $Get_Setting->agent; ?><?php echo $date_member->username_mb; ?> : <?php echo $date_member->name_mb; ?></h6>
			<hr>
			
			<form method="post" id="form_depositform_user" enctype="multipart/form-data">
			<div class="row mb-3">
			<input type="text" name="phone_mb" value="<?php echo $date_member->phone_mb; ?>" hidden>
				<div class="col-md-4 col-lg-3">
					<div class="form-group has-feedback">
						<label class="control-label-dc">ใส่ยอดเงินที่ต้องการฝาก</label>
						<input class="form-control" name="amount_dp" type="text" required>
					</div>
				</div>
				<div class="col-md-4 col-lg-3">
					<div class="form-group has-feedback">
						<label class="control-label-dc">เลือกรับโปรโมชั่นที่ท่านต้องการ</label>
						<select class="custom-select form-control" name="promotion_dp" required>
							<option></option>
							<option value="ไม่รับโบนัส">ไม่รับโบนัส ไม่ต้องทำเทิร์น</option>
                            <option value="เครดิตฟรี">เครดิตฟรี</option>
							<?php
                                $query = "SELECT * FROM promotion ORDER BY id desc";
								$result = $class_admin->load_date_sql($query);
                                while($row = mysqli_fetch_array($result)) {
                                 echo '<option value="'.$row["name_pro"].'">'.$row["name_pro"].'</option>';
                                } ?>
						</select>
					</div>	
				</div>
				<div class="col-md-2 col-lg-3 mt-2 align-self-center">
					<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-check"></i> ทำรายการ</button>
				</div>
			</div>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$("#form_depositform_user").on("submit",function(e){
e.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: '/api/admin/depositformuser',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>
