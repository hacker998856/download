<?php
$id = $_GET['id'];
$sql = "SELECT * FROM member WHERE id_mb = '$id'";
$date_member = $class_admin->load_db_date($sql);
?>

<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/allmember"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>

<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-plus-square"></i> เพิ่มเครดิต - <?php echo $Get_Setting->agent; ?><?php echo $date_member->username_mb; ?> : <?php echo $date_member->name_mb; ?></h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-3">
					<div class="form-group has-feedback">
						<label class="control-label">ใส่จำนวนเครดิตที่ต้องการเติม</label>
						<input class="form-control" id="amount" type="text">
					</div>
				</div>
				<input type="text" id="username" value="<?php echo $Get_Setting->agent; ?><?php echo $date_member->username_mb; ?>" hidden>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="addsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-check"></i> เพิ่มเครดิต</button>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$('#addsubmit').click(function(e){
e.preventDefault();
var username = $("#username").val();
var amount = $("#amount").val();
if (amount == '') {
$('#amount').closest('.form-group').addClass('has-error');
}else{
$('#amount').closest('.form-group').removeClass('has-error');
		$.ajax({
            url: '/api/admin/addcredit',
            type: 'POST',
            data: {
				username:username,
				amount:amount,
			},
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status == 'success') {
					Swal.fire({
						icon: 'success',
						title: 'เพิ่มเครดิต สำเร็จ',
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด ' + obj.status,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				} 
			}
        });
}		
});

</script>