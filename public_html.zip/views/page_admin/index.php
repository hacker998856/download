<?php
if(!isset($_SESSION['id_ad'])){
	echo "<script>window.location = './login'</script>";
	exit;
}
?>
<div class="content-wrapper">
	<!-- Main content -->
	<div class="content">
		<!-- Small boxes (Stat box) -->
		<div class="row">
			<div class="col-lg-3 col-6">
				<div class="info-box bg-darkblue"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-users text-white"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">สมาชิกทั้งหมด</h4>
						<h2 class="text-white" id="allmembers">0</h2> <span class="progress-description text-white d-sm-none d-md-none">สมาชิกทั้งหมด</span></div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-green text-white"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-sack-dollar"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">รายได้วันนี้</h4>
						<h2 class="text-white" id="TotalAmount">0</h2> <span class="progress-description text-white d-sm-none d-md-none">รายได้วันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-green text-white"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-chart-line"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ยอดฝากวันนี้</h4>
						<h2 class="text-white" id="SUM_Amount_DP_ToDay">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ยอดฝากวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-orange"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-chart-line-down"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ยอดถอนวันนี้</h4>
						<h2 class="text-white" id="SUM_Amount_WD_ToDay">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ยอดถอนวันนี้ </span> </div>
				</div>
				
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-blue"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-file-invoice-dollar"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">จำนวนบิลฝากวันนี้</h4>
						<h2 class="text-white" id="bill_DP">0</h2> <span class="progress-description text-white d-sm-none d-md-none">จำนวนบิลฝากวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-light-blue"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-file-invoice-dollar"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">จำนวนบิลถอนวันนี้</h4>
						<h2 class="text-white" id="bill_WD">0</h2> <span class="progress-description text-white d-sm-none d-md-none">จำนวนบิลถอนวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-purple"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-hand-holding-usd"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">รับยอดเสียรวมวันนี้</h4>
						<h2 class="text-white" id="amount_cashback">0</h2> <span class="progress-description text-white d-sm-none d-md-none">รับยอดเสียรวมวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-secondary"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-link text-white"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ยอดถอนแนะนำเพื่อน</h4>
						<h2 class="text-white" id="amount_aff">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ยอดถอนแนะนำเพื่อน </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-red"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-users-crown"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">สต็อกที่สมัครได้</h4>
						<h2 class="text-white" id="stockmembers">0</h2> <span class="progress-description text-white d-sm-none d-md-none">สต็อกที่สมัครได้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-yellow"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-exchange"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">แลกพ้อยด์</h4>
						<h2 class="text-white" id="change_point">0</h2> <span class="progress-description text-white d-sm-none d-md-none">แลกพ้อยด์ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-fuchsia"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-chart-bar"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">จำนวนสมาชิกฝากเงินวันนี้</h4>
						<h2 class="text-white" id="members_deposit_today">0</h2> <span class="progress-description text-white d-sm-none d-md-none">จำนวนสมาชิกฝากเงินวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-navy"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-coins"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">เครดิตคงเหลือ</h4>
						<h2 class="text-white" id="credit_ufa">0</h2> <span class="progress-description text-white d-sm-none d-md-none">เครดิตคงเหลือ </span> </div>
				</div>
			</div>
			<div class="col-lg-3 col-6">
				<div class="info-box bc-colored bg-success"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-gift"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ยอดโบนัสวันนี้</h4>
						<h2 class="text-white" id="bonustoday">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ยอดโบนัสวันนี้ </span> </div>
				</div>
			</div>
			<div class="col-lg-12 col-12"><hr></div>
			
			<?php
			$sqlscb = "SELECT * FROM bank WHERE name_bank = 'ธนาคารไทยพาณิชย์'";
			$load_date_scb = $class_admin->load_date_sql($sqlscb);
			$num_scb = mysqli_num_rows($load_date_scb);
			if($num_scb > 0){
			?>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-purple"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-university"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ธนาคารไทยพาณิชย์</h4>
						<h2 class="text-white" id="credit_scb">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ธนาคารไทยพาณิชย์ </span> </div>
				</div>
			</div>
			<?php } ?>
			<?php
			$sqlkbank = "SELECT * FROM bank WHERE name_bank = 'ธนาคารกสิกรไทย'";
			$load_date_kbank = $class_admin->load_date_sql($sqlkbank);
			$num_kbank = mysqli_num_rows($load_date_kbank);
			if($num_kbank > 0){
			?>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-green"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-university"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ธนาคารกสิกรไทย</h4>
						<h2 class="text-white" id="credit_kbank">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ธนาคารกสิกรไทย </span> </div>
				</div>
			</div>
			<?php } ?>
			
			<?php
			$sqltruewallet = "SELECT * FROM bank WHERE name_bank = 'ทรูวอเล็ต'";
			$load_date_truewallet = $class_admin->load_date_sql($sqltruewallet);
			$num_truewallet = mysqli_num_rows($load_date_truewallet);
			if($num_truewallet > 0){
			?>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-yellow"> <span class="info-box-icon bg-transparent text-white"><i class="fab fa-google-wallet"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ทรูวอเล็ต</h4>
						<h2 class="text-white" id="credit_true">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ทรูวอเล็ต </span> </div>
				</div>
			</div>
			<?php } ?>
			
			<?php
			$sqlsaving = "SELECT * FROM bank WHERE name_bank = 'ธนาคารออมสิน'";
			$load_date_saving = $class_admin->load_date_sql($sqlsaving);
			$num_saving = mysqli_num_rows($load_date_saving);
			if($num_saving > 0){
			?>
			<div class="col-lg-3 col-6">
				<div class="info-box bg-fuchsia"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-university"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block">ธนาคารออมสิน</h4>
						<h2 class="text-white" id="credit_saving">0</h2> <span class="progress-description text-white d-sm-none d-md-none">ธนาคารออมสิน </span> </div>
				</div>
			</div>
			<?php } ?>
			
			
			
<?php 
$sql_info_bank = "SELECT * FROM bank WHERE name_bank != 'ธนาคารไทยพาณิชย์' AND name_bank != 'ธนาคารกสิกรไทย' AND name_bank != 'ทรูวอเล็ต' AND name_bank != 'ธนาคารออมสิน' ORDER BY id DESC";
$load_info_bank = $class_admin->load_date_sql($sql_info_bank);
while($row = mysqli_fetch_array($load_info_bank)) {
?>

			<div class="col-lg-3 col-6">
				<div class="info-box bg-darkblue"> <span class="info-box-icon bg-transparent text-white"><i class="fas fa-university"></i></span>
					<div class="info-box-content">
						<h4 class="text-white d-none d-sm-block d-md-block"><?php echo $row["name_bank"]; ?></h4>
						<h2 class="text-white" >0</h2> <span class="progress-description text-white d-sm-none d-md-none"><?php echo $row["name_bank"]; ?></span> </div>
				</div>
			</div>



<?php } ?>			
			
			
			
		</div>
		<div class="info-box">
			<div class="row mb-3">
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label">จากวันที่ :</label>
						<input class="form-control" type="text" id="FromDay"> </div>
				</div>
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label">ถึงวันที่ :</label>
						<input class="form-control" type="text" id="ToDay"> </div>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonsearch" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonyesterday" class="btn btn-sm btn-primary btn-block p-2">เมื่อวาน</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonthismonth" class="btn btn-sm btn-primary btn-block p-2">เดือนนี้</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="buttonlastmonth" class="btn btn-sm btn-primary btn-block p-2">เดือนที่แล้ว</button>
				</div>
			</div>
			<hr>
			<h5 class="text-black"><i class="fas fa-file-search"></i> รายงานประจำวันที่</h5>
			<h6 class="text-black"><span id="ShowFromDay" >×</span> ถึง <span id="ShowToDay" >×</span></h6>
			<hr>
			<div class="table-responsive">
				<table class="table table-hover text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">จำนวนสมาชิกฝากเงิน</th>
							<th scope="col">ยอดฝาก</th>
							<th scope="col">ยอดถอน</th>
							<th scope="col">ยอดถอนแนะนำเพื่อน</th>
							<th scope="col">จำนวนบิลฝาก</th>
							<th scope="col">แลกพ้อยด์</th>
							<th scope="col">รับยอดเสีย</th>
							<th scope="col">ยอดโบนัส</th>
							<th scope="col">ได้ราย</th>
						</tr>
					</thead>
					<tbody id="showdateget">
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
var today = '';	
  $.ajax({
      type: "POST",
	  data: {
          today:today
      },
      url: "/api/admin/loadstatusall",
      success: function(data) {
          var obj = JSON.parse(data);
		  $('#allmembers').html(obj.allmembers);
		  $('#stockmembers').html(obj.stockmembers);
		  $('#SUM_Amount_DP_ToDay').html(obj.SUM_Amount_DP_ToDay);
		  $('#SUM_Amount_WD_ToDay').html(obj.SUM_Amount_WD_ToDay);
		  $('#TotalAmount').html(obj.TotalAmount);
		  $('#bill_DP').html(obj.bill_DP);
		  $('#bill_WD').html(obj.bill_WD);
		  $('#amount_cashback').html(obj.amount_cashback);
		  $('#amount_aff').html(obj.amount_aff);
		  $('#change_point').html(obj.change_point);
		  $('#members_deposit_today').html(obj.members_deposit_today);
		  $('#credit_ufa').html(obj.credit_ufa);
		  $('#credit_scb').html(obj.credit_scb);
		  $('#credit_true').html(obj.credit_true);
		  $('#credit_kbank').html(obj.credit_kbank);
		  $('#bonustoday').html(obj.bonustoday);
		  
      }
  });
});
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
jQuery.datetimepicker.setLocale('th');
jQuery('#FromDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
jQuery('#ToDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
</script>
<script type="text/javascript">
function showdatelist(GetDate) {
	$('#showdateget').html('');
	html = "";
	html += '<tr>';
	html += '<th scope="col">' + GetDate.members_deposit_today + '</th>';
	html += '<th scope="col">' + GetDate.SUM_Amount_DP_ToDay + '</th>';
	html += '<th scope="col">' + GetDate.SUM_Amount_WD_ToDay + '</th>';
	html += '<th scope="col">' + GetDate.amount_aff + '</th>';
	html += '<th scope="col">' + GetDate.bill_DP + '</th>';
	html += '<th scope="col">' + GetDate.change_point + '</th>';
	html += '<th scope="col">' + GetDate.amount_cashback + '</th>';
	html += '<th scope="col">' + GetDate.bonustoday + '</th>';
	html += '<th scope="col">' + GetDate.TotalAmount + '</th>';
	html += '</tr>';
	$('#showdateget').html(html);
	$('#ShowFromDay').html(GetDate.fromTime);
	$('#ShowToDay').html(GetDate.toTime);
}
</script>

<script type="text/javascript">
$("#buttonsearch").click(function(){
var FromDay = $("#FromDay").val();
var ToDay = $("#ToDay").val();
var search = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadstatusall",
      data: {
		  search:search,
          FromDay:FromDay,
          ToDay:ToDay,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});

$("#buttonyesterday").click(function(){
var yesterday = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadstatusall",
      data: {
          yesterday:yesterday
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});
$("#buttonthismonth").click(function(){
var thismonth = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadstatusall",
      data: {
          thismonth:thismonth
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});
$("#buttonlastmonth").click(function(){
var lastmonth = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadstatusall",
      data: {
          lastmonth:lastmonth
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  showdatelist(obj);
      }
  });
});
</script>
