<?php
$setting = $class_admin->load_db_setting();
?>
<script type="text/javascript">
$(document).ready(function(){
  $("#input_search").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#showdateget tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-history"></i> ประวัติหมุนวงล้อ</h4>
					<hr>
					<div class="row mb-3">
						<div class="col-md-8">
							<div class="form-group">
								<label class="control-label-dc">กรอกเบอร์โทรศัพท์ หรือ ยูสเซอร์เนม หรือ ชื่อสมาชิก</label>
								<input class="form-control" id="input_search" type="text"> </div>
						</div>
						<div class="col-md-4 mt-2 align-self-center">
							<button type="button" id="button_input_search" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-history"></i> ประวัติหมุนวงล้อ</h4>
					<hr>
					<div class="row mb-3">
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">จากวันที่ :</label>
								<input class="form-control" id="FromDay" type="text"> </div>
						</div>
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">ถึงวันที่ :</label>
								<input class="form-control" id="ToDay" type="text"> </div>
						</div>
						<div class="col-md-4 mt-2 align-self-center">
							<button type="button" id="buttonsearch" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="button" id="show100" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 100 รายการล่าสุด</button>
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="button" id="show500" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 500 รายการล่าสุด</button>
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="button" id="show1000" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 1,000 รายการล่าสุด</button>
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="button" id="showAll" class="btn btn-sm btn-primary btn-block p-2">ค้นหาทุกรายการทั้งหมด</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="info-box">
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">ลำดับ</th>
							<th scope="col">รางวัล</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">วันเวลา</th>
						</tr>
					</thead>
					<tbody id="showdateget" style="font-size: 14px;">
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha512-AIOTidJAcHBH2G/oZv9viEGXRqDNmfdPVPYOYKGy3fti0xIplnlgMHUGfuNRzC6FkzIo0iIxgFnr9RikFxK+sw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
jQuery.datetimepicker.setLocale('th');
jQuery('#FromDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
jQuery('#ToDay').datetimepicker({
	lang:'th',
	timepicker:false,
	format:'Y-m-d'
});
</script>

<script type="text/javascript">
function showdatelist(GetDate) {
	console.log(GetDate.result);
	$('#showdateget').html('');
	html = "";
	$.each(GetDate.result, function( index, value ) {
		var str_confirm_dp;
		if(value.reward == 'ไม่ได้รับรางวัล'){
			str_confirm_dp = '<span class="btn btn-sm btn-danger px-2 noHover"><i class="fas fa-times"></i> ไม่ได้รับรางวัล</span>';
		}else{
			str_confirm_dp = '<span class="btn btn-sm btn-success px-4 noHover">' + value.reward + ' พ้อยด์</span>';
		}
		html += '<tr>';
		html += '<th scope="col">' + value.id + '</th>';
		html += '<th scope="col">' + str_confirm_dp + '</th>';
		html += '<th scope="col"><?php echo $setting->agent; ?>' + value.username + '</th>';
		html += '<th scope="col">' + value.phone + '</th>';
		html += '<th scope="col">' + value.name + '</th>';
		html += '<th scope="col">' + value.time + '</th>';
		html += '</tr>';
	});
	$('#showdateget').html(html);
	$('#ShowFromDay').html(GetDate.ShowFromDay);
	$('#ShowToDay').html(GetDate.ShowToDay);
}
</script>
<script type="text/javascript">
$("#button_input_search").click(function(){
	
var input_search = $("#input_search").val();
var search = '';
if (input_search == '') {
	
$('#input_search').closest('.form-group').addClass('has-error');

}else{
$('#input_search').closest('.form-group').removeClass('has-error');
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          search:search,
          phone_dp:input_search,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  }
      }
  });
  
}
  
});

$("#buttonsearch").click(function(){
var FromDay = $("#FromDay").val();
var ToDay = $("#ToDay").val();
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          FromDay:FromDay,
          ToDay:ToDay,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  }
      }
  });
});

$("#show100").click(function(){
var show100 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          show100:show100
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show500").click(function(){
var show500 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          show500:show500
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show1000").click(function(){
var show1000 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          show1000:show1000
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#showAll").click(function(){
var showAll = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadspinhistory",
      data: {
          showAll:showAll
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
</script>
