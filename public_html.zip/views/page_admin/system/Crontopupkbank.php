<?php
//error_reporting(0);
$load_setting = $class_admin->load_db_setting();
$Load_Class_KBank = $class_admin->return_class_KBank();


$sql = "SELECT * FROM bank WHERE name_bank='ธนาคารกสิกรไทย'";
$result = $class_admin->load_date_sql($sql);
$row = mysqli_fetch_assoc($result);
//$endpoint = $row['token_kbank'];


$status_transfer = $load_setting->status_auto;
$limit_scb = $load_setting->max_autowd;
$status_auto2 = $load_setting->status_auto2;

if ($status_auto2 == 'เปิด') {

	if ($status_transfer != 'เปิด') {
		echo 'ฟังชั่นปิดอยู่';
		exit();
	}



	//หากลูกค้ารับโปรวันนี้ จะไม่สามารถถอนออโต้ได้
	$sql = 'SELECT * FROM withdraw WHERE confirm_wd = "รอดำเนินการ" AND bank_wd != "ทรูวอเล็ต" ORDER by id asc LIMIT 1';
	$result = $class_admin->load_date_sql($sql);
	$row = mysqli_fetch_assoc($result);
	$phone2 = $row['phone_wd'];
	//echo $phone;

	$today_pro = date('Y-m-d');
	$sql2 = "SELECT * FROM deposit WHERE phone_dp = $phone2 AND date_dp LIKE '%$today_pro%' AND promotion_dp!='ไม่รับโบนัส' AND confirm_dp='อนุมัติ'";
	$query2 = $class_admin->load_date_sql($sql2);
	$check2 = mysqli_num_rows($query2);
	//echo $check2;

	if ($check2 > 0) {
		echo 'ลูกค้ารับโปรก่อนหน้านี้';
		exit();
	}


	$withdraw = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND bank_wd!="ทรูวอเล็ต" AND lastpro="ไม่รับโบนัส" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1'; //ถ้าไม่ต้องการเช็คคนที่รับโปร ก่อนถอน เอา lastpro="ไม่รับโบนัส" ออก

	$result = $class_admin->load_date_sql($withdraw);
	$withdraw = array();
	foreach ($result as $row) {



		$sql1 = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';
		$result1 = $class_admin->load_date_sql($sql1);
		$row1 = mysqli_fetch_assoc($result1);

		$row['bank_name1'] = $row1['bank_wd'];
		$row['bank_number'] = $row1['bankacc_wd'];

		//echo $row['bank_name1'];

		array_push($withdraw, $row);
	}


?>


<?php $i = 1;
	foreach ($withdraw as $key => $value) {
		$credit = $value['amount_wd'];
		//echo $credit;
		if ($credit <= $limit_scb) {
			$phone = $value['phone_wd'];
			echo 'ถอนได้';
			echo '<br>';
			$sql55 = 'SELECT * FROM withdraw WHERE confirm_wd="รอดำเนินการ" AND pin_wd="unknown6134" ORDER by id asc LIMIT 1';
			$result55 = $class_admin->load_date_sql($sql55);
			$row55 = mysqli_fetch_assoc($result55);
			$pin_wd = $row55['pin_wd'];
			//echo $pin_wd;
			if ($pin_wd == 'unknown6134') {

				//echo $endpoint;


				//echo $row['bank_name1'];

				function code($value)
				{
					$value = trim($value);

					if ($value == "ธ.ไทยพาณิชย์") {
						return '010';
					}

					if ($value == "ธ.กรุงเทพ") {
						return '003';
					}

					if ($value == "ธ.กสิกรไทย") {
						return '001';
					}

					if ($value == "ธ.กรุงไทย") {
						return '004';
					}

					if ($value == "ธ.ทหารไทยธนชาติ") {
						return '007';
					}

					if ($value == "ธ.กรุงศรีอยุธยา") {
						return '017';
					}
					if ($value == "ธ.ออมสิน") {
						return '022';
					}

					if ($value == "ธ.ก.ส.") {
						return '026';
					}

					if ($value == "ธ.ซีไอเอ็มบีไทย") {
						return '018';
					}

					if ($value == "ธ.เกียรตินาคิณภัทร") {
						return '023';
					}

					if ($value == "ธ.ทิสโก้") {
						return '029';
					}

					if ($value == "ธ.ยูโอบี") {
						return '016';
					}

					if ($value == "ธ.อิสลาม") {
						return '028';
					}

					if ($value == "ธ.ไอซีบีซี") {
						return '030';
					}
				}
				$accountTo = $value['bank_number'];
				$accountToBankCode = code($value['bank_name1']);
				$amount = $credit;
				echo $accountToBankCode;
				echo '<br>';
				echo $credit;
				echo '<br>';

				$data = json_encode($Load_Class_KBank->transferVerify($accountToBankCode, $accountTo, $amount));

				$wd = json_decode($data);
				$code_wd5 = $wd->kbankInternalSessionId;
				$code_wd = $wd->error;
				echo $code_wd5;
				if ($code_wd == 'NF-CIGW21, เลขที่บัญชีปลายทางไม่ถูกต้อง กรุณาตรวจสอบและทำรายการใหม่อีกครั้ง') {

					echo "เลขที่บัญชีปลายทางไม่ถูกต้อง";
				} else {
					$data2 = json_encode($Load_Class_KBank->transferConfrim78($code_wd5));
					$qrcode2 = json_decode($data2);
					$qrcode = $qrcode2->rawQr;
				}

				$sql4 = 'SELECT * FROM bank WHERE name_bank="ธนาคารกสิกรไทย" AND status_bank="เปิด"';
				$result4 = $class_admin->load_date_sql($sql4);
				$row4 = mysqli_fetch_assoc($result4);

				$bankout_no = $row4['bankacc_bank'];




				if ($qrcode != '') {

					$sql = "UPDATE withdraw SET
            					confirm_wd='อนุมัติ' , 
            					pin_wd='',
            					add_wd='AUTO',
            					bankout_wd='ธนาคารกสิกรไทย $bankout_no' 
            					WHERE phone_wd='$phone' AND confirm_wd='รอดำเนินการ'";

					if ($class_admin->load_date_sql($sql) === TRUE) {

						$sMessage = "BOT อนุมัติถอน \nจำนวนเงิน " . $amount . " บาท\nเบอร์ " . $phone;
						$token = $load_setting->linewithdraw;
					    $run_class = $class_admin->notify_line($sMessage,$token);


						$data = array('msg' => "ทำรายการ สำเร็จ!", 'status' => 200);
						echo json_encode($data);
						exit();


						$data = array('msg' => 'success!', 'phone' => $GLOBALS["phone"], 'id' => $GLOBALS["id"], 'status' => 200);
						echo json_encode($data);
						exit();
					} else {

						$sMessage = "BOT มีปัญหา \nจำนวนเงิน " . $amount . " บาท\nเบอร์ " . $phone;
						$token = $load_setting->linewithdraw;
						$run_class = $class_admin->notify_line($sMessage,$token);

						$data = array('msg' => $status, 'status' => 500);
						echo json_encode($data);
						exit();
					}
				} else {


					$sMessage = "BOT! มีรายการถอนค้างอยู่  \nจำนวนเงิน " . $amount . " บาท\nเบอร์ " . $phone;
					$token = $load_setting->linewithdraw;
					$run_class = $class_admin->notify_line($sMessage,$token);

					$data = array('msg' => $status, 'status' => 500);
					echo json_encode($data);

					// echo 'เกินงบ ถอนไม่ได้';
				}
			}
		} else {
			echo 'ยอดถอนเกินที่ตั้งไว้';
		}
?>
 

<?php $i++;
	}
} else {
	echo 'ระบบออโต้ปิด';
}


?>
