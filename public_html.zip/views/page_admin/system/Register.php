
<?php
 error_reporting(0);
//require '../connectdb.php';
//$sql = "SELECT * FROM setting";
//$result = mysqli_query($con,$sql);
//$row = mysqli_fetch_assoc($result);



// $agent_user=$row['agent'];
// $GLOBALS["api_betflix"]=$row['pass_agent'];
// $GLOBALS["apikey"]=$row['txtTotal'];
// echo $agent_user;


$sql="SELECT * FROM member WHERE phone_mb =''";
$result = $class_admin->load_date_sql($sql);
$num=mysqli_num_rows($result);

function generateRandomString($length = 5) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

$username=generateRandomString();

if ($num<500) {

$username=generateRandomString(); 
$password=urlencode('aa123456');



$status = $class_admin->register_agent($username,$password);
//echo $status;
if ($status['status'] == 'success') {
	

$sql = "INSERT INTO member (username_mb, password_ufa)
       VALUES('$username', '$password')";
	if ($class_admin->load_date_sql($sql) === TRUE) {


			echo"successfully";

 exit();
}else{
	echo"no no no";
}				
  }else{
  	echo"can not register";
  }




  

}else{

	echo 'สต็อกยูสเซอร์เต็มแล้ว';
}


?>
