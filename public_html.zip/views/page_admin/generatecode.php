<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-barcode-alt"></i> เช็ครายการโค้ด</h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label-dc">รางวัล</label>
						<input class="form-control" id="reward" type="text"> </div>
				</div>
				<div class="col-md-2">
					<div class="form-group has-feedback">
						<label class="control-label-dc">เทิร์นโอเวอร์</label>
						<input class="form-control" id="turnover" type="text"> </div>
				</div>
				<div class="col-md-2 mt-2 align-self-center">
					<button type="button" id="button_success" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-check"></i> สร้างโค้ด</button>
				</div>
			</div>
			<hr>
			<h4 class="text-black"><i class="fas fa-spinner fa-spin"></i> โค้ดที่ยังไม่ใช้งาน</h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">โค้ด</th>
							<th scope="col">รางวัล</th>
							<th scope="col">เทิร์นโอเวอร์</th>
							<th scope="col">วันที่สร้าง</th>
							<th scope="col">ลบ</th>
						</tr>
					</thead>
					<tbody id="showdateget">
<?php 
$sql_code_wait = "SELECT * FROM code_reward WHERE phone = '' ORDER BY id DESC";
$load_date_code_wait = $class_admin->load_date_sql($sql_code_wait);
while($row = mysqli_fetch_array($load_date_code_wait)) {
?>
								<tr>
									<td class="align-middle"><?php echo $row["code"]; ?></td>
									<td class="align-middle"><?php echo $row["reward"]; ?></td>
									<td class="align-middle"><?php echo $row["turnover"]; ?></td>
									<td class="align-middle"><?php echo $row["date_code"]; ?></td>
									<th scope="col"><button type="button" class="btn btn-default text-danger btn-sm startdelete" data-id="<?php echo $row["id"]; ?>"><i class="fas fa-trash-alt"></i></button></th>
								</tr>	
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		
		<div class="info-box">
		<h4 class="text-black"><i class="far fa-check"></i> โค้ดที่ใช้งานแล้ว</h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">โค้ด</th>
							<th scope="col">รางวัล</th>
							<th scope="col">เทิร์นโอเวอร์</th>
							<th scope="col">เบอร์ผู้รับ</th>
							<th scope="col">วันที่สร้าง</th>
							<th scope="col">ลบ</th>
						</tr>
					</thead>
					<tbody>
<?php 
$sql_code_success = "SELECT * FROM code_reward WHERE phone != '' ORDER BY id DESC";
$load_date_code_success = $class_admin->load_date_sql($sql_code_success);
while($row = mysqli_fetch_array($load_date_code_success)) {
?>
								<tr>
									<td class="align-middle"><?php echo $row["code"]; ?></td>
									<td class="align-middle"><?php echo $row["reward"]; ?></td>
									<td class="align-middle"><?php echo $row["turnover"]; ?></td>
									<td class="align-middle"><?php echo $row["phone"]; ?></td>
									<td class="align-middle"><?php echo $row["date_code"]; ?></td>
									<th scope="col"><button type="button" class="btn btn-default text-danger btn-sm startdelete" data-id="<?php echo $row["id"]; ?>"><i class="fas fa-trash-alt"></i></button></th>
								</tr>	
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
var function_delete_id = document.getElementsByClassName("startdelete");
if (function_delete_id) {
    Array.from(function_delete_id).forEach(function(element) {
        element.addEventListener('click', Call_delete_id);
    });
}
function Call_delete_id() {
	    var id = $(this).data('id');
		Swal.fire({
			title: 'คำเตือน',
			text: "คุณต้องการ ลบ ใช่ไหม",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00C851',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ใช่'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					type:"POST",
					data: {
					   'FROM_NAME' : 'code_reward',
					   'WHERE_NAME' : 'id',
					   'WHERE_VALUE' : id,
					},
					url:"/api/admin/run_delete_sql",
					success:function(data){
						Swal.fire({
							icon: 'success',
							title: 'ลบรายการ สำเร็จ',
							showConfirmButton: false,
							timer: 2000,
							timerProgressBar: true,
						}).then((result) => {
							window.location.href='./generatecode';
						})

					}

				})

			}

		})
}
</script>
<script type="text/javascript">
$("#button_success").click(function(){
	
var input_reward = $("#reward").val();
var input_turnover = $("#turnover").val();
if (input_reward == '') {
	
$('#reward').closest('.form-group').addClass('has-error');
$('#turnover').closest('.form-group').removeClass('has-error');

} else if (input_turnover == '') {

$('#turnover').closest('.form-group').addClass('has-error');
$('#reward').closest('.form-group').removeClass('has-error');

}else{

$('#reward').closest('.form-group').removeClass('has-error');
$('#turnover').closest('.form-group').removeClass('has-error');

$.ajax({
      type: "POST",
      url: "/api/admin/BuildCodeReward",
      data: {
          reward:input_reward,
          turnover:input_turnover,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.status=="success"){
			 Swal.fire({
				icon: 'success',
				title: 'สำเร็จ',
				text: obj.info,
				allowOutsideClick: false,
				confirmButtonColor: '#00C851',
			}).then((result) => {
				window.location.href='./generatecode';
			})
		  }else{
			  Swal.fire({
				icon: 'error',
				title: 'ผิดพลาด',
				text: obj.info,
				allowOutsideClick: false,
				confirmButtonColor: '#00C851',
			})
		  }
      }
});	
	
}
  
});
</script>
