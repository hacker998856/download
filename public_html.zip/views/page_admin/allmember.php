<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-users"></i> สมาชิกทั้งหมด</h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-3">
					<div class="form-group has-feedback">
						<label class="control-label">กรอกเบอร์โทรศัพท์ หรือ ยูสเซอร์เนม หรือ ชื่อสมาชิก</label>
						<input class="form-control" id="input_search" type="text"> </div>
				</div>
				<div class="col-md-1 mt-3 align-self-center">
					<button type="button" id="button_input_search" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-search"></i> ค้นหา</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show100" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 100 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show500" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 500 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show1000" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 1,000 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="showAll" class="btn btn-sm btn-primary btn-block p-2">ค้นหาทุกรายการทั้งหมด</button>
				</div>

			</div>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">สถานะ</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ไอดีทรูวอเล็ต</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">วันลงทะเบียน</th>
							<th scope="col">เครดิต</th>
							<th scope="col">เพิ่มโดย</th>
							<th scope="col">แก้ไขโดย</th>
							<th scope="col">เติมเครดิต</th>
							<th scope="col">ตัดเครดิต</th>
							<th scope="col">ฝาก</th>
							<th scope="col">ถอน</th>
							<th scope="col">แก้ไข</th>
							<th scope="col">ลบ</th>
						</tr>
					</thead>
					<tbody id="showdateget">
					
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function Call_delete_id() {
	    var id = $(this).data('id');
		Swal.fire({
			title: 'คำเตือน',
			text: "คุณต้องการ ลบ ใช่ไหม",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00C851',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ใช่'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					type:"POST",
					data: {
					   'FROM_NAME' : 'member',
					   'WHERE_NAME' : 'id_mb',
					   'WHERE_VALUE' : id,
					},
					url:"/api/admin/run_delete_sql",
					success:function(data){
						Swal.fire({
							icon: 'success',
							title: 'ลบรายการ สำเร็จ',
							showConfirmButton: false,
							timer: 2000,
							timerProgressBar: true,
						}).then((result) => {
							window.location.href='./allmember';
						})

					}

				})

			}

		})
}
</script>
<script type="text/javascript">
function showdatelist(GetDate) {
//console.log(GetDate);
sessionStorage.setItem("Date_Page_Member", JSON.stringify(GetDate));

	$('#showdateget').html('');
	html = "";
	$.each(GetDate.result, function( index, value ) {
		var confirm_mb;
		if (value.confirm_mb == "") {
			 confirm_mb = '<a href="/admin/userupdateform?id=' + value.id_mb + '" class="btn btn-info btn-sm"><i class="fas fa-spinner fa-spin"></i> รอยืนยัน</a>';
		}
		if (value.confirm_mb == "1") {
			confirm_mb = '<span class="btn btn-success btn-sm noHover"><i class="fas fa-check"></i> เรียบร้อย</span>';
		}
		
		html += '<tr>';
		html += '<th scope="col">' + confirm_mb + '</th>';
		html += '<th scope="col">' + value.agent + value.username_mb + '</th>';
		html += '<th scope="col">' + value.phone_mb + '</th>';
		html += '<th scope="col">' + value.phone_true + '</th>';
		html += '<th scope="col">' + value.name_mb + '</th>';
		html += '<th scope="col">' + value.date_mb + '</th>';
		html += '<th scope="col">' + value.Balance + '</th>';
		html += '<th scope="col">' + value.add_mb + '</th>';
		html += '<th scope="col">' + value.edit_mb + '</th>';
		html += '<th scope="col"><a href="/admin/addcredit?id=' + value.id_mb + '" class="btn btn-success btn-sm">เติมเครดิต</a></th>';
		html += '<th scope="col"><a href="/admin/deletecredit?id=' + value.id_mb + '" class="btn btn-danger btn-sm">ตัดเครดิต</a></th>';
		html += '<th scope="col"><a href="/admin/depositformuser?id=' + value.id_mb + '" class="btn btn-warning btn-sm">ฝาก</a></th>';
		html += '<th scope="col"><a href="/admin/withdrawformuser?id=' + value.id_mb + '" class="btn btn-dark btn-sm">ถอน</a></th>';
		//html += '<th scope="col"><span class="btn btn-warning btn-sm noHover">ฝาก</span></th>';
		//html += '<th scope="col"><span class="btn btn-dark btn-sm noHover">ถอน</span></th>';
		html += '<th scope="col"><a href="/admin/userupdateform?id=' + value.id_mb + '" class="btn btn-info btn-sm"><i class="fas fa-user-edit"></i></a></th>';
		html += '<th scope="col"><button type="button" class="btn btn-default text-danger btn-sm startdelete" data-id="' + value.id_mb + '"><i class="fas fa-trash-alt"></i></button></th>';
		html += '</tr>';
	});
	$('#showdateget').html(html);
	
var function_delete_id = document.getElementsByClassName("startdelete");
if (function_delete_id) {
    Array.from(function_delete_id).forEach(function(element) {
        element.addEventListener('click', Call_delete_id);
    });
   }
}
</script>
<script type="text/javascript">
$(function(){
if (sessionStorage.getItem('Date_Page_Member')) {
	var obj = JSON.parse(sessionStorage.getItem('Date_Page_Member'));
	showdatelist(obj);
}
});

</script>
<script type="text/javascript">
$("#button_input_search").click(function(){
	
var input_search = $("#input_search").val();
var search = '';
if (input_search == '') {
	
$('#input_search').closest('.form-group').addClass('has-error');

}else{
$('#input_search').closest('.form-group').removeClass('has-error');
$.ajax({
      type: "POST",
      url: "/api/admin/loadallmember",
      data: {
          search:search,
          input_search:input_search,
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  }
      }
  });
  
}
  
});


$("#show100").click(function(){
$('#showdateget').html('<tr><td colspan="100"><div class="alert alert-secondary" role="alert"><i class="fas fa-spinner fa-spin"></i> กำลังโหลดข้อมูล...</div></td></tr>');
var show100 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadallmember",
      data: {
          show100:show100
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show500").click(function(){
$('#showdateget').html('<tr><td colspan="100"><div class="alert alert-secondary" role="alert"><i class="fas fa-spinner fa-spin"></i> กำลังโหลดข้อมูล...</div></td></tr>');
var show500 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadallmember",
      data: {
          show500:show500
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show1000").click(function(){
$('#showdateget').html('<tr><td colspan="100"><div class="alert alert-secondary" role="alert"><i class="fas fa-spinner fa-spin"></i> กำลังโหลดข้อมูล...</div></td></tr>');	
var show1000 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadallmember",
      data: {
          show1000:show1000
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#showAll").click(function(){
$('#showdateget').html('<tr><td colspan="100"><div class="alert alert-secondary" role="alert"><i class="fas fa-spinner fa-spin"></i> กำลังโหลดข้อมูล...</div></td></tr>');	
var showAll = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadallmember",
      data: {
          showAll:showAll
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
</script>
