
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-clipboard-list"></i> เช็คข้อมูลการถอน</h4></div>
			</div>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">สถานะ</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">ยอดเงินถอน</th>
							<th scope="col">ยอดเงินคืน</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เวลา</th>
						</tr>
					</thead>
					<tbody>
<?php
$setting = $class_admin->load_db_setting();
$sql = "SELECT * FROM withdraw WHERE confirm_wd = 'รอดำเนินการ'";
$load_date  = $class_admin->load_date_sql($sql);
while($row = mysqli_fetch_array($load_date)) {
?>
								<tr>
									<td class="align-middle">
										<div class="btn-group">
<?php
if ($row["confirm_wd"]=="รอดำเนินการ") {
				echo"<span class='btn btn-info btn-sm noHover'><i class='fas fa-spinner fa-spin'></i> กำลังดำเนินการ</span>";
				echo"<a href='/admin/withdrawupdateform?id=$row[0]' class='btn btn-success btn-sm'><i class='fas fa-eye'></i> ตรวจสอบ</a>";
}
if ($row["confirm_wd"]=="อนุมัติ") {
				echo"<span class='btn btn-success btn-sm px-4 noHover'><i class='fas fa-check'></i> อนุมัติ</span>";
}
if ($row["confirm_wd"]=="ปฏิเสธ") {
				echo"<span class='btn btn-sm btn-danger px-4 noHover'><i class='fas fa-times'></i> ปฏิเสธ</span>";
}
?>
										</div>
									</td>
									<td class="align-middle"><?php echo $setting->agent; ?><?php echo $row["username_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_cashback"]; ?></td>
									<td class="align-middle"><?php echo $row["phone_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["name_wd"]; ?></td>
									<td class="align-middle"><?php echo $row["date_wd"]; ?></td>
								</tr>	
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="card">
      <div class="card-header">
        <div class="clearfix">
          <span class="float-left h4">
            <i class="fas fa-user-plus"></i> เพิ่มสมาชิก </span>
          <span class="float-right text-danger" data-dismiss="modal">
            <i class="fas fa-window-close fa-2x"></i>
          </span>
        </div>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>เบอร์โทรศัพท์</label>
              <input class="form-control" type="text">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>รหัสผ่าน</label>
              <input class="form-control" type="text">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>ไอดีทรูวอเล็ต</label>
              <input class="form-control" type="text">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>ธนาคาร</label>
              <select class="custom-select form-control">
                <option selected="selected">เลือกธนาคาร</option>
                <option value="ทรูวอเล็ต">ทรูวอเล็ต</option>
                <option value="ธ.กสิกรไทย">ธ.กสิกรไทย</option>
                <option value="ธ.กรุงไทย">ธ.กรุงไทย</option>
                <option value="ธ.กรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
                <option value="ธ.กรุงเทพ">ธ.กรุงเทพ</option>
                <option value="ธ.ไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
                <option value="ธ.ทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
                <option value="ธ.ออมสิน">ธ.ออมสิน</option>
                <option value="ธ.ก.ส.">ธ.ก.ส.</option>
                <option value="ธ.ซีไอเอ็มบี">ธ.ซีไอเอ็มบี</option>
                <option value="ธ.ทิสโก้">ธ.ทิสโก้</option>
                <option value="ธ.ยูโอบี">ธ.ยูโอบี</option>
                <option value="ธ.อิสลาม">ธ.อิสลาม</option>
                <option value="ธ.ไอซีบีซี">ธ.ไอซีบีซี</option>
                <option value="ธ.เกียรตินาคินภัทร">ธ.เกียรตินาคินภัทร</option>
              </select>
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>เลขบัญชีธนาคาร</label>
              <input class="form-control" type="text">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label>ชื่อ-นามสกุล</label>
              <input class="form-control" type="text">
            </fieldset>
          </div>
        </div>
      </div>
      <div class="card-footer">
        <button type="button" class="btn btn-success float-right">
          <i class="fas fa-save"></i> ยืนยัน </button>
      </div>
    </div>
  </div>
</div>
