<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/allmember"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<?php
$id = $_GET['id'];
$sql = "SELECT * FROM member WHERE id_mb = '$id'";
$date_member = $class_admin->load_db_date($sql);

$UsernameAgent = $Get_Setting->agent . $date_member->username_mb;
$Balance = $class_admin->load_balance_user($UsernameAgent);
?>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-plus-circle"></i> เพิ่มรายการถอน</h4>
			<hr>
			<h6 class="text-black">เครดิตคงเหลือ : <?php echo $Balance; ?> </h6>
			<h6 class="text-black"><?php echo $Get_Setting->agent; ?><?php echo $date_member->username_mb; ?> : <?php echo $date_member->name_mb; ?></h6>
			<hr>
			
			<form method="post" id="form_withdrawform_user" enctype="multipart/form-data">
			<input type="text" name="phone_mb" value="<?php echo $date_member->phone_mb; ?>" hidden>
			<div class="row mb-3">
				<div class="col-md-4 col-lg-4">
					<div class="form-group has-feedback">
						<label class="control-label-dc">ใส่ยอดเงินที่ต้องการถอน</label>
						<input class="form-control" name="amount_wd" type="text">
					</div>
				</div>
				<div class="col-md-4 col-lg-4 mt-2 align-self-center">
					<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="far fa-check"></i> ทำรายการ</button>
				</div>
			</div>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$("#form_withdrawform_user").on("submit",function(e){
e.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: '/api/admin/withdrawformuser',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>
