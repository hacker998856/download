<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-clipboard-list"></i> เช็คข้อมูลการถอน AFF</h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">สถานะ</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">ยอดเงินถอน</th>
							<th scope="col">ธนาคารที่ใช้ถอน</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เวลา</th>
						</tr>
					</thead>
					<tbody>
<?php
$setting = $class_admin->load_db_setting();
$sql = "SELECT * FROM withdrawaff WHERE confirm_aff = 'รอดำเนินการ' ORDER BY id DESC";
$load_date  = $class_admin->load_date_sql($sql);
while($row = mysqli_fetch_array($load_date)) {
?>
								<tr>
									<td class="align-middle">
										<div class="btn-group">
<?php
if ($row["confirm_aff"]=="รอดำเนินการ") {
				echo"<span class='btn btn-info btn-sm noHover'><i class='fas fa-spinner fa-spin'></i> กำลังดำเนินการ</span>";
				echo"<a href='/admin/withdrawaffupdateform?id=$row[0]' class='btn btn-success btn-sm'><i class='fas fa-eye'></i> ตรวจสอบ</a>";
}
if ($row["confirm_aff"]=="อนุมัติ") {
				echo"<span class='btn btn-success btn-sm px-4 noHover'><i class='fas fa-check'></i> อนุมัติ</span>";
}
if ($row["confirm_aff"]=="ปฏิเสธ") {
				echo"<span class='btn btn-sm btn-danger px-4 noHover'><i class='fas fa-times'></i> ปฏิเสธ</span>";
}
?>
										</div>
									</td>
									<td class="align-middle"><?php echo $setting->agent; ?><?php echo $row["username_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["bankout_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["phone_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["name_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["date_aff"]; ?></td>
								</tr>	
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		<div class="info-box">
			<h5 class="text-black"><i class="fas fa-clipboard-check"></i> ทำรายการแล้ว</h5>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">สถานะ</th>
							<th scope="col">ยูสเซอร์เนม</th>
							<th scope="col">ยอดเงินถอน</th>
							<th scope="col">ธนาคารที่ใช้ถอน</th>
							<th scope="col">เบอร์โทรศัพท์</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เวลา</th>
							<th scope="col">แก้ไข</th>
						</tr>
					</thead>
					<tbody>
<?php
$sql = "SELECT * FROM withdrawaff WHERE confirm_aff != 'รอดำเนินการ' ORDER BY id DESC";
$load_date  = $class_admin->load_date_sql($sql);
while($row = mysqli_fetch_array($load_date)) {
?>
								<tr>
									<td class="align-middle">
										<div class="btn-group">
<?php
if ($row["confirm_aff"]=="อนุมัติ") {
				echo"<span class='btn btn-success btn-sm px-4 noHover'><i class='fas fa-check'></i> อนุมัติ</span>";
}
if ($row["confirm_aff"]=="ปฏิเสธ") {
				echo"<span class='btn btn-sm btn-danger px-4 noHover'><i class='fas fa-times'></i> ปฏิเสธ</span>";
}
?>
										</div>
									</td>
									<td class="align-middle"><?php echo $row["username_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["amount_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["bankout_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["phone_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["name_aff"]; ?></td>
									<td class="align-middle"><?php echo $row["date_aff"]; ?></td>
									<td class="align-middle"><a href="/admin/withdrawaffupdateform?id=<?php echo $row[0]; ?>" class="btn btn-sm btn-info px-4"><i class="fas fa-edit"></i> แก้ไข</a></td>
								</tr>	
<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>