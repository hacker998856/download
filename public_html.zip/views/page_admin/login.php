<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>ระบบหลังบ้าน</title>
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script><!-- v4.0.0-alpha.6 -->
<link rel="stylesheet" href="/assets/admin/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/admin/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.all.min.js"></script>
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-box-body">
    <h3 class="login-box-msg">เข้าสู่ระบบ</h3>
      <div class="form-group has-feedback">
        <input type="text" class="form-control sty1" id="username_ad" placeholder="Username">
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control sty1" id="password_ad" placeholder="Password">
      </div>
      <div>
        <div class="col-xs-4 m-t-1">
          <button type="submit" id="submitlogin" class="btn btn-primary btn-block btn-flat">เข้าสู่ระบบ</button>
        </div>
      </div>
  </div>
</div>
<script type="text/javascript">
$('#submitlogin').click(function(e){
		e.preventDefault();
		var username_ad = $("#username_ad").val();
		var password_ad = $("#password_ad").val();
		$.ajax({
			type:"POST",
			url:"/api/admin/login",
			data:{
				username_ad:username_ad,
				password_ad:password_ad,
			},success:function(data){
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					Swal.fire({
						icon: 'success',
						title: 'เข้าสู่ระบบ',
						text: obj.info,
						allowOutsideClick: false,
						confirmButtonColor: '#00C851',
					}).then((result) => {
						window.location.href='./';
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: 'เข้าสู่ระบบ',
						text: obj.info,
						allowOutsideClick: false,
						confirmButtonColor: '#00C851',
					})
				}
			}
		});
});
</script>
<script src="/assets/admin/js/jquery.min.js"></script> 
<script src="/assets/admin/bootstrap/js/bootstrap.min.js"></script> 
<script src="/assets/admin/js/niche.js"></script>
</body>
</html>