<?php
$id = $_GET['id'];
$sql = "SELECT * FROM member WHERE id_mb = '$id'";
$setting_member = $class_admin->load_db_date($sql);

$UsernameAgent = $Get_Setting->agent . $setting_member->username_mb;
$Balance = $class_admin->load_balance_user($UsernameAgent);
?>
<?php
$id_dp = $setting_member->id_mb;                 
$sql2 = "SELECT * FROM deposit WHERE id_dp ='$id_dp' AND confirm_dp = 'อนุมัติ' ORDER BY id DESC limit 1";
$result_date2 = $class_admin->load_date_sql($sql2);
$result2_num = mysqli_num_rows($result_date2);
if($result2_num == 0){
	$row2['turnover'] = '';
	$row2['promotion_dp'] = '';
}else{
	while($row = mysqli_fetch_array($result_date2)) {
		$row2[] = $row; 
	}
}

$phone_mb = $setting_member->phone_mb; 

$sql_SUM_Amount_dp = $class_admin->load_date_sql("SELECT SUM(amount_dp) FROM deposit WHERE confirm_dp = 'อนุมัติ' AND phone_dp = '$phone_mb'");
while($row = mysqli_fetch_array($sql_SUM_Amount_dp)) {
	$result_SUM_Amount_DP = $row['SUM(amount_dp)']; 
}
if (is_null($result_SUM_Amount_DP)) {
$result_SUM_Amount_DP = "0";
}

$sql_SUM_Amount_wd = $class_admin->load_date_sql("SELECT SUM(amount_wd) FROM withdraw WHERE confirm_wd = 'อนุมัติ' AND phone_wd = '$phone_mb'");
while($row = mysqli_fetch_array($sql_SUM_Amount_wd)) {
	$result_SUM_Amount_WD = $row['SUM(amount_wd)']; 
}
if (is_null($result_SUM_Amount_WD)) {
$result_SUM_Amount_WD = "0";
}
?>
<div class="content-wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-12">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-search-plus"></i>  ตรวจสอบสมาชิก</h4>
					<hr class="mb-0">
					  <div class="d-flex justify-content-around box text-nowrap mb-1">
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">เครดิตคงเหลือ</h4>
								<span class="description-text"><?php echo $Balance; ?></span>
							</div>
						</div>
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">ยอดเทิร์นที่ต้องทำ</h4>
								<span class="description-text"><?php if ($row2['turnover']=='') { echo 0; }else { echo $row2['turnover']; } ?></span>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="description-block">
								<h4 class="description-header text-black">โปรโมชั่นล่าสุด</h4>
								<span class="description-text"><?php echo $row2['promotion_dp']; ?></span>
							</div>
						</div>
					  </div>
					  <div class="d-flex justify-content-around box text-nowrap mb-4">
						<div class="col-sm-3 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">ยอดฝากทั้งหมด</h4>
								<span class="description-text"><?php echo $result_SUM_Amount_DP; ?></span>
							</div>
						</div>
						<div class="col-sm-3 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">ยอดถอนทั้งหมด</h4>
								<span class="description-text"><?php echo $result_SUM_Amount_WD; ?></span>
							</div>
						</div>
						<div class="col-sm-3 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">สิทธิ์หมุนวงล้อ</h4>
								<span class="description-text"><?php echo $setting_member->creditspin; ?></span>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="description-block">
								<h4 class="description-header text-black">พ้อยด์</h4>
								<span class="description-text"><?php echo $setting_member->creditspin; ?></span>
							</div>
						</div>
					  </div>

				<form method="post" id="form_userupdateform" enctype="multipart/form-data">
					<input class="d-none" type="" name="id_mb" value="<?php echo $id; ?>">
					<div class="row mb-3">
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยูสเซอร์เนม UFABET</label>
							  <input class="form-control" type="text" value="<?php echo $UsernameAgent; ?>" readonly>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยูสเซอร์เนม</label>
							  <input class="form-control" type="text" name="username_mb" value="<?php echo $setting_member->username_mb; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">รหัสผ่าน</label>
							  <input class="form-control" type="text" name="password_mb" value="<?php echo $setting_member->password_mb; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ไอดีทรูวอเล็ต</label>
							  <input class="form-control" type="text" name="phone_true" value="<?php echo $setting_member->phone_true; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เลขบัญชีธนาคาร</label>
							  <input class="form-control" type="text" name="bankacc_mb" value="<?php echo $setting_member->bankacc_mb; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ธนาคาร</label>
							  <select class="custom-select form-control" name="bank_mb" required>
								<option selected="selected" value="<?php echo $setting_member->bank_mb; ?>"><?php echo $setting_member->bank_mb; ?></option>
								<option value="ทรูวอเล็ต">ทรูวอเล็ต</option>
								<option value="ธ.กสิกรไทย">ธ.กสิกรไทย</option>
								<option value="ธ.กรุงไทย">ธ.กรุงไทย</option>
								<option value="ธ.กรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
								<option value="ธ.กรุงเทพ">ธ.กรุงเทพ</option>
								<option value="ธ.ไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
								<option value="ธ.ทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
								<option value="ธ.ออมสิน">ธ.ออมสิน</option>
								<option value="ธ.ก.ส.">ธ.ก.ส.</option>
								<option value="ธ.ซีไอเอ็มบี">ธ.ซีไอเอ็มบี</option>
								<option value="ธ.ทิสโก้">ธ.ทิสโก้</option>
								<option value="ธ.ยูโอบี">ธ.ยูโอบี</option>
								<option value="ธ.อิสลาม">ธ.อิสลาม</option>
								<option value="ธ.ไอซีบีซี">ธ.ไอซีบีซี</option>
							  </select>
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เบอร์โทรศัพท์</label>
							  <input class="form-control" type="text" name="phone_mb" value="<?php echo $setting_member->phone_mb; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ชื่อ-นามสกุล</label>
							  <input class="form-control" type="text" name="name_mb" value="<?php echo $setting_member->name_mb; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ผู้แนะนำ</label>
							  <input class="form-control" type="text" value="<?php echo $setting_member->aff; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							<label class="control-label-dc">สถานะ</label>
								<select class="custom-select form-control" name="confirm_mb">
									<option value="<?php echo $setting_member->confirm_mb; ?>">ยังไม่ยืนยัน</option>
									<option value="1">ยืนยัน</option>
									<option value="">ยังไม่ยืนยัน</option>
							    </select>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ชื่อในแอพกสิกร</label>
							  <input class="form-control" type="text" name="name_eng" value="<?php echo $setting_member->name_eng; ?>">
							</fieldset>	
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button>
						</div>
					</div>
				</form>
					
					
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$("#form_userupdateform").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","member");
formData.append("WHERE_NAME","id_mb");
formData.append("WHERE_VALUE",formData.get('id_mb'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>