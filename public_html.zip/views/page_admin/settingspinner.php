<?php
if($_SESSION["status_ad"] != "Administrator"){
	echo "<script>window.location = './'</script>";
	exit;
}
?>
<?php
$setting = $class_admin->load_db_setting();
?>
<div class="content-wrapper">
	<div class="content">
      <div class="info-box">
		<div class="d-flex">
		  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> ตั้งค่า - วงล้อ</h4></div>
		  <div class="col-lg-2 col-4"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
		</div>
		<hr>
		
		<form method="post" id="form_settingspinner" enctype="multipart/form-data">
		
		<div class="row">
          <div class="col-lg-4">
            <div class="form-group">
                <label class="control-label-dc">ยอดฝากต่อ 1 สิทธิ์</label>
                <div class="input-group">
                <div class="input-group-addon"><i class="fas fa-sack-dollar"></i></div>
                <input class="form-control" type="text" name="dp_creditspin" value="<?php echo $setting->dp_creditspin; ?>">
                </div>
			</div>
          </div>
		  <div class="col-lg-4">
            <div class="form-group">
                <label class="control-label-dc">แลกพ้อยด์ [1 พ้อยด์ = เครดิต]</label>
                <div class="input-group">
                <div class="input-group-addon"><i class="fas fa-exchange-alt"></i></div>
                <input class="form-control" type="text" name="change_point" value="<?php echo $setting->change_point; ?>">
                </div>
			</div>
          </div>
		  <div class="col-lg-4">
            <div class="form-group">
                <label class="control-label-dc">รูปกลางวงล้อ</label>
                <div class="input-group">
                <div class="input-group-addon"><i class="fas fa-image"></i></div>
                <input class="form-control" type="text" name="ImageCenter" value="<?php echo $setting->ImageCenter; ?>">
                </div>
			</div>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #1</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward1" value="<?php echo $setting->reward1; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change1" value="<?php echo $setting->Change1; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image1" value="<?php echo $setting->Image1; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #2</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward2" value="<?php echo $setting->reward2; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change2" value="<?php echo $setting->Change2; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image2" value="<?php echo $setting->Image2; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #3</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward3" value="<?php echo $setting->reward3; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change3" value="<?php echo $setting->Change3; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image3" value="<?php echo $setting->Image3; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #4</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward4" value="<?php echo $setting->reward4; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change4" value="<?php echo $setting->Change4; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image4" value="<?php echo $setting->Image4; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #5</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward5" value="<?php echo $setting->reward5; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change5" value="<?php echo $setting->Change5; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image5" value="<?php echo $setting->Image5; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #6</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward6" value="<?php echo $setting->reward6; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change6" value="<?php echo $setting->Change6; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image6" value="<?php echo $setting->Image6; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #7</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward7" value="<?php echo $setting->reward7; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change7" value="<?php echo $setting->Change7; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image7" value="<?php echo $setting->Image7; ?>">
            </fieldset>
          </div>
        </div>
		<hr>
		<h5 class="text-lg-left text-center"><label class="control-label-dc">ช่องรางวัล #8</label></h5>
        <div class="row">
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รางวัลที่</label>
              <input class="form-control" type="text" name="reward8" value="<?php echo $setting->reward8; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">เปอร์เซ็นต์</label>
              <input class="form-control" type="text" name="Change8" value="<?php echo $setting->Change8; ?>">
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">รูปรางวัล</label>
              <input class="form-control" type="text" name="Image8" value="<?php echo $setting->Image8; ?>">
            </fieldset>
          </div>
        </div>
		<button type="submit" id="submitclick" class="d-none" ></button>
	</form>
	
    </div>
</div>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});

</script>
<script type="text/javascript">
$("#form_settingspinner").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","setting");
formData.append("WHERE_NAME","id");
formData.append("WHERE_VALUE","1");
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				//console.log(data);
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>