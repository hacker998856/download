<?php
if($_SESSION["status_ad"] != "Administrator"){
	echo "<script>window.location = './'</script>";
	exit;
}
?>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> ตั้งค่า - ธนาคาร</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" class="btn btn-sm btn-success btn-block p-2" data-toggle="modal" data-target="#myModal"><i class="fas fa-plus-circle"></i> เพิ่มธนาคาร</button></div>
			</div>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">โลโก้ธนาคาร</th>
							<th scope="col">ธนาคาร - ทรูวอเล็ต</th>
							<th scope="col">เลขบัญชี</th>
							<th scope="col">ประเภท</th>
							<th scope="col">โอนเงิน</th>
							<th scope="col">สถานะ</th>
							<th scope="col">แก้ไข</th>
							<th scope="col">ลบ</th>
						</tr>
					</thead>
					<tbody>
<?php 
$sql_bank = "SELECT * FROM bank WHERE name_bank!='' ORDER BY id DESC";
$load_date_bank = $class_admin->load_date_sql($sql_bank);
while($row = mysqli_fetch_array($load_date_bank)) {
if ($row["bankfor"]=="ฝาก") {
	$status = '<span class="btn btn-sm btn-info px-4 noHover">ฝาก</span>';
}
if ($row["bankfor"]=="ถอน") {
	$status = '<span class="btn btn-sm btn-warning px-4 noHover">ถอน</span>';
}	
if ($row["bankfor"]=="ฝากและถอน") {
	$status = '<span class="btn btn-sm btn-success px-4 noHover">ฝากและถอน</span>';
}

$status_transfer = '<span class="btn btn-sm btn-danger px-4 noHover"><i class="fas fa-times"></i> โอนไม่ได้</span>';
if ($row["name_bank"]=="ธนาคารไทยพาณิชย์") {
	$status_transfer = '<button type="button" class="btn btn-sm btn-success px-4" data-toggle="modal" data-target="#scb_modal"> โอนเงิน</button>';
}
if ($row["name_bank"]=="ธนาคารกสิกรไทย") {
	$status_transfer = '<button type="button" class="btn btn-sm btn-success px-4" data-toggle="modal" data-target="#kplus_modal"> โอนเงิน</button>';
}	
			
?>
								<tr>
									<td class="align-middle"><img src="/assets/img/bank_logo/<?php echo $row["name_bank"]; ?>.png" class="img-circle img-w-30" alt="scb"></td>
									<td class="align-middle"><?php echo $row["name_bank"]; ?></td>
									<td class="align-middle"><?php echo $row["bankacc_bank"]; ?></td>
									<td class="align-middle"><?php echo $status; ?></td>
									<td class="align-middle"><?php echo $status_transfer; ?></td>
									<td class="align-middle">
										<div class="form-check form-switch form-switch-md">
											<input class="form-check-input" value="<?php echo $row[0]; ?>" onclick='handleClick(this);' type="checkbox" <?php if ($row["status_bank"] == "เปิด")  { ?> checked <?php } ?>>
										</div>
									</td>
									<td class="align-middle"><a href="/admin/bankupdateform?id=<?php echo $row[0]; ?>" class="btn btn-sm btn-info px-4"><i class="fas fa-edit"></i> แก้ไข</a></td>
									<td class="align-middle"><button type="button" class="btn btn-sm btn-danger px-4 startdelete" data-id="<?php echo $row[0]; ?>"><i class="fas fa-trash-alt"></i> ลบ</button></td>
								</tr>	
<?php } ?>					
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="card">
      <div class="card-header">
        <div class="clearfix">
          <span class="float-left h4">
            <i class="fas fa-plus-circle"></i> เพิ่มธนาคาร - ทรูวอเล็ต </span>
          <span class="float-right text-danger" data-dismiss="modal">
            <i class="fas fa-window-close fa-2x"></i>
          </span>
        </div>
      </div>
	  
	  <form method="post" id="form_addbank" enctype="multipart/form-data">
      <div class="card-body">
        <div class="row">
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ธนาคาร / ทรูวอเล็ต</label>
              <select class="custom-select form-control" name="name_bank" required>
                <option selected="selected">เลือกธนาคาร</option>
                <option value="ทรูวอเล็ต">ทรูวอเล็ต</option>
                <option value="ธนาคารกสิกรไทย">ธ.กสิกรไทย</option>
                <option value="ธนาคารกรุงไทย">ธ.กรุงไทย</option>
                <option value="ธนาคารกรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
                <option value="ธนาคารกรุงเทพ">ธ.กรุงเทพ</option>
                <option value="ธนาคารไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
                <option value="ธนาคารทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
                <option value="ธนาคารออมสิน">ธ.ออมสิน</option>
                <option value="ธ.ก.ส.">ธ.ก.ส.</option>
                <option value="ธนาคารซีไอเอ็มบี">ธ.ซีไอเอ็มบี</option>
                <option value="ธนาคารทิสโก้">ธ.ทิสโก้</option>
                <option value="ธนาคารยูโอบี">ธ.ยูโอบี</option>
                <option value="ธนาคารอิสลาม">ธ.อิสลาม</option>
                <option value="ธนาคารไอซีบีซี">ธ.ไอซีบีซี</option>
                <option value="ธนาคารเกียรตินาคินภัทร">ธ.เกียรตินาคินภัทร</option>
              </select>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">เลขบัญชี</label>
              <input class="form-control" type="text" name="bankacc_bank" required>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ชื่อบัญชี</label>
              <input class="form-control" type="text" name="nameacc_bank" required>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <div class="form-group container">
              <label class="control-label-dc">รูปธนาคาร</label>
               <input type="file" class="dropify" name="fileupload_bank" required>
            </div>
          </div>
          <div class="col-lg-9 col-9">
            <fieldset class="form-group">
              <label class="control-label-dc">ประเภท</label>
              <select class="custom-select form-control" name="bankfor" required>
                <option selected="selected">เลือก ประเภท</option>
                <option value="ฝาก">ฝาก</option>
				<option value="ถอน">ถอน</option>
				<option value="ฝากและถอน">ฝากและถอน</option>
              </select>
            </fieldset>
          </div>
		  <div class="col-lg-3 col-3">
            <fieldset class="form-group text-center">
              <label class="control-label-dc">สถานะ</label>
              <div class="form-check form-switch form-switch-md">
				<input class="form-check-input" type="checkbox" name="status_bank" id="status_bank" checked>
			  </div>
            </fieldset>
          </div>
        </div>
      </div>
      <div class="card-footer">
        <button type="submit" class="btn btn-success float-right">
          <i class="fas fa-save"></i> ยืนยัน </button>
      </div>
	  </form>
	  
    </div>
  </div>
</div>


<div class="modal fade" id="scb_modal" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="card">
      <div class="card-header">
        <div class="clearfix">
          <span class="float-left h4">
            <i class="fas fa-envelope-open-dollar"></i> โอนเงิน</span>
          <span class="float-right text-danger" data-dismiss="modal">
            <i class="fas fa-window-close fa-2x"></i>
          </span>
        </div>
      </div>
	  
	  <form method="post" id="scb_transfer" enctype="multipart/form-data">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ยอดเงิน</label>
			  <input class="form-control" type="text" name="amount" required>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">เลขบัญชี</label>
              <input class="form-control" type="text" name="accountTo" required>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ประเภท</label>
              <select class="custom-select form-control" name="accountToBankCode" required>
                <option selected="selected">เลือก</option>
                <option value="ธ.กสิกรไทย">ธ.กสิกรไทย</option>
                <option value="ธ.กรุงไทย">ธ.กรุงไทย</option>
                <option value="ธ.กรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
                <option value="ธ.กรุงเทพ">ธ.กรุงเทพ</option>
                <option value="ธ.ไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
                <option value="ธ.ทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
                <option value="ธ.ออมสิน">ธ.ออมสิน</option>
                <option value="ธ.ก.ส.">ธ.ก.ส.</option>
                <option value="ธ.ซีไอเอ็มบีไทย">ธ.ซีไอเอ็มบีไทย</option>
                <option value="ธ.เกียรตินาคินภัทร">ธ.เกียรตินาคินภัทร</option>
                <option value="ธ.ทิสโก้">ธ.ทิสโก้</option>
                <option value="ธ.ยูโอบี">ธ.ยูโอบี</option>
                <option value="ธ.อิสลาม">ธ.อิสลาม</option>
                <option value="ธ.ไอซีบีซี">ธ.ไอซีบีซี</option>
              </select>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">รหัสถอนเงิน</label>
              <input class="form-control" type="password" name="key_input" required>
            </fieldset>
          </div>


        </div>
      </div>
      <div class="card-footer">
        <button type="submit" class="btn btn-success float-right">
          <i class="fas fa-save"></i> ยืนยัน </button>
      </div>
	  </form>
	  
    </div>
  </div>
</div>


<div class="modal fade" id="kplus_modal" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="card">
      <div class="card-header">
        <div class="clearfix">
          <span class="float-left h4">
            <i class="fas fa-envelope-open-dollar"></i> โอนเงิน</span>
          <span class="float-right text-danger" data-dismiss="modal">
            <i class="fas fa-window-close fa-2x"></i>
          </span>
        </div>
      </div>
	  
	  <form method="post" id="kplus_transfer" enctype="multipart/form-data">
      <div class="card-body">
        <div class="row">
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ยอดเงิน</label>
			  <input class="form-control" type="text" name="amount" required>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">เลขบัญชี</label>
              <input class="form-control" type="text" name="accountTo" required>
            </fieldset>
          </div>
          <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">ประเภท</label>
              <select class="custom-select form-control" name="accountToBankCode" required>
                <option selected="selected">เลือก</option>
                <option value="ธ.กสิกรไทย">ธ.กสิกรไทย</option>
                <option value="ธ.กรุงไทย">ธ.กรุงไทย</option>
                <option value="ธ.กรุงศรีอยุธยา">ธ.กรุงศรีอยุธยา</option>
                <option value="ธ.กรุงเทพ">ธ.กรุงเทพ</option>
                <option value="ธ.ไทยพาณิชย์">ธ.ไทยพาณิชย์</option>
                <option value="ธ.ทหารไทยธนชาติ">ธ.ทหารไทยธนชาติ</option>
                <option value="ธ.ออมสิน">ธ.ออมสิน</option>
                <option value="ธ.ก.ส.">ธ.ก.ส.</option>
                <option value="ธ.ซีไอเอ็มบีไทย">ธ.ซีไอเอ็มบีไทย</option>
                <option value="ธ.เกียรตินาคินภัทร">ธ.เกียรตินาคินภัทร</option>
                <option value="ธ.ทิสโก้">ธ.ทิสโก้</option>
                <option value="ธ.ยูโอบี">ธ.ยูโอบี</option>
                <option value="ธ.อิสลาม">ธ.อิสลาม</option>
                <option value="ธ.ไอซีบีซี">ธ.ไอซีบีซี</option>
              </select>
            </fieldset>
          </div>
		  <div class="col-lg-12">
            <fieldset class="form-group">
              <label class="control-label-dc">รหัสถอนเงิน</label>
              <input class="form-control" type="password" name="key_input" required>
            </fieldset>
          </div>


        </div>
      </div>
      <div class="card-footer">
        <button type="submit" class="btn btn-success float-right">
          <i class="fas fa-save"></i> ยืนยัน </button>
      </div>
	  </form>
	  
    </div>
  </div>
</div>
<script src="/assets/admin/plugins/dropify/dropify.min.js"></script> 
<script>
$(document).ready(function(){

$('.dropify').dropify({
    messages: {
        'default': 'ลากและวางไฟล์ที่นี่หรือคลิก',
        'replace': 'ลากและวางหรือคลิกเพื่อแทนที่',
        'remove':  'ลบ',
        'error':   'อ๊ะ มีบางอย่างผิดปกติเกิดขึ้น'
    }
});

});
</script>
<script type="text/javascript">
function handleClick(checkbox) {
var TABLE_NAME = "bank";
var SET_NAME = "status_bank";
var WHERE_NAME = "id";
    if(checkbox.checked){
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"เปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
    else{
		$.ajax({
            url: '/api/admin/updatecheckbox',
            type: 'POST',
            data:{
				TABLE_NAME:TABLE_NAME,
				SET_NAME:SET_NAME,
				SET_VALUE:"ปิด",
				WHERE_NAME:WHERE_NAME,
				WHERE_VALUE:checkbox.value,
			},
			success:function(data){
				Swal.fire({
					toast: true,
					icon: 'success',
					title: 'บันทึกสำเร็จ',
					position: 'top-right',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });
    }
}
</script>
<script type="text/javascript">
$("#form_addbank").on("submit",function(e){
        e.preventDefault();
		var checked = $('#status_bank').is(":checked") ? 'เปิด':'ปิด'; 
        var formData = new FormData($(this)[0]);
		formData.append("status_bank",checked);
		console.log(formData);
        $.ajax({
            url: '/api/admin/bank',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				//console.log(data);
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					$('#closemodal_1').click();
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					}).then((result) => {
						window.location.href='./settingbank';
					})
					
					
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>
<script type="text/javascript">
var function_delete_id = document.getElementsByClassName("startdelete");
if (function_delete_id) {
    Array.from(function_delete_id).forEach(function(element) {
        element.addEventListener('click', Call_delete_id);
    });
   }
function Call_delete_id() {
	    var id = $(this).data('id');
		Swal.fire({
			title: 'คำเตือน',
			text: "คุณต้องการ ลบ ใช่ไหม",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00C851',
			cancelButtonColor: '#d33',
			confirmButtonText: 'ใช่'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					type:"POST",
					data: {
					   'FROM_NAME' : 'bank',
					   'WHERE_NAME' : 'id',
					   'WHERE_VALUE' : id,
					},
					url:"/api/admin/run_delete_sql",
					success:function(data){
						Swal.fire({
							icon: 'success',
							title: 'ลบรายการ สำเร็จ',
							showConfirmButton: false,
							timer: 2000,
							timerProgressBar: true,
						}).then((result) => {
							window.location.href='./settingbank';
						})

					}

				})

			}

		})
}
</script>
<script type="text/javascript">
$("#scb_transfer").on("submit",function(e){
e.preventDefault();
Swal.fire({
	icon: 'error',
	title: 'กำลังแก้ไข',
	showConfirmButton: false,
	timer: 2000,
	timerProgressBar: true,
})
});
</script>
<script type="text/javascript">
$("#kplus_transfer").on("submit",function(e){
e.preventDefault();
        var formData = new FormData($(this)[0]);
		console.log(formData);
        $.ajax({
            url: '/api/admin/TransferKBank',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				console.log(data);
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					}).then((result) => {
						window.location.href='./settingbank';
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>