<?php
$id = $_GET['id'];
$sql = "SELECT * FROM bank WHERE id ='$id' ";
$setting_bank = $class_admin->load_db_date($sql);
?>
<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/settingbank"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> แก้ไข - ธนาคาร</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
			</div>
			<hr>
			
			<form id="form_bankupdateform" method="POST" enctype="multipart/form-data">
			<input class="d-none" type="" name="id" value="<?php echo $id; ?>">
			<div class="row">
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ธนาคาร/ทรูวอเล็ต</label>
				  <select class="custom-select form-control" name="name_bank" required="required">
					<option selected="selected" value="<?php echo $setting_bank->name_bank; ?>"><?php echo $setting_bank->name_bank; ?></option>
					  <option value="ทรูวอเล็ต">ทรูวอเล็ต</option>
					  <option value="ธนาคารกสิกรไทย">ธนาคารกสิกรไทย</option>
					  <option value="ธนาคารไทยพาณิชย์">ธนาคารไทยพาณิชย์</option>
					  <option value="ธนาคารกรุงไทย">ธนาคารกรุงไทย</option>
					  <option value="ธนาคารกรุงเทพ">ธนาคารกรุงเทพ</option>
					  <option value="ธนาคารกรุงศรีอยุธยา">ธนาคารกรุงศรีอยุธยา</option>
					  <option value="ธนาคารทหารไทยธนชาติ">ธนาคารทหารไทยธนชาติ</option>
					  <option value="ธนาคารเกียรตินาคินภัทร">ธนาคารเกียรตินาคินภัทร</option>
				  </select>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">เลขบัญชี</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->bankacc_bank; ?>" name="bankacc_bank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ชื่อบัญชี</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->nameacc_bank; ?>" name="nameacc_bank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ประเภท</label>
				  <select class="custom-select form-control" name="bankfor">
					  <option selected="selected" value="<?php echo $setting_bank->bankfor; ?>"><?php echo $setting_bank->bankfor; ?></option>
					  <option value="ฝาก">ฝาก</option>
					  <option value="ถอน">ถอน</option>
					  <option value="ฝากและถอน">ฝากและถอน</option>
				  </select>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">DEVICE ID</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->device; ?>" name="device">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">PIN SCB/ทรูวอเล็ต</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->pin_bank; ?>" name="pin_bank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">รหัสผ่านทรูวอเล็ต</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->password_true; ?>" name="password_true">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">เลขอ้างอิงทรูวอเล็ต</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->no_true; ?>" name="no_true">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">OTP ทรูวอเล็ต</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->otp_true; ?>" name="otp_true">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">User KBank</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->user_kbank; ?>" name="user_kbank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">Pass KBank</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->pass_kbank; ?>" name="pass_kbank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ID KBank</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->id_kbank; ?>" name="id_kbank">
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">Token KBank</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->token_kbank; ?>" name="token_kbank">
				</fieldset>
			  </div>
			  <div class="col-lg-1">
				<fieldset class="form-group text-center">
				  <label class="control-label-dc">สถานะ</label>
				  <div class="form-check form-switch form-switch-md">
					<input class="form-check-input" type="checkbox" name="status_bank" id="status_bank" <?php if ($setting_bank->status_bank == "เปิด")  { ?> checked <?php } ?>>
				  </div>
				</fieldset>
			  </div>
			  <div class="col-lg-2 mt-2 align-self-center">
					<button type="button" class="btn btn-sm btn-danger btn-block p-2" onclick="window.open('/system/run/tw4', '_blank')" ><i class="fas fa-sms"></i> รับ OTP ทรูวอเล็ต</button>
			  </div>
			  <div class="col-lg-2 mt-2 align-self-center">
					<button type="button" class="btn btn-sm btn-primary btn-block p-2" onclick="window.open('/system/run/tw5', '_blank')" ><i class="fab fa-google-wallet"></i> LOGIN ทรูวอเล็ต</button>
			  </div>
			  
			</div>
			<button type="submit" id="submitclick" class="d-none" ></button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
	$("#form_bankupdateform").on("submit",function(e){
        e.preventDefault();
		var checked = $('#status_bank').is(":checked") ? 'เปิด':'ปิด'; 
        var formData = new FormData($(this)[0]);
		formData.append("status_bank",checked);
		formData.append("TABLE_NAME","bank");
		formData.append("WHERE_NAME","id");
		formData.append("WHERE_VALUE",formData.get('id'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='./settingbank';
				})
			}
        });    
    });
</script>