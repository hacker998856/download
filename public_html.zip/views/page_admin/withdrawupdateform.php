<?php
$id = $_GET['id'];
$sql = "SELECT * FROM withdraw WHERE id = '$id' ";
$setting_withdraw = $class_admin->load_db_date($sql);

$selete_username = $setting_withdraw->username_wd;

$sql2 = "SELECT * FROM deposit WHERE username_dp = '$selete_username'  AND confirm_dp = 'อนุมัติ'  ORDER BY id DESC limit 1";
$setting_withdraw2 = $class_admin->load_db_date($sql2);

$UsernameAgent = $Get_Setting->agent . $setting_withdraw->username_wd;
$Balance = $class_admin->load_balance_user($UsernameAgent);
?>
<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/withdraw"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-minus-square"></i> ตัดเครดิต</h4>
					<hr>
					<div class="row mb-3">
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">ยูสเซอร์เนม </label>
								<input class="form-control" type="text" id="username" value="<?php echo $UsernameAgent; ?>" readonly="readonly">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">จำนวนเครดิตที่ตัด</label>
								<input class="form-control" type="text" id="amount" value="<?php echo $setting_withdraw->amount_wd; ?>">
							</div>
						</div>
						<div class="col-md-4 mt-2 align-self-center">
							<button type="button" id="removesubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-check"></i> ตัดเครดิต</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-search-plus"></i> ตรวจสอบรายการถอนเงิน</h4>
					<hr class="mb-0">
					  <div class="d-flex justify-content-around box text-nowrap mb-4">
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">เครดิตคงเหลือ</h4>
								<span class="description-text"><?php echo $Balance; ?></span>
							</div>
						</div>
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">ยอดเทิร์นที่ต้องทำ</h4>
								<span class="description-text"><?php echo $setting_withdraw2->turnover; ?></span>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="description-block">
								<h4 class="description-header text-black">โปรโมชั่นล่าสุด</h4>
								<span class="description-text"><?php echo $setting_withdraw2->promotion_dp; ?></span>
							</div>
						</div>
					  </div>

					<form method="post" id="form_withdrawupdateform" enctype="multipart/form-data">
					<input class="form-control" type="text" name="id" value="<?php echo $id; ?>" hidden>
					<input class="form-control" type="text" name= "edit_wd" value="<?php echo $_SESSION["name_ad"]; ?>" hidden>
					<div class="row mb-3">
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยอดเงินถอน</label>
							  <input class="form-control" type="text" name="amount_wd" value="<?php echo $setting_withdraw->amount_wd; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยูสเซอร์เนม</label>
							  <input class="form-control" type="text" value="<?php echo $UsernameAgent; ?>" readonly>
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ชื่อ-นามสกุล</label>
							  <input class="form-control" type="text" name="name_wd" value="<?php echo $setting_withdraw->name_wd; ?>" readonly>
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เบอร์โทรศัพท์</label>
							  <input class="form-control" type="text" name="phone_wd" value="<?php echo $setting_withdraw->phone_wd; ?>" readonly>
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เลขบัญชีธนาคาร</label>
							  <input class="form-control" type="text" name="bankacc_wd" value="<?php echo $setting_withdraw->bankacc_wd; ?>" readonly> 
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ธนาคาร</label>
							  <input class="form-control" type="text" name="bank_wd" value="<?php echo $setting_withdraw->bank_wd; ?>" readonly>
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							<label class="control-label-dc">ธนาคารที่ใช้ถอน</label>
								<select class="custom-select form-control" name="bankout_wd">
								<option selected="selected" value="<?php echo $setting_withdraw->bankout_wd; ?>"><?php echo $setting_withdraw->bankout_wd; ?></option>
								<option value="ไม่ถูกต้อง">ไม่ถูกต้อง</option>
								
								<?php 
                            $sqlbankwithdraw = "SELECT * FROM bank WHERE bankfor LIKE '%ถอน%' AND status_bank ='เปิด' ";
							$resultbankwithdraw  = $class_admin->load_date_sql($sqlbankwithdraw);
                            while($bankwithdraw = mysqli_fetch_array($resultbankwithdraw)) 
								{ ?>
							<option value="<?php echo $bankwithdraw['name_bank']; ?><?php echo $bankwithdraw['bankacc_bank']; ?>"><?php echo $bankwithdraw['name_bank']; ?> <?php echo $bankwithdraw['bankacc_bank']; ?></option>
						  <?php } ?>
							    </select>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							<label class="control-label-dc">สถานะ</label>
								<select class="custom-select form-control" name="confirm_wd">
									<option value="<?php echo $setting_withdraw->confirm_wd; ?>"><?php echo $setting_withdraw->confirm_wd; ?></option>
									<option value="อนุมัติ">อนุมัติ</option>
									<option value="ปฏิเสธ">ปฏิเสธ</option>
							    </select>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">หมายเหตุ***</label>
							  <input class="form-control" type="text" name="note_wd" value="<?php echo $setting_withdraw->note_wd; ?>">
							</fieldset>	
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button>
						</div>
					</div>
					</form>
					
					
				</div>
			</div>
			<div class="col-md-6">
			</div>
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-sack-dollar"></i> โอนเงิน</h4>
					<hr>
					
					<form method="post" id="kplus_transfer_wd" enctype="multipart/form-data">
					<input type="text" name="phone_wd" value="<?php echo $setting_withdraw->phone_wd; ?>" hidden>
					<input type="text" name="accountTo" value="<?php echo $setting_withdraw->bankacc_wd; ?>" hidden>
                    <input type="text" name="accountToBankCode" value="<?php echo $setting_withdraw->bank_wd; ?>" hidden>
					<div class="row mb-3">
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">ยอดเงิน </label>
								<input class="form-control" type="text" name="amount" required>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">รหัสลับ</label>
								<input class="form-control" type="password" name="key_input" required>
							</div>
						</div>
						<div class="col-md-4 mt-2 align-self-center">
							<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-check"></i> โอนเงิน</button>
						</div>
					</div>
					</form>
					
				</div>
			</div>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$('#removesubmit').click(function(e){
e.preventDefault();
var username = $("#username").val();
var amount = $("#amount").val();
		$.ajax({
            url: '/api/admin/removecredit',
            type: 'POST',
            data: {
				username:username,
				amount:amount,
			},
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status == 'success') {
					Swal.fire({
						icon: 'success',
						title: 'ตัดเครดิต สำเร็จ',
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด ' + obj.status,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				} 
			}
        });
});
</script>

<script type="text/javascript">
$("#kplus_transfer_wd").on("submit",function(e){
e.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: '/api/admin/TransferKBank',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status=="success"){
					Swal.fire({
						icon: 'success',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: obj.info,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}
			}
        });    
});
</script>


<script type="text/javascript">
$("#form_withdrawupdateform").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","withdraw");
formData.append("WHERE_NAME","id");
formData.append("WHERE_VALUE",formData.get('id'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>