<script type="text/javascript">
$(document).ready(function(){
  $("#input_search").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#showdateget tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<h4 class="text-black"><i class="fas fa-history"></i> ประวัติรายการ TRUE WALLET</h4>
			<hr>
			<div class="row mb-3">
				<div class="col-md-2 mt-2 align-self-center">
					<div class="form-group">
						<label class="control-label-dc">ค้นหา</label>
						<input class="form-control" id="input_search" type="text">
					</div>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show100" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 100 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show500" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 500 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="show1000" class="btn btn-sm btn-primary btn-block p-2">ค้นหา 1,000 รายการล่าสุด</button>
				</div>
				<div class="col-md-2 mt-3 align-self-center">
					<button type="button" id="showAll" class="btn btn-sm btn-primary btn-block p-2">ค้นหาทุกรายการทั้งหมด</button>
				</div>
			</div>
			<hr>
			<div class="table-responsive">
				<table class="table table-bordered text-nowrap text-center">
					<thead class="text-black">
						<tr>
							<th scope="col">ลำดับ	</th>
							<th scope="col">สถานะ</th>
							<th scope="col">จำนวนเงิน</th>
							<th scope="col">ไอดีทรู</th>
							<th scope="col">ชื่อ-นามสกุล</th>
							<th scope="col">เวลาที่ลงบันทึก</th>
						</tr>
					</thead>
					<tbody id="showdateget">
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function showdatelist(GetDate) {
	console.log(GetDate.result);
	$('#showdateget').html('');
	html = "";
	$.each(GetDate.result, function( index, value ) {
		var str_type;
		
		if(value.status =="รับโอนเงิน"){
			str_type = '<span class="btn btn-info btn-sm px-2 noHover">รับโอนเงิน</span>';
		} else if (value.status =="โอนเงิน") {
			str_type = '<span class="btn btn-sm btn-success px-3 noHover">โอนเงิน</span>';
		}else{
			str_type = '<span class="btn btn-sm btn-danger px-4 noHover">อื่นๆ</span>';
		}
		
		html += '<tr>';
		html += '<th scope="col">' + value.id + '</th>';
		html += '<th scope="col">' + str_type + '</th>';
		html += '<th scope="col">' + value.amount + '</th>';
		html += '<th scope="col">' + value.trueacc + '</th>';
		html += '<th scope="col">' + value.name + '</th>';
		html += '<th scope="col">' + value.datetrue + '</th>';
		html += '</tr>';
	});
	$('#showdateget').html(html);
	$('#ShowFromDay').html(GetDate.ShowFromDay);
	$('#ShowToDay').html(GetDate.ShowToDay);
}
</script>
<script type="text/javascript">
$("#show100").click(function(){
var show100 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadtruehistory",
      data: {
          show100:show100
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show500").click(function(){
var show500 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadtruehistory",
      data: {
          show500:show500
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#show1000").click(function(){
var show1000 = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadtruehistory",
      data: {
          show1000:show1000
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
$("#showAll").click(function(){
var showAll = '';
$.ajax({
      type: "POST",
      url: "/api/admin/loadtruehistory",
      data: {
          showAll:showAll
      },
      success: function(data) {
          var obj = JSON.parse(data);
		  if (obj.result !== null) {
			 showdatelist(obj); 
		  }else{
			 $('#showdateget').html('');
		  } 
      }
  });
});
</script>