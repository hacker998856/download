<?php
$id = $_GET['id'];
$sql = "SELECT * FROM admin WHERE id_ad = '$id' ";
$setting_bank = $class_admin->load_db_date($sql);
?>
<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/settingstaff"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> แก้ไข - ข้อมูลพนักงาน</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
			</div>
			<hr>
			
			<form id="form_adminupdateform" method="POST" enctype="multipart/form-data">
			<input class="d-none" type="" name="id_ad" value="<?php echo $id; ?>">
			<div class="row">
			  <div class="col-lg-3">
				<fieldset class="form-group">
				  <label class="control-label-dc">ยูสเซอร์เนม</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->username_ad; ?>" name="username_ad" required>
				</fieldset>
			  </div>
			  <div class="col-lg-3">
				<fieldset class="form-group">
				  <label class="control-label-dc">รหัสผ่าน</label>
				  <input class="form-control" type="text" name="password_ad" value="" required>
				</fieldset>
			  </div>
			  <div class="col-lg-3">
				<fieldset class="form-group">
				  <label class="control-label-dc">เบอร์โทรศัพท์</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->phone_ad; ?>" name="phone_ad">
				</fieldset>
			  </div>
			  <div class="col-lg-3">
				<fieldset class="form-group">
				  <label class="control-label-dc">ชื่อ-นามสกุล</label>
				  <input class="form-control" type="text" value="<?php echo $setting_bank->name_ad; ?>" name="name_ad">
				</fieldset>
			  </div>
			</div>
			<button type="submit" id="submitclick" class="d-none" ></button>
			</form>
			
		</div>
	</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/js-md5@0.7.3/src/md5.min.js"></script>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
	$("#form_adminupdateform").on("submit",function(e){
        e.preventDefault();
        var formData = new FormData($(this)[0]);
		var password_md5 = md5(formData.get('password_ad'));
		formData.append("TABLE_NAME","admin");
		formData.append("WHERE_NAME","id_ad");
		formData.append("WHERE_VALUE",formData.get('id_ad'));
		formData.append('password_ad',password_md5);
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='./settingstaff';
				})
			}
        });    
    });
</script>