<?php
$myid = $_GET['id'];
$sql = "SELECT * FROM deposit WHERE id = '$myid' ";
$date_deposit = $class_admin->load_db_date($sql);

$amount_dp = (float)$date_deposit->amount_dp;
$UsernameAgent = $Get_Setting->agent . $date_deposit->username_dp;
$Balance = $class_admin->load_balance_user($UsernameAgent);
?>

<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/deposit"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>

<?php                    

if ($date_deposit->promotion_dp=='ไม่รับโบนัส') {
     $status_amount = $amount_dp + 0;
}
$sql_promotion = "SELECT * FROM promotion ORDER BY id DESC";
$result_promotion = $class_admin->load_date_sql($sql_promotion);           
while($row_promotion = mysqli_fetch_array($result_promotion)) {
$namepro = $row_promotion['name_pro'];
$bonuspro = $row_promotion['bonus_pro'];
$bonusperpro = $row_promotion['bonusper_pro'];      
               
if ($date_deposit->promotion_dp == $namepro){
	
	$status_amount = ($amount_dp + $bonuspro) + ($amount_dp * $bonusperpro / 100);

	
}   
              
}

if ($amount_dp == 'กิจกรรม'){ 
	$status_amount = $date_deposit->bonus_dp;
}

?>

<div class="content-wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-plus-square"></i> เพิ่มเครดิต</h4>
					<hr>
					<div class="row mb-3">
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">ยูสเซอร์เนม </label>
								<input class="form-control" type="text" id="username" value="<?php echo $UsernameAgent; ?>" readonly="readonly">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group has-feedback">
								<label class="control-label-dc">จำนวนเครดิตที่เติม</label>
								<input class="form-control" type="text" id="amount" value="<?php echo $status_amount; ?>">
							</div>
						</div>
						<div class="col-md-4 mt-2 align-self-center">
							<button type="button" id="addsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-check"></i> เพิ่มเครดิต</button>
						</div>
					</div>
				</div>
			</div>
			
			
			
			<div class="col-md-6">
				<div class="info-box">
					<h4 class="text-black"><i class="fas fa-search-plus"></i> ตรวจสอบรายการฝากเงิน</h4>
					<hr class="mb-0">
					  <div class="d-flex justify-content-around box text-nowrap mb-4">
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">เครดิตคงเหลือ</h4>
								<span class="description-text"><?php echo $Balance; ?></span>
							</div>
						</div>
						<div class="col-sm-4 border-right">
							<div class="description-block">
								<h4 class="description-header text-black">ยอดเติมเงิน</h4>
								<span class="description-text"><?php echo $date_deposit->amount_dp; ?></span>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="description-block">
								<h4 class="description-header text-black">โปรโมชั่นที่รับ</h4>
								<span class="description-text"><?php echo $date_deposit->promotion_dp; ?></span>
							</div>
						</div>
					  </div>

					<form method="post" id="form_depositupdateform" enctype="multipart/form-data">
					<input class="d-none" type="" name="id" value="<?php echo $myid; ?>">
					<div class="row mb-3">
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยอดเงินฝาก</label>
							  <input class="form-control" type="text" name= "add_dp" value="<?php echo $_SESSION["name_ad"]; ?>" hidden>
							  <input class="form-control" type="text" name= "edit_dp" value="<?php echo $_SESSION["name_ad"]; ?>" hidden>
							  <input class="form-control" type="text" name="amount_dp" value="<?php echo $date_deposit->amount_dp; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">โบนัส</label>
							  <input class="form-control" type="text" name="bonus_dp" value="<?php echo $date_deposit->bonus_dp; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เทิร์นโอเวอร์</label>
							  <input class="form-control" type="text" name="turnover" value="<?php echo $date_deposit->turnover; ?>">
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ยูสเซอร์เนม</label>
							  <input class="form-control" type="text" value="<?php echo $UsernameAgent; ?>" readonly="readonly">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ชื่อ-นามสกุล</label>
							  <input class="form-control" type="text" name="name_dp" value="<?php echo $date_deposit->name_dp; ?>" readonly="readonly">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เบอร์โทรศัพท์</label>
							  <input class="form-control" type="text" name="phone_dp" value="<?php echo $date_deposit->phone_dp; ?>" readonly="readonly">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							<label class="control-label-dc">ธนาคารที่โอนเข้า</label>
								<select class="custom-select form-control" name="bankin_dp">
								<option selected="selected" value="<?php echo $date_deposit->bankin_dp; ?>"><?php echo $date_deposit->bankin_dp; ?></option>
								<option value="ไม่ถูกต้อง">ไม่ถูกต้อง/เครดิตฟรี</option>
								<?php
								$sql_bank = "SELECT * FROM bank WHERE bankfor LIKE '%ฝาก%' AND status_bank ='เปิด' ";
								$setting_bank = $class_admin->load_date_sql($sql_bank);
								?>
								<?php
								while($row_bank = mysqli_fetch_array($setting_bank)) {
								?>
									<option value="<?php echo $row_bank['name_bank']; ?> <?php echo $row_bank['bankacc_bank']; ?>"><?php echo $row_bank['name_bank']; ?> <?php echo $row_bank['bankacc_bank'];?></option>
								<?php
								}
								?>
							    </select>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">ธนาคาร</label>
							  <input class="form-control" type="text" name="bank_dp" value="<?php echo $date_deposit->bank_dp; ?>" readonly="readonly">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">เลขบัญชีธนาคาร</label>
							  <input class="form-control" type="text" name="bankacc_dp" value="<?php echo $date_deposit->bankacc_dp; ?>" readonly="readonly">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							<label class="control-label-dc">สถานะ</label>
								<select class="custom-select form-control" name="confirm_dp" required>
									<option value="<?php echo $date_deposit->confirm_dp; ?>"><?php echo $date_deposit->confirm_dp; ?></option>
									<option value="อนุมัติ">อนุมัติ</option>
									<option value="ปฏิเสธ">ปฏิเสธ</option>
							    </select>
							</fieldset>
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">หมายเหตุ***</label>
							  <input class="form-control" type="text" name="note_dp" value="<?php echo $date_deposit->note_dp; ?>">
							</fieldset>	
						</div>
						<div class="col-md-4">
							<fieldset class="form-group">
							  <label class="control-label-dc">โปรโมชั่น</label>
							  <select class="custom-select form-control" name="promotion_dp">
							  <option selected="selected" value="<?php echo $date_deposit->promotion_dp; ?>"><?php echo $date_deposit->promotion_dp; ?></option>
							  <option value="ไม่รับโปรโมชั่น">ไม่รับโปรโมชั่น</option>
							  <?php
								$sql_pro = "SELECT * FROM promotion ORDER BY id DESC";
								$load_sql_pro = $class_admin->load_date_sql($sql_pro);
								?>
								<?php
								while($row_pro = mysqli_fetch_array($load_sql_pro)) {
								?>
									<option value="<?php echo $row_pro['name_pro']; ?>"><?php echo $row_pro['name_pro']; ?></option>
								<?php
								}
								?>
								</select>
							</fieldset>	
						</div>
						<div class="col-md-3 mt-2 align-self-center">
							<button type="submit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button>
						</div>
					</div>
					</form>
					
					
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
$('#addsubmit').click(function(e){
e.preventDefault();
var username = $("#username").val();
var amount = $("#amount").val();
//console.log(username);
//console.log(amount);
		$.ajax({
            url: '/api/admin/addcredit',
            type: 'POST',
            data: {
				username:username,
				amount:amount,
			},
			success:function(data){
				var obj = JSON.parse(data);
				if (obj.status == 'success') {
					Swal.fire({
						icon: 'success',
						title: 'เพิ่มเครดิต สำเร็จ',
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				}else{
					Swal.fire({
						icon: 'error',
						title: 'ผิดพลาด ' + obj.status,
						showConfirmButton: false,
						timer: 2000,
						timerProgressBar: true,
					})
				} 
			}
        });
});

</script>
<script type="text/javascript">
$("#form_depositupdateform").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","deposit");
formData.append("WHERE_NAME","id");
formData.append("WHERE_VALUE",formData.get('id'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>