<?php
$id = $_GET['id'];
$sql = "SELECT * FROM withdrawaff WHERE id='$id' ";
$date_withdrawaff = $class_admin->load_db_date($sql);
?>
<script type="text/javascript">
$(document).ready(function () {
$('.treeview a[href="/admin/withdrawaff"]').parent().addClass("active").closest('.treeview').addClass('active');
});
</script>
<div class="content-wrapper">
	<div class="content">
		<div class="info-box">
			<div class="d-flex">
			  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-search-plus"></i> ตรวจสอบรายการถอนเงิน</h4></div>
			  <div class="col-lg-2 col-5"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
			</div>
			<hr>
			
			<form id="form_withdrawaffupdateform" method="POST" enctype="multipart/form-data">
			<input class="d-none" type="" name="id" value="<?php echo $id; ?>">
			<div class="row">
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ยูสเซอร์เนม</label>
				  <input class="form-control" type="text" value="<?php echo $Get_Setting->agent; ?><?php echo $date_withdrawaff->username_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ยอดเงินถอน</label>
				  <input class="form-control" type="text" name="amount_aff" value="<?php echo $date_withdrawaff->amount_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">เบอร์โทรศัพท์</label>
				  <input class="form-control" type="text" name="phone_aff" value="<?php echo $date_withdrawaff->phone_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">เลขบัญชีธนาคาร</label>
				  <input class="form-control" type="text" name="bankacc_aff" value="<?php echo $date_withdrawaff->bankacc_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ธนาคาร</label>
				  <input class="form-control" type="text" name="bank_aff" value="<?php echo $date_withdrawaff->bank_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ชื่อ-นามสกุล</label>
				  <input class="form-control" type="text" name="name_aff" value="<?php echo $date_withdrawaff->name_aff; ?>" readonly>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">สถานะ</label>
				  <select class="custom-select form-control" name="confirm_aff">
					  <option selected="selected" value="<?php echo $date_withdrawaff->confirm_aff; ?>"><?php echo $date_withdrawaff->confirm_aff; ?></option>
					  <option value="อนุมัติ">อนุมัติ</option>
                      <option value="ปฏิเสธ">ปฏิเสธ</option>
				  </select>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">ธนาคารที่ใช้ถอน</label>
				  <select class="custom-select form-control" name="bankout_aff">
					  <option selected="selected" value="<?php echo $date_withdrawaff->bankout_aff; ?>"><?php echo $date_withdrawaff->bankout_aff; ?></option>
					  <option value="ปฏิเสธการถอน">ปฏิเสธการถอน</option>

						<?php 
                            $sqlbankwithdraw = "SELECT * FROM bank WHERE bankfor LIKE '%ถอน%' AND status_bank ='เปิด' ";
							$resultbankwithdraw  = $class_admin->load_date_sql($sqlbankwithdraw);
                            while($bankwithdraw = mysqli_fetch_array($resultbankwithdraw)) 
								{ ?>
							<option value="<?php echo $bankwithdraw['name_bank']; ?><?php echo $bankwithdraw['bankacc_bank']; ?>"><?php echo $bankwithdraw['name_bank']; ?> <?php echo $bankwithdraw['bankacc_bank']; ?></option>
						  <?php } ?>
						  
				  </select>
				</fieldset>
			  </div>
			  <div class="col-lg-4">
				<fieldset class="form-group">
				  <label class="control-label-dc">หมายเหตุ</label>
				  <input class="form-control" type="text" name="note_aff" value="<?php echo $date_withdrawaff->note_aff; ?>">
				</fieldset>
			  </div>
			  
			</div>
			<button type="submit" id="submitclick" class="d-none" ></button>
			</form>
			
		</div>
	</div>
</div>
<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});
</script>
<script type="text/javascript">
	$("#form_withdrawaffupdateform").on("submit",function(e){
        e.preventDefault();
        var formData = new FormData($(this)[0]);
		formData.append("TABLE_NAME","withdrawaff");
		formData.append("WHERE_NAME","id");
		formData.append("WHERE_VALUE",formData.get('id'));
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				}).then((result) => {
					window.location.href='./withdrawaff';
				})
			}
        });    
    });
</script>