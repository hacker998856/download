<?php
if($_SESSION["status_ad"] != "Administrator"){
	echo "<script>window.location = './'</script>";
	exit;
}
?>
<?php
$sql_apikey = "SELECT * FROM apikey ORDER BY id DESC LIMIT 1";
$load_date_apikey = $class_admin->load_date_sql($sql_apikey);
while($row = mysqli_fetch_array($load_date_apikey)) {
	$user_agent = $row['user_agent'];
	$x_api_betflix = $row['x_api_betflix'];
	$x_api_key = $row['x_api_key'];
}

?>

<div class="content-wrapper">
	<div class="content">
      <div class="info-box">
		<div class="d-flex">
		  <div class="mr-auto"><h4 class="text-black"><i class="fas fa-cogs"></i> ตั้งค่า - API KEY</h4></div>
		  <div class="col-lg-2 col-4"><button type="button" id="settingsubmit" class="btn btn-sm btn-success btn-block p-2"><i class="fas fa-save"></i> บันทึก</button></div>
		</div>
		<hr>
		
		<form method="post" id="form_apikey" enctype="multipart/form-data">
        <div class="row">
		  <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">USER-AGENT</label>
              <input class="form-control" type="text" name="user_agent" value="<?php echo $user_agent; ?>" required>
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">X-API-BETFLIX</label>
              <input class="form-control" type="text" name="x_api_betflix" value="<?php echo $x_api_betflix; ?>" required>
            </fieldset>
          </div>
          <div class="col-lg-4">
            <fieldset class="form-group">
              <label class="control-label-dc">X-API-KEY</label>
              <input class="form-control" type="text" name="x_api_key" value="<?php echo $x_api_key; ?>" required>
            </fieldset>
          </div>
        </div>
		<button type="submit" id="submitclick" class="d-none" ></button>
		</form>
		
    </div>
</div>

<script type="text/javascript">
$('#settingsubmit').click(function(e){
e.preventDefault();
$('#submitclick').click();
});

</script>
<script type="text/javascript">
$("#form_apikey").on("submit",function(e){
e.preventDefault();
var formData = new FormData($(this)[0]);
formData.append("TABLE_NAME","apikey");
formData.append("WHERE_NAME","id");
formData.append("WHERE_VALUE","1");
        $.ajax({
            url: '/api/admin/run_update_sql',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
			success:function(data){
				Swal.fire({
					icon: 'success',
					title: 'บันทึก สำเร็จ',
					showConfirmButton: false,
					timer: 2000,
					timerProgressBar: true,
				})
			}
        });    
});
</script>