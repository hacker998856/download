$(document).ready(function(){
	// menu click event
	$('.menuBtn').click(function() {
		$(this).toggleClass('act');
			if($(this).hasClass('act')) {
				$('.mainMenu').addClass('act');
				$('.showfull').addClass('full');
			}
			else {
				$('.mainMenu').removeClass('act');
				$('.showfull').removeClass('full');
			}
	});
	
	$('.showfull').click(function() {
		
		$(".menuBtn").click();

	});
	


});